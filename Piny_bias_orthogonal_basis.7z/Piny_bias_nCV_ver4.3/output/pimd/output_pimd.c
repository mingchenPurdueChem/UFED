/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
/*                                                                          */
/*                         PI_MD:                                           */
/*             The future of simulation technology                          */
/*             ------------------------------------                         */
/*                     Module: output_pimd                                  */
/*                                                                          */
/* This subprogram provides output for a MD on a                            */ 
/* classical potential energy surface (PES)                                 */
/*                                                                          */
/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
/*               Header:                                                    */

#include "standard_include.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../typ_defs/typedefs_gen.h"
#include "../proto_defs/proto_output_entry.h"
#include "../proto_defs/proto_output_local.h"
#include "../proto_defs/proto_friend_lib_entry.h"
#include "../proto_defs/proto_math.h"
#include <errno.h>

/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void output_pimd(CLASS *class,GENERAL_DATA *general_data,BONDED *bonded,int ipt)

/*==========================================================================*/
{/*begin routine*/
  /*=======================================================================*/
  /*            Local variable declarations                                */
  /*  int ipt=1;*/

  int iii;
  int iptoff = ipt + general_data->tempering_ctrl.npara_temps_proc_off;
  int exit_flag = general_data->timeinfo.exit_flag;
  double etot,econv_now; 
  double vtot,avtot; 
  double apnow,pnow;
  double apnow_inter,pnow_inter;
  double apnow_intra,pnow_intra;
  double apnow_kin,pnow_kin;
  double nhc_div,nhc_div_bead;
  double a,b,c,tab,tac,tbc; 
  double deth;

  /*=====================================================================*/
  /*        Output_pimd routine                                            */
  /*=====================================================================*/
  /*  I)Open File option :                                               */

  if(((general_data->timeinfo.itime)==0)&&
       ((general_data->filenames.ifile_open)==1)){
     initial_fopen_pimd(class,general_data,bonded,ipt);
  }/*endif*/

  /*=======================================================================*/
  /*  II) Write Initial Energies to screen                                 */

  if(general_data->timeinfo.itime==0 && general_data->simopts.debug_pimd == 0){
    initial_output_pimd(class,general_data,bonded,ipt);
  }/*endif*/

  /*=======================================================================*/
  /* II) Calculate some dinky quantities                                   */

  if((general_data->timeinfo.itime)!=0){
    if((general_data->timeinfo.itime % general_data->filenames.iwrite_screen) == 0 || 
       (general_data->timeinfo.itime % general_data->filenames.iwrite_inst)==0 ||
        (exit_flag == 1)){
      get_cell(general_data->cell.hmat,&a,&b,&c,&tab,&tbc,&tac);
      dink_quant_calc_pimd(class, general_data,&etot,&econv_now,&vtot, &avtot,
                         &deth,&pnow, &apnow,&pnow_inter, &apnow_inter,
                         &pnow_intra, &apnow_intra,
                         &pnow_kin, &apnow_kin,&nhc_div,&nhc_div_bead,ipt);
    } /*endif*/
  }/*endif*/

  /*=======================================================================*/
  /*  III) Write to the output to screen                                   */

  if((general_data->timeinfo.itime) != 0){
    if((general_data->timeinfo.itime % general_data->filenames.iwrite_screen) == 0 ||
       (exit_flag == 1)){ 
      screen_write_pimd(class,general_data,bonded,
                     etot,econv_now,vtot,avtot,deth,pnow, apnow,
                     pnow_inter, apnow_inter,
                     pnow_intra, apnow_intra,
                     pnow_kin, apnow_kin,
                     nhc_div,nhc_div_bead,a,b,c,tab,tbc,tac,ipt);
    }/*endif*/
  }/*endif*/

  /*======================================================================*/
  /* IV) Write to the output to dump file                                 */ 

  if((general_data->timeinfo.itime!=0)){
    if((general_data->timeinfo.itime % general_data->filenames.iwrite_dump)==0 ||
       (exit_flag == 1)){
      write_dump_file_pimd(class,bonded,general_data,ipt);
    }/*endif*/
  }/*endif*/

  /*======================================================================*/
  /* V) Write to the output to free energy                                */ 

  if((general_data->timeinfo.itime)!=0){
    if((general_data->timeinfo.itime % general_data->filenames.iwrite_dump) == 0){
      write_free_energy_file_pimd(class,bonded,general_data,ipt);
    }/*endif*/
  }/*endif*/

  /*====================================================================*/
  /* VI) Write to the config files                                      */

  if((general_data->timeinfo.itime)!=0){
    write_config_files_pimd(class,bonded,general_data,ipt);
  }/*endif*/

  /*======================================================================*/
  /* VII) Write to the inst avgs to inst file                            */

  if((general_data->timeinfo.itime)!=0){
    if((general_data->timeinfo.itime % general_data->filenames.iwrite_inst) == 0 ){
      write_inst_file_pimd(class,general_data,etot,a,b,c,tac,tab,tbc,ipt);
    }/*endif*/
  }/*endif*/

/*==========================================================================*/
}/*end routine*/
/*==========================================================================*/

/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void initial_output_pimd(CLASS *class,GENERAL_DATA *general_data,BONDED *bonded,
			 int ipt)

/*==========================================================================*/

{/* begin routine */
  /*  int ipt=1;*/

  int np_tot,npairs,nsh_tot,iii;
  double nhc_div;
  double eu_conv=1.0;
  NAME tname;
  int  npara_temps      = general_data->simopts.npara_temps; 
  FILE *fp;

  if(general_data->filenames.iwrite_units==0){eu_conv=1.0;}
  if(general_data->filenames.iwrite_units==1){eu_conv=KCAL;}
  if(general_data->filenames.iwrite_units==2){eu_conv=BOLTZ;}
/*=======================================================================*/
/* switch for || temping yes/no */

  if(npara_temps==1){
    fp=stdout;
  }else{
    fp = cfopen(general_data->tempering_screen_out[ipt].fname,"a");
  }/*endifelse*/

/*==========================================================================*/
  fprintf(fp,"Initial intra        energy  %.10g\n",
                           general_data->stat_avg[ipt].vintrat*eu_conv);
  fprintf(fp,"Initial inter        energy  %.10g\n",
                           general_data->stat_avg[ipt].vintert*eu_conv);
  fprintf(fp,"Initial kinetic      energy  %.10g\n",
                           general_data->stat_avg[ipt].kinet*eu_conv);
  fprintf(fp,"Initial prim kinetic      energy  %.10g\n",
                           general_data->stat_avg[ipt].pi_ke_prim*eu_conv);
  fprintf(fp,"Initial vir kinetic      energy  %.10g\n",
                           general_data->stat_avg[ipt].pi_ke_vir*eu_conv);
  fprintf(fp,"Initial harm kinetic energy  %.10g\n",
                           general_data->stat_avg[ipt].kin_harm*eu_conv);
  if(class->energy_ctrl.isep_vvdw == 1) {
    fprintf(fp,"Initial VDW          energy  %.10g\n",
                           general_data->stat_avg[ipt].vvdw*eu_conv);
    fprintf(fp,"Initial Coul         energy  %.10g\n",
                           general_data->stat_avg[ipt].vcoul*eu_conv);
  }/*endif*/
  fprintf(fp,"Initial Bond         energy  %.10g\n",
                           general_data->stat_avg[ipt].vbondt*eu_conv);
  fprintf(fp,"Initial Bendbnd_bond energy  %.10g\n",
                           general_data->stat_avg[ipt].vbend_bnd_bond*eu_conv);
  fprintf(fp,"Initial Watts_bond energy  %.10g\n",
                           general_data->stat_avg[ipt].vbondt_watts*eu_conv);
  fprintf(fp,"Initial Total Bond   energy  %.10g\n",
                           (general_data->stat_avg[ipt].vbend_bnd_bond+
                            general_data->stat_avg[ipt].vbondt+
                            general_data->stat_avg[ipt].vbondt_watts)*eu_conv);
  fprintf(fp,"Initial Bend         energy  %.10g\n",
                           general_data->stat_avg[ipt].vbendt*eu_conv);
  fprintf(fp,"Initial Bendbnd_bend energy  %.10g\n",
                           general_data->stat_avg[ipt].vbend_bnd_bend*eu_conv);
  fprintf(fp,"Initial Watts_bend energy  %.10g\n",
                           general_data->stat_avg[ipt].vbendt_watts*eu_conv);
  fprintf(fp,"Initial Total Bend   energy  %.10g\n",
                           (general_data->stat_avg[ipt].vbend_bnd_bend+
                            general_data->stat_avg[ipt].vbendt+
                            general_data->stat_avg[ipt].vbendt_watts)*eu_conv);
  fprintf(fp,"Initial Torsion      energy  %.10g\n",
                                     general_data->stat_avg[ipt].vtorst*eu_conv);
  fprintf(fp,"Initial onefour      energy  %.10g\n",
                                     general_data->stat_avg[ipt].vonfot*eu_conv);
  fprintf(fp,"Initial surface      energy  %.10g\n",
                                     general_data->stat_avg[ipt].vsurft*eu_conv);
  fprintf(fp,"Initial volume               %.10g\n",general_data->stat_avg[ipt].vol
                                                  *BOHR*BOHR*BOHR);
  fprintf(fp,"Initial Atm temperature    %.10g\n",
            ((2.0*general_data->stat_avg[ipt].kinet*BOLTZ)/
           ((double)(class->clatoms_info.nfree_pimd)) ) );

/*==========================================================================*/
  /* NHC quantities                                                        */

    if(general_data->ensopts.nvt==1){
      nhc_div = (double) ( class->therm_info_class[ipt].len_nhc*
                          (class->therm_info_class[ipt].num_nhc) );
      if(nhc_div>0){
       fprintf(fp,"Initial NHC temperature %.10g\n", 
             ((2.0*general_data->stat_avg[ipt].kinet_nhc*BOLTZ)/nhc_div));
      }else{
       fprintf(fp,"Initial NHC temperature 0.0\n"); 
      }/*endif*/
      if(class->clatoms_info.pi_beads>1){
        nhc_div = (double) ( class->therm_info_bead[ipt].len_nhc*
                           (class->therm_info_bead[ipt].num_nhc)*
                           (class->clatoms_info.pi_beads-1) );
        fprintf(fp,"Initial bead NHC temperature %.10g\n", 
              ((2.0*general_data->stat_avg[ipt].kinet_nhc_bead*BOLTZ)/nhc_div));
      }/*endif*/
    }/*endif*/

    if(general_data->ensopts.npt_i==1){
      nhc_div = (double) ( class->therm_info_class[ipt].len_nhc*
                          (class->therm_info_class[ipt].num_nhc +1));
      fprintf(fp,"Initial NHC temperature %.10g\n", 
            ((2.0*general_data->stat_avg[ipt].kinet_nhc*BOLTZ)/nhc_div));
      if(class->clatoms_info.pi_beads>1){
       nhc_div = (double) ( class->therm_info_bead[ipt].len_nhc*
                           (class->therm_info_bead[ipt].num_nhc)*
                           (class->clatoms_info.pi_beads-1) );
       fprintf(fp,"Initial bead NHC temperature %.10g\n", 
             ((2.0*general_data->stat_avg[ipt].kinet_nhc_bead*BOLTZ)/nhc_div));
      }
      fprintf(fp,"Initial Volume temperature %.10g\n",
            (2.0*general_data->stat_avg[ipt].kinet_v*BOLTZ)); 
    }/*endif*/

    if(general_data->ensopts.npt_f==1){
      nhc_div = (double) ( class->therm_info_class[ipt].len_nhc*
                          (class->therm_info_class[ipt].num_nhc +1));
      fprintf(fp,"Initial NHC temperature %.10g\n", 
            ((2.0*general_data->stat_avg[ipt].kinet_nhc*BOLTZ)/nhc_div));
      if(class->clatoms_info.pi_beads>1){
       nhc_div = (double) ( class->therm_info_bead[ipt].len_nhc*
                           (class->therm_info_bead[ipt].num_nhc)*
                           (class->clatoms_info.pi_beads-1) );
       fprintf(fp,"Initial bead NHC temperature %.10g\n", 
             ((2.0*general_data->stat_avg[ipt].kinet_nhc_bead*BOLTZ)/nhc_div));
      }
      fprintf(fp,"Initial Volume temperature %.10g\n",      
            ((2.0*general_data->stat_avg[ipt].kinet_v*BOLTZ)/9.0));
    }/*endif*/

/*==========================================================================*/
  /* Neighbor list quantities                                              */

    if((class->nbr_list.iver)==1){
      npairs = class->nbr_list.verlist[ipt].nver_lst_now;
      np_tot = (class->clatoms_info.natm_tot)*
               (class->clatoms_info.natm_tot-1)/2 
       - (bonded->excl.nlst);
      fprintf(fp,"Number of pairs = %d out of %d\n",npairs,np_tot);
      if(general_data->timeinfo.int_res_ter==1){
       npairs = class->nbr_list.verlist[ipt].nver_lst_now_res;
       fprintf(fp,"Number RESPA pairs = %d out of %d\n",npairs,np_tot);
      }/*endif*/
    }/*endif*/

    if((class->nbr_list.ilnk)==1){
      nsh_tot = ((class->nbr_list.lnklist[ipt].ncell_a)*
                 (class->nbr_list.lnklist[ipt].ncell_b)*
                 (class->nbr_list.lnklist[ipt].ncell_c)-1)/2 +
                 (((class->nbr_list.lnklist[ipt].ncell_a)*
                   (class->nbr_list.lnklist[ipt].ncell_b)*
                   (class->nbr_list.lnklist[ipt].ncell_c)-1) % 2) + 1;
      fprintf(fp,"ncell_a = %d, ncell_b = %d, ncell_c = %d natm_cell_max %d \n",
            class->nbr_list.lnklist[ipt].ncell_a,class->nbr_list.lnklist[ipt].ncell_b,
            class->nbr_list.lnklist[ipt].ncell_c,
            class->nbr_list.lnklist[ipt].natm_cell_max);
      fprintf(fp,"# of shifts = %d out of %d\n",
            class->nbr_list.lnklist[ipt].nshft_lnk,nsh_tot);
      if(general_data->timeinfo.int_res_ter==1){
       fprintf(fp,"# of respa shifts = %d out of %d\n",
              class->nbr_list.lnklist[ipt].nshft_lnk_res,nsh_tot);
      }/*endif*/
    }/*endif*/

  fflush(fp);
  if(npara_temps>1){
    fclose(fp);
  }/*endifelse*/

/*==========================================================================*/
}/* end routine */
/*==========================================================================*/



/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void initial_fopen_pimd(CLASS *class,GENERAL_DATA *general_data,BONDED *bonded,
			int ipt)

/*==========================================================================*/

{/* begin routine */
/*==========================================================================*/
/*   Local Variables                                                        */
  /*  int ipt=1;*/

  int iptoff = ipt + general_data->tempering_ctrl.npara_temps_proc_off;
  int n=1,iii,ibinary,iwrite_now,ifound;
  NAME file_typ;
  FILE *fp_bond_free,*fp_bend_free,*fp_tors_free;
  FILE *fp_iname, *fp_cpname, *fp_cvname,*fp_dname,*fp_centname;
  FILE *fp_rbar_free,*fscreen,*fp_temper;
  NAME tname;
  int  npara_temps      = general_data->simopts.npara_temps; 


/*==========================================================================*/
/*     A) Open dump file                                          */
  if(iptoff==1 && npara_temps > 1){
    fp_temper = cfopen(general_data->tempering_ctrl.history_name,"w");
    fclose(fp_temper);
    fp_temper = cfopen(general_data->tempering_ctrl.wgt_name,"w");
    fclose(fp_temper);
    fp_temper = cfopen(general_data->tempering_ctrl.troyer_name,"w");
    fclose(fp_temper);
  }/*endif intial temper fopen*/

  if(npara_temps>1){
    sprintf(tname,"%s.%d",general_data->filenames.dname,iptoff);
  }else{
    strcpy(tname,general_data->filenames.dname);
  }/*endif*/
  
  fp_dname = cfopen(tname,"w");
  fclose(fp_dname);

/*==========================================================================*/
/*     A) Open inst avg file                                          */
  if(npara_temps>1){
    sprintf(tname,"%s.%d",general_data->filenames.iname,iptoff);
  }else{
    strcpy(tname,general_data->filenames.iname);
  }/*endif*/

  ibinary    = 0; /* never binary */
  iwrite_now = general_data->filenames.iwrite_inst;
  strcpy(file_typ,"ins_file");
  fp_iname   = cfopen(tname,"w");
  write_gen_header(class,general_data,fp_iname,ibinary,
                   iwrite_now,file_typ,ipt);
  fclose(fp_iname);

/*==========================================================================*/
/*     B) Open atm vel conf file                                       */
  if(npara_temps>1){
    sprintf(tname,"%s.%d",general_data->filenames.cvname,iptoff);
  }else{
    strcpy(tname,general_data->filenames.cvname);
  }/*endif*/

  ibinary    = general_data->filenames.iwrite_conf_binary;
  iwrite_now = general_data->filenames.iwrite_confv;
  strcpy(file_typ,"vel_file");
  fp_cvname  = cfopen(tname,"w");
  write_gen_header(class,general_data,fp_cvname,ibinary,
                   iwrite_now,file_typ,ipt);
  fclose(fp_cvname); 

/*==========================================================================*/
/*     C) Open pos conf file                                           */
  if(npara_temps>1){
    sprintf(tname,"%s.%d",general_data->filenames.cpname,iptoff);
  }else{
    strcpy(tname,general_data->filenames.cpname);
  }/*endif*/

  ibinary    = general_data->filenames.iwrite_conf_binary;
  iwrite_now = general_data->filenames.iwrite_confp;
  strcpy(file_typ,"pos_file");
  fp_cpname  = cfopen(tname,"w");
  write_gen_header(class,general_data,fp_cpname,ibinary,
                   iwrite_now,file_typ,ipt);
  fclose(fp_cpname); 

/*======================================================================*/
/*     C) Open partial pos conf file                                    */
  if(npara_temps>1){
    sprintf(tname,"%s.%d",general_data->filenames.cpparname,iptoff);
  }else{
    strcpy(tname,general_data->filenames.cpparname);
  }/*endif*/

 if((general_data->filenames.low_lim_par<=general_data->filenames.high_lim_par)){
   ibinary    = general_data->filenames.iwrite_conf_binary;
   iwrite_now = general_data->filenames.iwrite_par_confp;
   strcpy(file_typ,"par_file");
   fp_cpname = cfopen(tname,"w"); 
   write_gen_header(class,general_data,fp_cpname,ibinary,
                   iwrite_now,file_typ,ipt);
   fclose(fp_cpname); 
 }/*endif*/

/*==========================================================================*/
/*     C) Open centroid conf file                                           */
  if(npara_temps>1){
    sprintf(tname,"%s.%d",general_data->filenames.centname,iptoff);
  }else{
    strcpy(tname,general_data->filenames.centname);
  }/*endif*/

  ibinary    = general_data->filenames.iwrite_conf_binary;
  iwrite_now = general_data->filenames.iwrite_path_cent;
  strcpy(file_typ,"cen_file");
  fp_centname  = cfopen(tname,"w");
  write_gen_header(class,general_data,fp_centname,ibinary,
                   iwrite_now,file_typ,ipt);
  fclose(fp_centname); 

/*==========================================================================*/
/*     E) Open bond free energy file                                   */

    if(bonded->bond_free[ipt].num>0){
      fp_bond_free  = cfopen(bonded->bond_free[ipt].file,"w");
      fclose(fp_bond_free);
    }/*endif*/

/*==========================================================================*/
/*     F) Open bend free energy file                                    */

    if(bonded->bend_free[ipt].num>0){
      fp_bend_free  = cfopen(bonded->bend_free[ipt].file,"w");
      fclose(fp_bend_free);
    }/*endif*/

/*==========================================================================*/
/*     G) Open tors free energy file                                    */

    if(bonded->tors_free[ipt].num>0){
      fp_tors_free  = cfopen(bonded->tors_free[ipt].file,"w");
      fclose(fp_tors_free);
    }/*endif*/
    
/*==========================================================================*/
/*     H) Open rbar_sig free energy file                                    */

    if(bonded->rbar_sig_free[ipt].nfree>0){
      fp_rbar_free  = cfopen(bonded->rbar_sig_free[ipt].file,"w");
      fclose(fp_rbar_free);
    }/*endif*/
    
/*==========================================================================*/
/*     I) Open and close || temp screen files                               */
    if(npara_temps>1){
      fscreen  = cfopen(general_data->tempering_screen_out[ipt].fname,"w");
      fclose(fscreen);
    }/*endif*/
    
/*==========================================================================*/
}/* end routine */
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void dink_quant_calc_pimd(CLASS *class, GENERAL_DATA *general_data,double *etot,
                        double *econv_now,double *vtot, double *avtot,
                        double *deth,double *pnow, double *apnow,
                        double *pnow_inter, double *apnow_inter,
                        double *pnow_intra, double *apnow_intra,
                        double *pnow_kin, double *apnow_kin,
                        double *nhc_div,double *nhc_div_bead,int ipt)

/*==========================================================================*/

{/* begin routine */
  /*  int ipt=1;*/

  int i,iii;

/*==========================================================================*/
 /*  Energy */

    (*etot) = (general_data->stat_avg[ipt].kinet) + (general_data->stat_avg[ipt].vintert) 
            + (general_data->stat_avg[ipt].vintrat) + (general_data->stat_avg[ipt].kin_harm);
      if((general_data->ensopts.nvt)==1)  
       {(*etot)     += (general_data->stat_avg[ipt].kinet_nhc) +
             (general_data->stat_avg[ipt].kinet_nhc_bead) 
          + (general_data->stat_avg[ipt].vpotnhc);}
      if((general_data->ensopts.npt_i)==1)
       {(*etot)     += (general_data->stat_avg[ipt].kinet_nhc)  
           + (general_data->stat_avg[ipt].kinet_nhc_bead) 
          + (general_data->stat_avg[ipt].vpotnhc)
            + (general_data->stat_avg[ipt].kinet_v)   
              + (general_data->stat_avg[ipt].vpot_v);}
      if((general_data->ensopts.npt_f)==1)
       {(*etot)+= (general_data->stat_avg[ipt].kinet_nhc) 
           + (general_data->stat_avg[ipt].kinet_nhc_bead) 
          + (general_data->stat_avg[ipt].vpotnhc)
            + (general_data->stat_avg[ipt].kinet_v)   
              + (general_data->stat_avg[ipt].vpot_v);}
      if(((general_data->ensopts.npt_i+general_data->ensopts.npt_f)==1)&&
          (general_data->stat_avg[ipt].iswit_vdw<=0))
          {(*etot)+= (general_data->stat_avg[ipt].vlong);}
      (*econv_now) = fabs((*etot)-general_data->stat_avg[ipt].econv0)/
       fabs(general_data->stat_avg[ipt].econv0);
 /*==========================================================================*/
 /*  Volume and pressure                                                    */

      (*vtot) = general_data->stat_avg[ipt].vintert + general_data->stat_avg[ipt].vintrat;
      (*avtot) = general_data->stat_avg[ipt].avintert + general_data->stat_avg[ipt].avintrat;
      (*deth) = getdeth(general_data->cell.hmat);
      for(i=1;i<=9;i++){
       general_data->stat_avg[ipt].apten_out[i]=(general_data->ptens[ipt].pvten_tot[i]
                                  +general_data->ptens[ipt].tvten[i])/((*deth)*PCONV);}
      (*pnow)  = (general_data->stat_avg[ipt].apten_out[1]
              +  general_data->stat_avg[ipt].apten_out[5]
              +  general_data->stat_avg[ipt].apten_out[9])/(3.0);
      (*apnow) =  general_data->stat_avg[ipt].apress
       /(PCONV*((double)(general_data->timeinfo.itime)));
      (*pnow_inter)  = general_data->stat_avg[ipt].press_inter/PCONV;
      (*apnow_inter) = general_data->stat_avg[ipt].apress_inter
                           /(PCONV*((double)(general_data->timeinfo.itime)));
      (*pnow_intra)  = general_data->stat_avg[ipt].press_intra/PCONV;
      (*apnow_intra) = general_data->stat_avg[ipt].apress_intra
                           /(PCONV*((double)(general_data->timeinfo.itime)));
      (*pnow_kin)  = general_data->stat_avg[ipt].press_kin/PCONV;
      (*apnow_kin) = general_data->stat_avg[ipt].apress_kin
                           /(PCONV*((double)(general_data->timeinfo.itime)));
 /*==========================================================================*/
 /*  NHC degrees of freedom                                                  */

      (*nhc_div) = (double)((class->therm_info_class[ipt].len_nhc)*
                   (class->therm_info_class[ipt].num_nhc));
      if(general_data->ensopts.npt_f == 1 || general_data->ensopts.npt_i == 1){
       (*nhc_div) = (double) (class->therm_info_class[ipt].len_nhc*
                           (class->therm_info_class[ipt].num_nhc +1) );
      }/*endif*/
      if(class->clatoms_info.pi_beads>1){
        *nhc_div_bead = (double) ( class->therm_info_bead[ipt].len_nhc*
                           (class->therm_info_bead[ipt].num_nhc)*
                           (class->clatoms_info.pi_beads-1) );
      }/*endif*/

/*==========================================================================*/
}/* end routine */
/*==========================================================================*/



/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void screen_write_pimd(CLASS *class,GENERAL_DATA *general_data,BONDED *bonded,
                     double etot,double econv_now,double vtot, 
                   double avtot,double deth,double pnow, double apnow,
                     double pnow_inter, double apnow_inter,
                     double pnow_intra, double apnow_intra,
                     double pnow_kin, double apnow_kin,
                     double nhc_div,double nhc_div_bead,
                     double a,double b,double c,
                   double tab,double tbc,double tac,int ipt)


/*==========================================================================*/
{/* begin routine */
  /* int ipt=1;*/

 int npairs,iii;
 int iptoff = ipt + general_data->tempering_ctrl.npara_temps_proc_off;
 int  npara_temps_proc  = general_data->tempering_ctrl.npara_temps_proc;
 double dpi_beads = (double)class->clatoms_info.pi_beads;
 double atime,vol_div,atm_div;
 double updates_t,updates_true,updates_now; 
 double eu_conv=1.0;
  NAME tname;
  int  npara_temps      = general_data->simopts.npara_temps; 
  FILE *fp;

/*==========================================================================*/
/* Write to screen                                                          */

      atime = (double)(general_data->timeinfo.itime);
      if(general_data->filenames.iwrite_units==0){eu_conv=1.0;}
      if(general_data->filenames.iwrite_units==1){eu_conv=KCAL;}
      if(general_data->filenames.iwrite_units==2){eu_conv=BOLTZ;}
/*=======================================================================*/
/* switch for || temping yes/no */

  if(npara_temps==1){
    fp=stdout;
  }else{
    fp = cfopen(general_data->tempering_screen_out[ipt].fname,"a");
  }/*endifelse*/

/*==========================================================================*/
/*     A) Standard                                                   */
  fprintf(fp,"\n");
  fprintf(fp,"********************************************************\n");
  fprintf(fp,"QUANTITY          =  INSTANTANEOUS    AVERAGE           \n");
  fprintf(fp,"--------------------------------------------------------\n");
  if(general_data->ensopts.nve==1)  fprintf(fp,"Ensemble          = NVE     \n");
  if(general_data->ensopts.nvt==1)  fprintf(fp,"Ensemble          = NVT     \n");
  if(general_data->ensopts.npt_i==1)fprintf(fp,"Ensemble          = NPT-ISO \n");
  if(general_data->ensopts.npt_f==1)fprintf(fp,"Ensemble          = NPT-FLEX\n");
  fprintf(fp,"Time step         = %d\n",(general_data->timeinfo.itime));
  if(npara_temps>1){  fprintf(fp,"Temperer index    = %d\n",iptoff);}
  fprintf(fp,"----------------- \n");
  fprintf(fp,"Econv             = %.10g %.10g\n",( econv_now ),
        ( general_data->stat_avg[ipt].econv/atime));
  fprintf(fp,"Energy            = %.10g %.10g\n",(general_data->stat_avg[ipt].kinet+vtot)*eu_conv,
        (general_data->stat_avg[ipt].akinet+avtot)/atime*eu_conv);
  fprintf(fp,"Total PE          = %.10g %.10g\n",(vtot)*eu_conv,(avtot/atime)*eu_conv);
  fprintf(fp,"Intermol PE       = %.10g %.10g\n",(general_data->stat_avg[ipt].vintert)*eu_conv,
        (general_data->stat_avg[ipt].avintert/atime)*eu_conv);
  fprintf(fp,"Intramol PE       = %.10g %.10g\n",(general_data->stat_avg[ipt].vintrat)*eu_conv,
        (general_data->stat_avg[ipt].avintrat/atime)*eu_conv);
  fprintf(fp,"Fict. Atm KE      = %.10g %.10g\n",(general_data->stat_avg[ipt].kinet/dpi_beads)*eu_conv,
        (general_data->stat_avg[ipt].akinet/(atime*dpi_beads))*eu_conv);
  fprintf(fp,"Prim KE           = %.10g %.10g\n",(general_data->stat_avg[ipt].pi_ke_prim)*eu_conv,
        (general_data->stat_avg[ipt].api_ke_prim/atime)*eu_conv);
  fprintf(fp,"Vir KE            = %.10g %.10g\n",(general_data->stat_avg[ipt].pi_ke_vir)*eu_conv,
        (general_data->stat_avg[ipt].api_ke_vir/atime)*eu_conv);
  fprintf(fp,"----------------- \n");
  atm_div = (double)(class->clatoms_info.nfree);
  fprintf(fp,"Atm Deg. Free     = %.10g\n",atm_div); 
  atm_div = (double)(class->clatoms_info.nfree_pimd);
  fprintf(fp,"Beads              = %g\n",dpi_beads); 
  fprintf(fp,"Bead Deg. Free     = %.10g\n",atm_div); 
  fprintf(fp,"Fict. Atm Temperature   = %.10g %.10g \n",
        (general_data->stat_avg[ipt].kinet*2.0*BOLTZ/(atm_div)),
        (general_data->stat_avg[ipt].akinet*2.0*BOLTZ/(atm_div*atime)));
  
/*==========================================================================*/
/*     B) Extended Class                                          */
      if((general_data->ensopts.nvt + general_data->ensopts.npt_i
         + general_data->ensopts.npt_f == 1) && (general_data->simopts.pimd==1)){
       if(nhc_div>0){
        fprintf(fp,"NHC Temperature   = %.10g %.10g\n",
               (general_data->stat_avg[ipt].kinet_nhc*2.0*BOLTZ/nhc_div),
               (general_data->stat_avg[ipt].akinet_nhc*2.0*BOLTZ
               /(nhc_div*atime)));
       }else{
        fprintf(fp,"NHC Temperature   = 0.0 0.0\n");
       }/*endif*/
        if(class->clatoms_info.pi_beads){
       fprintf(fp,"Bead NHC Temperature   = %.10g %.10g\n",
              (general_data->stat_avg[ipt].kinet_nhc_bead*2.0*BOLTZ/nhc_div_bead),
              (general_data->stat_avg[ipt].akinet_nhc_bead*2.0*BOLTZ
              /(nhc_div_bead*atime)));
      }
      }
      if((general_data->ensopts.npt_i +general_data->ensopts.npt_f == 1) && 
        (general_data->simopts.pimd==1)) {
        vol_div = 1.0;
        if(general_data->ensopts.npt_f == 1) vol_div = 6.0;
       fprintf(fp,"Vol Temperature   = %.10g %.10g\n",
              (general_data->stat_avg[ipt].kinet_v*2.0*BOLTZ/vol_div),
              (general_data->stat_avg[ipt].akinet_v*2.0*BOLTZ/(atime*vol_div)));}
        fprintf(fp,"----------------- \n");
/*==========================================================================*/
/*     C)Pressure/Vol                                                */
      if(general_data->cell.iperd>=2){
       fprintf(fp,"Pressure          = %.10g %.10g\n",(pnow),( apnow));
       fprintf(fp,"Inter Pressure    = %.10g %.10g\n",(pnow_inter),( apnow_inter));
       fprintf(fp,"Intra Pressure    = %.10g %.10g\n",(pnow_intra),( apnow_intra));
       fprintf(fp,"Kinetic Pressure  = %.10g %.10g\n",(pnow_kin),( apnow_kin));
       fprintf(fp,"Avg  P11,P22,P33  = %.10g %.10g %.10g \n",
              general_data->stat_avg[ipt].apten[1]/(PCONV*atime),
              general_data->stat_avg[ipt].apten[5]/(PCONV*atime),
              general_data->stat_avg[ipt].apten[9]/(PCONV*atime));
       fprintf(fp,"Inst P11,P22,P33  = %.10g %.10g %.10g \n",
              general_data->stat_avg[ipt].apten_out[1],
              general_data->stat_avg[ipt].apten_out[5],
              general_data->stat_avg[ipt].apten_out[9]);
       fprintf(fp,"Avg  P12,P13,P23  = %.10g %.10g %.10g \n",
              general_data->stat_avg[ipt].apten[4]/(PCONV*atime),
              general_data->stat_avg[ipt].apten[7]/(PCONV*atime),
              general_data->stat_avg[ipt].apten[8]/(PCONV*atime));
       fprintf(fp,"Inst P12,P13,P23  = %.10g %.10g %.10g \n",
              general_data->stat_avg[ipt].apten_out[4],
              general_data->stat_avg[ipt].apten_out[7],
              general_data->stat_avg[ipt].apten_out[8]);
       fprintf(fp,"Avg  P21,P31,P32  = %.10g %.10g %.10g \n",
              general_data->stat_avg[ipt].apten[2]/(PCONV*atime),
              general_data->stat_avg[ipt].apten[3]/(PCONV*atime),
              general_data->stat_avg[ipt].apten[6]/(PCONV*atime));
       fprintf(fp,"Inst P21,P31,P32  = %.10g %.10g %.10g \n",
              general_data->stat_avg[ipt].apten_out[2],
              general_data->stat_avg[ipt].apten_out[3],
              general_data->stat_avg[ipt].apten_out[6]);
       fprintf(fp,"----------------- \n");
       fprintf(fp,"Volume            = %.10g %.10g\n",(deth*BOHR*BOHR*BOHR),
              (general_data->stat_avg[ipt].avol/atime)*BOHR*BOHR*BOHR);
       /*          if (a<b ){fprintf(fp,"Volume (Upper h)  = %.10g %.10g\n",(deth),
                  (general_data->stat_avg[ipt].avol/atime));}
                  if (a>=b){fprintf(fp,"Volume (Upper h)  = %.10g %.10g\n",(deth),
                  (general_data->stat_avg[ipt].avol/atime));}      */
       fprintf(fp,"Inst cell lths    = %.10g %.10g %.10g\n",(a),(b),(c));
       fprintf(fp,"Avg  cell lths    = %.10g %.10g %.10g\n",    
              (general_data->stat_avg[ipt].acella/atime),
              (general_data->stat_avg[ipt].acellb/atime),
              (general_data->stat_avg[ipt].acellc/atime));
       fprintf(fp,"Inst cell angs    = %.10g %.10g %.10g\n",(tab),(tac),(tbc));
       fprintf(fp,"Avg  cell angs    = %.10g %.10g %.10g\n",
              (general_data->stat_avg[ipt].acellab/atime),
              (general_data->stat_avg[ipt].acellac/atime),
              (general_data->stat_avg[ipt].acellbc/atime));
       fprintf(fp,"----------------- \n");
      }/*endif*/

/*==========================================================================*/
/*     D)Constraint                                                  */
  if(bonded->constrnt.iconstrnt == 1) {
    if(general_data->simopts.pimd==1){
      if(bonded->bond.ncon > 0) {
       fprintf(fp,"Shake iter        = %.10g %.10g\n",
              (double)(general_data->stat_avg[ipt].iter_shake),
              (general_data->stat_avg[ipt].aiter_shake/atime));
       fprintf(fp,"Rattle iter       = %.10g %.10g\n",
              (double)(general_data->stat_avg[ipt].iter_ratl),
              (general_data->stat_avg[ipt].aiter_ratl/atime));
      }
      if(bonded->grp_bond_con.num_21 > 0) {
       fprintf(fp,"Grp_21 shake iter = %.10g %.10g\n",
              general_data->stat_avg[ipt].iter_21,
              general_data->stat_avg[ipt].aiter_21/atime);
       fprintf(fp,"Grp_21 ratl iter = %.10g %.10g\n",
              general_data->stat_avg[ipt].iter_21r,
              general_data->stat_avg[ipt].aiter_21r/atime);
      }
      if(bonded->grp_bond_con.num_23 > 0) {
       fprintf(fp,"Grp_23 shake iter = %.10g %.10g\n",
              general_data->stat_avg[ipt].iter_23,
              general_data->stat_avg[ipt].aiter_23/atime);
       fprintf(fp,"Grp_23 ratl iter = %.10g %.10g\n",
              general_data->stat_avg[ipt].iter_23r,
              general_data->stat_avg[ipt].aiter_23r/atime);
      }
      if(bonded->grp_bond_con.num_33 > 0) {
       fprintf(fp,"Grp_33 shake iter = %.10g %.10g\n",
              general_data->stat_avg[ipt].iter_33,
              general_data->stat_avg[ipt].aiter_33/atime);
       fprintf(fp,"Grp_33 ratl iter = %.10g %.10g\n",
              general_data->stat_avg[ipt].iter_33r,
              general_data->stat_avg[ipt].aiter_33r/atime);
      }
      if(bonded->grp_bond_con.num_43 > 0) {
       fprintf(fp,"Grp_43 shake iter = %.10g %.10g\n",
              general_data->stat_avg[ipt].iter_43,
              general_data->stat_avg[ipt].aiter_43/atime);
       fprintf(fp,"Grp_43 ratl iter = %.10g %.10g\n",
              general_data->stat_avg[ipt].iter_43r,
              general_data->stat_avg[ipt].aiter_43r/atime);
      }
      if(bonded->grp_bond_con.num_46 > 0) {
       fprintf(fp,"Grp_46 shake iter = %.10g %.10g\n",
              general_data->stat_avg[ipt].iter_46,
              general_data->stat_avg[ipt].aiter_46/atime);
       fprintf(fp,"Grp_46 ratl iter = %.10g %.10g\n",
              general_data->stat_avg[ipt].iter_46r,
              general_data->stat_avg[ipt].aiter_46r/atime);
      }
      fprintf(fp,"----------------- \n");
    }/*endif*/
  }/*endif*/
  
/*==========================================================================*/
/*     D)Misc                                                         */

      if(class->nbr_list.iver == 1){
         updates_t = general_data->stat_avg[ipt].updates;
         if(updates_t == 0) updates_t = 1;
         updates_now = (double ) (general_data->timeinfo.itime-
                              general_data->stat_avg[ipt].itime_update);
          updates_true = updates_t;
          npairs = class->nbr_list.verlist[ipt].nver_lst_now;
          fprintf(fp,"Inst steps/update = %.10g\n",updates_now);
          fprintf(fp,"Avg. steps/update = %.10g\n",(atime/updates_t));
          fprintf(fp,"Total list updates= %.10g\n",updates_true);
          fprintf(fp,"Number of pairs   = %d \n",npairs);
          if(general_data->timeinfo.int_res_ter==1){
            npairs = class->nbr_list.verlist[ipt].nver_lst_now_res;
          fprintf(fp,"Inst steps/update = %.10g\n",updates_now);
            fprintf(fp,"Number RESPA pairs= %d \n",npairs);
          }/*endif*/
         fprintf(fp,"----------------- \n");
      }/*endif*/
      fprintf(fp,"Cpu time          = %.10g %.10g\n",
            (general_data->stat_avg[ipt].cpu_now),
            (general_data->stat_avg[ipt].acpu/atime));
      fprintf(fp,"--------------------------------------------------------\n");
      fprintf(fp,"\n"); 
      fprintf(fp,"********************************************************\n");
      fflush(fp);

/*==========================================================================*/

  if(npara_temps>1){fclose(fp);}
  if(iptoff==npara_temps_proc && npara_temps>1){
    printf("All temperers completed time step %d (a small lie in parallel).\n",
	   general_data->timeinfo.itime);
  }/*endif*/

/*==========================================================================*/
}/* end routine */
/*==========================================================================*/

/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void write_dump_file_pimd(CLASS *class,BONDED *bonded,GENERAL_DATA *general_data,
			  int ipt)

/*==========================================================================*/
{/* begin routine */
  /*  int ipt=1;*/

 int i,j,ip,ipp,iii;
 int iptoff = ipt + general_data->tempering_ctrl.npara_temps_proc_off;
 int pi_beads = class->clatoms_info.pi_beads;
 int pi_beads_proc = class->clatoms_info.pi_beads_proc;

 double deth;
 FILE *fp_dname;
 NAME tname;
 int  npara_temps      = general_data->simopts.npara_temps; 

/*==========================================================================*/
/* Open dump file                                                           */
  if(npara_temps>1){
    sprintf(tname,"%s.%d",general_data->filenames.dname,iptoff);
  }else{
    strcpy(tname,general_data->filenames.dname);
  }/*endif*/

  fp_dname = cfopen(tname,"o");

/*==========================================================================*/
/*     A)Atm positions                                               */

      fprintf(fp_dname,"natm_tot restart_typ itime pi_beads ipt\n");
      fprintf(fp_dname,"%d restart_all %d %d %d\n",class->clatoms_info.natm_tot,
             general_data->timeinfo.itime,pi_beads,iptoff);
      fprintf(fp_dname,"atm pos, atm_typ, mol_typ mol_num\n");
      for(ipp=1;ipp<=pi_beads;ipp++){
       for(i=1;i<=class->clatoms_info.natm_tot;i++){
	 ip=ipp + pi_beads*(ipt-1);
	 fprintf(fp_dname,"%.13g %.13g %.13g %s %s %s %d\n",
		 class->clatoms_tmp[ip].x[i],class->clatoms_tmp[ip].y[i],
		 class->clatoms_tmp[ip].z[i],
              class->atommaps.atm_typ[class->atommaps.iatm_atm_typ[i]],
              class->atommaps.res_typ[class->atommaps.iatm_res_typ[i]],
              class->atommaps.mol_typ[class->atommaps.iatm_mol_typ[i]],
              class->atommaps.iatm_mol_num[i]);
       }/*endfor*/
      }/*endfor*/

/*==========================================================================*/
/*     B)Cell shape                                                 */

      if(general_data->ensopts.npt_i==0){
       deth = getdeth(general_data->cell.hmat);
       general_data->baro.x_lnv = log(deth)/3.0;
       general_data->baro.v_lnv = (general_data->par_rahman.vgmat[1]
                           + general_data->par_rahman.vgmat[5]
                           + general_data->par_rahman.vgmat[9])/3.0;
      }/*endif*/

      fprintf(fp_dname,"h matrix\n");
      fprintf(fp_dname,"%.13g %.13g %.13g\n",general_data->cell.hmat[1],
             general_data->cell.hmat[4],general_data->cell.hmat[7]);
      fprintf(fp_dname,"%.13g %.13g %.13g\n",general_data->cell.hmat[2],
             general_data->cell.hmat[5],general_data->cell.hmat[8]);
      fprintf(fp_dname,"%.13g %.13g %.13g\n",general_data->cell.hmat[3],
             general_data->cell.hmat[6],general_data->cell.hmat[9]);
      fprintf(fp_dname,"h matrix for Ewald setup\n");
      fprintf(fp_dname,"%.13g %.13g %.13g\n",general_data->cell.hmat_ewd[1],
             general_data->cell.hmat_ewd[4],general_data->cell.hmat_ewd[7]);
      fprintf(fp_dname,"%.13g %.13g %.13g\n",general_data->cell.hmat_ewd[2],
             general_data->cell.hmat_ewd[5],general_data->cell.hmat_ewd[8]);
      fprintf(fp_dname,"%.13g %.13g %.13g\n",general_data->cell.hmat_ewd[3],
             general_data->cell.hmat_ewd[6],general_data->cell.hmat_ewd[9]);
      fprintf(fp_dname,"1/3 log(Vol)\n");
      fprintf(fp_dname,"%.13g\n",general_data->baro.x_lnv);

/*==========================================================================*/
/*    B.5)PT restart shanannigns                                            */

      if(npara_temps>1){
	fprintf(fp_dname,"origin direction troyer_left troyer_right\n");

        ip=1 + (ipt-1)*pi_beads_proc;
	fprintf(fp_dname,"%d %d %.10g %.10g\n",
		class->clatoms_pos[ip].origin,
		class->clatoms_pos[ip].idirect,
		general_data->stat_avg[ipt].ndirect[1],
		general_data->stat_avg[ipt].ndirect[2]);
      }/*end if*/

/*==========================================================================*/
/*    C)Atm and Atm NHC Velocities                                   */

      fprintf(fp_dname,"atm vel\n");
      for(ipp=1;ipp<=pi_beads;ipp++){
	ip=ipp + pi_beads*(ipt-1);
       for(i=1;i<=class->clatoms_info.natm_tot;i++){
       fprintf(fp_dname,"%.13g %.13g %.13g\n",class->clatoms_tmp[ip].vx[i],
              class->clatoms_tmp[ip].vy[i],class->clatoms_tmp[ip].vz[i]);
       }/*endfor*/
      }/*endfor*/
      
      fprintf(fp_dname,"number of atm nhc, length of nhc\n");
      fprintf(fp_dname,"%d %d\n",class->therm_info_class[ipt].num_nhc,
             class->therm_info_class[ipt].len_nhc);
      fprintf(fp_dname,"atm nhc velocities\n");
      for(j=1;j<=(class->therm_info_class[ipt].len_nhc);j++){
       for(i=1;i<=(class->therm_info_class[ipt].num_nhc);i++){
         fprintf(fp_dname,"%.13g\n",class->therm_class[ipt].v_nhc[j][i]);
       } /*endfor*/
      }/*endfor*/

      fprintf(fp_dname,"number of bead nhc, length of nhc\n");
      fprintf(fp_dname,"%d %d\n",class->therm_info_bead[ipt].num_nhc,
             class->therm_info_bead[ipt].len_nhc);
      fprintf(fp_dname,"bead nhc velocities\n");
      for(ipp=2;ipp<=pi_beads;ipp++){
	ip=ipp + pi_beads*(ipt-1);
        for(j=1;j<=(class->therm_info_bead[ipt].len_nhc);j++){
        for(i=1;i<=(class->therm_info_bead[ipt].num_nhc);i++){
          fprintf(fp_dname,"%.10g\n",class->clatoms_tmp[ip].v_nhc[j][i]);
        } /*endfor*/
        }/*endfor*/
      }/*endfor*/
/*==========================================================================*/
/*    D)Vol and Vol NHC Velocities                             */

      fprintf(fp_dname,"vol velocities\n");
      fprintf(fp_dname,"%.13g %.13g %.13g\n",general_data->par_rahman.vgmat[1],
             general_data->par_rahman.vgmat[4],general_data->par_rahman.vgmat[7]);
      fprintf(fp_dname,"%.13g %.13g %.13g\n",general_data->par_rahman.vgmat[2],
             general_data->par_rahman.vgmat[5],general_data->par_rahman.vgmat[8]);
      fprintf(fp_dname,"%.13g %.13g %.13g\n",general_data->par_rahman.vgmat[3],
             general_data->par_rahman.vgmat[6],general_data->par_rahman.vgmat[9]);
      fprintf(fp_dname,"log(vol) velocity\n");
      fprintf(fp_dname,"%.13g\n",general_data->baro.v_lnv);
      fprintf(fp_dname,"vol nhc velocities\n");
      for(i=1;i<=(class->therm_info_class[ipt].len_nhc);i++){
       fprintf(fp_dname,"%.13g\n",general_data->baro.v_vol_nhc[i]);
      }/*endfor*/
/*==========================================================================*/
/*    E)Misc                                                    */

      fprintf(fp_dname,"dt=%.13g\n",general_data->timeinfo.dt);
      fprintf(fp_dname,"nfree=%d\n",class->clatoms_info.nfree);
      fprintf(fp_dname,"nve=%d nvt=%d npt_i=%d npt_f=%d nst=%d\n",
             general_data->ensopts.nve,  general_data->ensopts.nvt,  
             general_data->ensopts.npt_i,  general_data->ensopts.npt_f,  
             general_data->ensopts.nst);
      fprintf(fp_dname,"nbond_free=%d nbend_free=%d ntors_free=%d\n",
             bonded->bond_free[ipt].num,bonded->bend_free[ipt].num,  
             bonded->tors_free[ipt].num);
      fprintf(fp_dname,"t_ext=%.13g,pext=%.13g,stens_ext=%.13g\n",
             general_data->statepoint[ipt].t_ext,
             general_data->statepoint[ipt].pext,
             general_data->statepoint[ipt].stens_ext);
/*==========================================================================*/
/*    F)CLose                                                               */

      fflush(fp_dname); 
      iii=fclose(fp_dname); 
      if(iii!=0){
        printf("@@@@@@@@@@@@@@@@@@@@_error_@@@@@@@@@@@@@@@@@@@@\n");
        printf("ERROR: can't close \"%s\" for writing (exiting) at %d\n",
                 general_data->filenames.dname,general_data->timeinfo.itime);
        printf("@@@@@@@@@@@@@@@@@@@@_error_@@@@@@@@@@@@@@@@@@@@\n");
        fflush(stdout);
        exit(1);
      }

/*==========================================================================*/
}/* end routine */
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void write_free_energy_file_pimd(CLASS *class,BONDED *bonded,
                                 GENERAL_DATA *general_data,int ipt)

/*==========================================================================*/

{/* begin routine */
  /*  int ipt=1;*/

  int i,iii,j,m,k;
  int iptoff = ipt + general_data->tempering_ctrl.npara_temps_proc_off;
  FILE *fp_bond_free,*fp_bend_free,*fp_tors_free, *fp_rbar_free;
  NAME tname;
  int  npara_temps      = general_data->simopts.npara_temps; 

/*==========================================================================*/
/*    A) Bonds                                                       */
   if(bonded->bond_free[ipt].num >0 ){
       fp_bond_free  = cfopen(bonded->bond_free[ipt].file,"o");
       fprintf(fp_bond_free,"Itime\n");
       fprintf(fp_bond_free,"%d\n",general_data->timeinfo.itime);
       fprintf(fp_bond_free,"fk, eq, npow\n");
       fprintf(fp_bond_free,"%.13g %.13g %d\n",bonded->bond_free[ipt].fk,
              bonded->bond_free[ipt].eq,bonded->bond_free[ipt].npow);
       fprintf(fp_bond_free,"nhist,rmin,rmax,dr\n");
       fprintf(fp_bond_free,"%d %.13g %.13g %.13g\n",
              bonded->bond_free[ipt].nhist,bonded->bond_free[ipt].rmin,
              bonded->bond_free[ipt].rmax,bonded->bond_free[ipt].del);
       fprintf(fp_bond_free,"histogram\n");
       for(i=1;i<=(bonded->bond_free[ipt].nhist);i++){
         fprintf(fp_bond_free,"%.13g\n",bonded->bond_free[ipt].hist[i]);
       }/*endfor*/
        fflush(fp_bond_free); 
        fclose(fp_bond_free); 
      }/*endif*/

/*==========================================================================*/
/*    B) Bends                                                  */
      if(bonded->bend_free[ipt].num >0 ){
       fp_bend_free  = cfopen(bonded->bend_free[ipt].file,"o");
       fprintf(fp_bend_free,"Itime\n");
       fprintf(fp_bend_free,"%d\n",general_data->timeinfo.itime);
       fprintf(fp_bend_free,"fk, eq, npow\n");
       fprintf(fp_bend_free,"%.13g %.13g %d\n",bonded->bend_free[ipt].fk,
              bonded->bend_free[ipt].eq,bonded->bend_free[ipt].npow);
       fprintf(fp_bend_free,"nhist, dtheta\n");
       fprintf(fp_bend_free,"%d %.13g \n",
              bonded->bend_free[ipt].nhist,bonded->bend_free[ipt].del);
       fprintf(fp_bend_free,"Histogram\n");
       for(i=1;i<=(bonded->bend_free[ipt].nhist);i++){
         fprintf(fp_bend_free,"%.13g\n",bonded->bend_free[ipt].hist[i]);
       }/*endfor*/
        fflush(fp_bend_free); 
        fclose(fp_bend_free); 
      }/*endif*/

/*==========================================================================*/
/*    C) Tors                                                    */

      if(bonded->tors_free[ipt].num ==1 ){
       fp_tors_free  = cfopen(bonded->tors_free[ipt].file,"o");
       fprintf(fp_tors_free,"Itime\n");
       fprintf(fp_tors_free,"%d\n",general_data->timeinfo.itime);
       fprintf(fp_tors_free,"fk, eq, npow\n");
       fprintf(fp_tors_free,"%.13g %.13g %d\n",bonded->tors_free[ipt].fk,
              bonded->tors_free[ipt].eq[1],bonded->tors_free[ipt].npow);
       fprintf(fp_tors_free,"nhist, dtheta\n");
       fprintf(fp_tors_free,"%d -180 180 %.13g \n",
              bonded->tors_free[ipt].nhist,bonded->tors_free[ipt].del);
       fprintf(fp_tors_free,"Histogram\n");
       for(i=1;i<=(bonded->tors_free[ipt].nhist);i++){
         fprintf(fp_tors_free,"%.13g\n",bonded->tors_free[ipt].hist[i]);
       }/*endfor*/
        fflush(fp_tors_free); 
        fclose(fp_tors_free); 
      }/*endif*/

   if(bonded->tors_free[ipt].num == 2){
       fp_tors_free  = cfopen(bonded->tors_free[ipt].file,"o");
       fprintf(fp_tors_free,"Itime\n");
       fprintf(fp_tors_free,"%d\n",general_data->timeinfo.itime);
       fprintf(fp_tors_free,"fk, eq, fk eq npow\n");
       fprintf(fp_tors_free,"%.13g %.13g %.13g %.13g %d\n",
           bonded->tors_free[ipt].fk,bonded->tors_free[ipt].eq[1],
           bonded->tors_free[ipt].fk,bonded->tors_free[ipt].eq[2],
           bonded->tors_free[ipt].npow);
       fprintf(fp_tors_free,"nhist, dtheta\n");
       fprintf(fp_tors_free,"%d -180.0 180.0 %.13g \n",
              bonded->tors_free[ipt].nhist,bonded->tors_free[ipt].del);
       fprintf(fp_tors_free,"nhist, dtheta\n");
       fprintf(fp_tors_free,"%d -180.0 180.0 %.13g \n",
              bonded->tors_free[ipt].nhist,bonded->tors_free[ipt].del);
       fprintf(fp_tors_free,"Histogram\n");
       for(i=1;i<=(bonded->tors_free[ipt].nhist);i++){
       for(j=1;j<=(bonded->tors_free[ipt].nhist);j++){
        fprintf(fp_tors_free,"%d %d %.13g\n",j,i,
                      bonded->tors_free[ipt].hist_2d[j][i]);
       }/*endfor*/
       }/*endfor*/
       fflush(fp_tors_free); 
       fclose(fp_tors_free); 
   }/*endif*/

/*==========================================================================*/
/*    D) rbar sigma                                                         */

   if(bonded->rbar_sig_free[ipt].nfree > 0){

        fp_rbar_free  = cfopen(bonded->rbar_sig_free[ipt].file,"o");

        fprintf(fp_rbar_free,"Itime\n");
        fprintf(fp_rbar_free,"%d\n",general_data->timeinfo.itime);
        fprintf(fp_rbar_free,"fk_bar, eq_bar, fk_sig, eq_sig nfree\n");
        fprintf(fp_rbar_free,"%.13g %.13g %.13g %.13g %d\n",
                             bonded->rbar_sig_free[ipt].fk_bar,
                             bonded->rbar_sig_free[ipt].eq_bar,
                             bonded->rbar_sig_free[ipt].fk_sigma,
                             bonded->rbar_sig_free[ipt].eq_sigma,
                             bonded->rbar_sig_free[ipt].nfree);

        fprintf(fp_rbar_free,"nhist_bar, rmin, rmax \n");
        fprintf(fp_rbar_free,"%d %.13g %.13g \n",
                             bonded->rbar_sig_free[ipt].nhist_bar,
                             bonded->rbar_sig_free[ipt].rmin,
                             bonded->rbar_sig_free[ipt].rmax);

        fprintf(fp_rbar_free,"nhist_sig, smin, smax \n");
        fprintf(fp_rbar_free,"%d %.13g %.13g \n",
                             bonded->rbar_sig_free[ipt].nhist_sig,
                             bonded->rbar_sig_free[ipt].smin,
                             bonded->rbar_sig_free[ipt].smax);

        fprintf(fp_rbar_free,"Histogram:ibar,isig,hist\n");
        for(i=1;i<=(bonded->rbar_sig_free[ipt].nhist_sig);i++){
         for(j=1;j<=(bonded->rbar_sig_free[ipt].nhist_bar);j++){
          fprintf(fp_rbar_free,"%d %d %.13g\n",
                       j,i,bonded->rbar_sig_free[ipt].hist[j][i]);
         }/*endfor*/
        }/*endfor*/
      
        for(m=1;m<=bonded->rbar_sig_free[ipt].nfree;m++){
         fprintf(fp_rbar_free,"Histogram %d:ibin,ibar,isig,hist\n",m);
         for(k=1;k<=bonded->rbar_sig_free[ipt].nhist_bar;k++){
               fprintf(fp_rbar_free,"%d %.13g\n",
                       k,bonded->rbar_sig_free[ipt].hist_rn[m][k]);
         }/*endfor*/
        }/*endfor*/

        fflush(fp_rbar_free); 
        fclose(fp_rbar_free); 

   }/*endif*/

/*==========================================================================*/
  }/* end routine */
/*==========================================================================*/



/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void write_config_files_pimd(CLASS *class,BONDED *bonded,
			     GENERAL_DATA *general_data,int ipt)

/*==========================================================================*/

{/* begin routine */
  /*  int ipt=1;*/

  int i,ip,ipp,n,iii;
  int iptoff = ipt + general_data->tempering_ctrl.npara_temps_proc_off;
  int pi_beads = class->clatoms_info.pi_beads;
  FILE *fp_cpname, *fp_cvname, *fp_centname;
  double dpi_beads,xcm,ycm,zcm;
  NAME tname;
  int  npara_temps      = general_data->simopts.npara_temps; 

/*=====================================================================*/
/* I) Write to the atm config file                                     */ 

    if((general_data->timeinfo.itime % general_data->filenames.iwrite_confp) == 0 ){
      if(npara_temps>1){
	sprintf(tname,"%s.%d",general_data->filenames.cpname,iptoff);
      }else{
	strcpy(tname,general_data->filenames.cpname);
      }/*endif*/

     if(general_data->filenames.iwrite_conf_binary==0){
      fp_cpname  = cfopen(tname,"a");
      for(ipp=1;ipp<=pi_beads;ipp++){
	ip=ipp + pi_beads*(ipt-1);
       for(i=1;i<=(class->clatoms_info.natm_tot);i++){
       fprintf(fp_cpname,"%.12g  %.12g  %.12g\n",class->clatoms_tmp[ip].x[i],
              class->clatoms_tmp[ip].y[i],class->clatoms_tmp[ip].z[i]);
       }/*endfor*/
      }/*endfor*/
      for(i=1;i<=9;i+=3) 
       fprintf(fp_cpname,"%.13g %.13g %.13g\n",general_data->cell.hmat[i],
              general_data->cell.hmat[(i+1)],general_data->cell.hmat[(i+2)]);
      fflush(fp_cpname);
      fclose(fp_cpname);
    }/*endif*/

   if(general_data->filenames.iwrite_conf_binary==1){
    fp_cpname = cfopen(tname,"a");
    n=1;
   for(ipp=1;ipp<=pi_beads;ipp++){
     ip=ipp + pi_beads*(ipt-1);
    for(i=1;i<=(class->clatoms_info.natm_tot);i++){ 
     fwrite(&(class->clatoms_tmp[ip].x)[i],sizeof(double),n,fp_cpname);
     fwrite(&(class->clatoms_tmp[ip].y)[i],sizeof(double),n,fp_cpname);
     fwrite(&(class->clatoms_tmp[ip].z)[i],sizeof(double),n,fp_cpname);
    }/*endfor*/ 
   }/*endfor*/ 
    for(i=1;i<=9;i+=3){ 
      fwrite(&(general_data->cell.hmat)[i],sizeof(double),n,fp_cpname);
      fwrite(&(general_data->cell.hmat)[i+1],sizeof(double),n,fp_cpname);
      fwrite(&(general_data->cell.hmat)[i+2],sizeof(double),n,fp_cpname);
    }/*endfor*/ 
      fclose(fp_cpname);
   }/*endif*/
   }/*endif*/
  /*===================================================================*/
  /* I) Write to the partial atm config files                    */
  if((general_data->timeinfo.itime % general_data->filenames.iwrite_par_confp) == 0 ){
    if(npara_temps>1){
      sprintf(tname,"%s.%d",general_data->filenames.cpparname,iptoff);
    }else{
      strcpy(tname,general_data->filenames.cpparname);
    }/*endif*/

   if((general_data->filenames.iwrite_conf_binary==0)&&
      (general_data->filenames.low_lim_par<=general_data->filenames.high_lim_par)){
    fp_cpname  = cfopen(tname,"a");
    for(ipp=1;ipp<=pi_beads;ipp++){
      ip=ipp + pi_beads*(ipt-1);
     for(i=(general_data->filenames.low_lim_par);
       i<=(general_data->filenames.high_lim_par);i++){
       fprintf(fp_cpname,"%.12g  %.12g  %.12g\n",class->clatoms_tmp[ip].x[i],
             class->clatoms_tmp[ip].y[i],class->clatoms_tmp[ip].z[i]);
     }/*endfor*/
    }/*endfor*/
    for(i=1;i<=9;i+=3) 
      fprintf(fp_cpname,"%.13g %.13g %.13g\n",general_data->cell.hmat[i],
             general_data->cell.hmat[(i+1)],general_data->cell.hmat[(i+2)]);
    fflush(fp_cpname);
    fclose(fp_cpname);
   }/*endif*/

   if((general_data->filenames.iwrite_conf_binary==1)&&
      (general_data->filenames.low_lim_par<=general_data->filenames.high_lim_par)){
    fp_cpname = cfopen(tname,"a");
    n=1;
    for(ipp=1;ipp<=pi_beads;ipp++){
      ip=ipp + pi_beads*(ipt-1);
     for(i=(general_data->filenames.low_lim_par);
      i<=(general_data->filenames.high_lim_par);i++){ 
      fwrite(&(class->clatoms_tmp[ip].x)[i],sizeof(double),n,fp_cpname);
      fwrite(&(class->clatoms_tmp[ip].y)[i],sizeof(double),n,fp_cpname);
      fwrite(&(class->clatoms_tmp[ip].z)[i],sizeof(double),n,fp_cpname);
    }/*endfor*/ 
   }/*endfor*/ 
    for(i=1;i<=9;i+=3){ 
      fwrite(&(general_data->cell.hmat)[i],sizeof(double),n,fp_cpname);
      fwrite(&(general_data->cell.hmat)[i+1],sizeof(double),n,fp_cpname);
      fwrite(&(general_data->cell.hmat)[i+2],sizeof(double),n,fp_cpname);
    }/*endfor*/ 
      fclose(fp_cpname);
   }/*endif*/

  }/*endif*/
  /*=====================================================================*/

/*=====================================================================*/
 /* II) Write to the atm velocity config file                          */

  if((general_data->timeinfo.itime % general_data->filenames.iwrite_confv) == 0 ){
  if(npara_temps>1){
    sprintf(tname,"%s.%d",general_data->filenames.cvname,iptoff);
  }else{
    strcpy(tname,general_data->filenames.cvname);
  }/*endif*/

   if(general_data->filenames.iwrite_conf_binary==0){
      fp_cvname  = cfopen(tname,"a");
      for(ipp=1;ipp<=pi_beads;ipp++){
	ip=ipp + pi_beads*(ipt-1);
        for(i=1;i<=(class->clatoms_info.natm_tot);i++){
        fprintf(fp_cvname,"%.12g  %.12g  %.12g\n",
                class->clatoms_tmp[ip].vx[i],
                class->clatoms_tmp[ip].vy[i],
                class->clatoms_tmp[ip].vz[i]);
       }/*endfor*/
      }/*endfor*/
      for(i=1;i<=9;i+=3) 
       fprintf(fp_cvname,"%.13g %.13g %.13g\n",general_data->cell.hmat[i],
              general_data->cell.hmat[(i+1)],general_data->cell.hmat[(i+2)]);
      fflush(fp_cvname);
      fclose(fp_cvname);
    }/*endif*/

   if(general_data->filenames.iwrite_conf_binary==1){
    fp_cvname = cfopen(tname,"a");
    n=1;
  for(ipp=1;ipp<=pi_beads;ipp++){
    ip=ipp + pi_beads*(ipt-1);
    for(i=1;i<=(class->clatoms_info.natm_tot);i++){ 
      fwrite(&(class->clatoms_tmp[ip].vx)[i],sizeof(double),n,fp_cvname);
      fwrite(&(class->clatoms_tmp[ip].vy)[i],sizeof(double),n,fp_cvname);
      fwrite(&(class->clatoms_tmp[ip].vz)[i],sizeof(double),n,fp_cvname);
    }/*endfor*/ 
  }/*endfor*/ 
    for(i=1;i<=9;i+=3){ 
      fwrite(&(general_data->cell.hmat)[i],sizeof(double),n,fp_cvname);
      fwrite(&(general_data->cell.hmat)[i+1],sizeof(double),n,fp_cvname);
      fwrite(&(general_data->cell.hmat)[i+2],sizeof(double),n,fp_cvname);
    }/*endfor*/ 
      fclose(fp_cvname);
   }/*endif*/

  }/*endif*/
  
/*=====================================================================*/
 /* III) Write to the centroid config file                             */

  if((general_data->timeinfo.itime % general_data->filenames.iwrite_path_cent) == 0 ){
  if(npara_temps>1){
    sprintf(tname,"%s.%d",general_data->filenames.centname,iptoff);
  }else{
    strcpy(tname,general_data->filenames.centname);
  }/*endif*/

   dpi_beads = (double) (pi_beads);
   if(general_data->filenames.iwrite_conf_binary==0){
     fp_centname  = cfopen(tname,"a");
     for(i=1;i<=(class->clatoms_info.natm_tot);i++){
       xcm = 0.0;  ycm = 0.0; zcm = 0.0;
       for(ipp=1;ipp<=pi_beads;ipp++){
	 ip=ipp + pi_beads*(ipt-1);
         xcm += class->clatoms_tmp[ip].x[i];
         ycm += class->clatoms_tmp[ip].y[i];
         zcm += class->clatoms_tmp[ip].z[i];
       }/*endfor*/
       xcm /= dpi_beads; ycm /= dpi_beads; zcm /= dpi_beads;
       fprintf(fp_centname,"%.12g  %.12g  %.12g\n",xcm,ycm,zcm);
     }/*endfor*/
     for(i=1;i<=(class->clatoms_info.natm_tot);i++){
       fprintf(fp_centname,"%.12g  %.12g  %.12g\n",
               class->clatoms_tmp[1].vx[i],
        class->clatoms_tmp[1].vy[i],
                class->clatoms_tmp[1].vz[i]);
     }/*endfor*/
     for(i=1;i<=9;i+=3){
       fprintf(fp_centname,"%.13g %.13g %.13g\n",general_data->cell.hmat[i],
              general_data->cell.hmat[(i+1)],general_data->cell.hmat[(i+2)]);
     }/*endfor*/
     fflush(fp_centname);
     fclose(fp_centname);
   }/*endif*/

   if(general_data->filenames.iwrite_conf_binary==1){
     fp_centname = cfopen(tname,"a");
     n=1;
     for(i=1;i<=(class->clatoms_info.natm_tot);i++){ 
       xcm = 0.0;  ycm = 0.0; zcm = 0.0;
       for(ipp=1;ipp<=pi_beads;ipp++){
	 ip=ipp + pi_beads*(ipt-1);
         xcm += class->clatoms_tmp[ip].x[i];
         ycm += class->clatoms_tmp[ip].y[i];
         zcm += class->clatoms_tmp[ip].z[i];
       }/*endfor*/
       xcm /= dpi_beads; ycm /= dpi_beads; zcm /= dpi_beads;
       fwrite(&xcm,sizeof(double),n,fp_centname);
       fwrite(&ycm,sizeof(double),n,fp_centname);
       fwrite(&zcm,sizeof(double),n,fp_centname);
     }/*endfor*/ 
     for(i=1;i<=(class->clatoms_info.natm_tot);i++){ 
      fwrite(&(class->clatoms_tmp[1].vx)[i],sizeof(double),n,fp_centname);
      fwrite(&(class->clatoms_tmp[1].vy)[i],sizeof(double),n,fp_centname);
      fwrite(&(class->clatoms_tmp[1].vz)[i],sizeof(double),n,fp_centname);
     }/*endfor*/ 
     for(i=1;i<=9;i+=3){ 
       fwrite(&(general_data->cell.hmat)[i],sizeof(double),n,fp_centname);
       fwrite(&(general_data->cell.hmat)[i+1],sizeof(double),n,fp_centname);
       fwrite(&(general_data->cell.hmat)[i+2],sizeof(double),n,fp_centname);
     }/*endfor*/ 
     fclose(fp_centname);
   }/*endif*/

  }/*endif*/
  
/*==========================================================================*/
}/* end routine */
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void write_inst_file_pimd(CLASS *class,GENERAL_DATA *general_data,
                        double etot,double a,double b,double c,
                        double tac,double tab,double tbc,int ipt)

/*==========================================================================*/

{/* begin routine */
  /*  int ipt=1;*/

  int i;
  int iptoff = ipt + general_data->tempering_ctrl.npara_temps_proc_off;
  double inst_div;
  FILE *fp_iname;
  NAME tname;
  int  npara_temps      = general_data->simopts.npara_temps; 

/*==========================================================================*/
/*    A) Finish Averages                                            */
      inst_div    = (double)(general_data->filenames.iwrite_inst);    
      general_data->stat_avg[ipt].aikinet          /= inst_div;
      general_data->stat_avg[ipt].aipi_ke_prim      /= inst_div;
      general_data->stat_avg[ipt].aipi_ke_vir       /= inst_div;
      general_data->stat_avg[ipt].aikin_harm        /= inst_div;
      general_data->stat_avg[ipt].aikinet_v        /= inst_div;
      general_data->stat_avg[ipt].aikinet_nhc      /= inst_div;
      general_data->stat_avg[ipt].aikinet_nhc_bead /= inst_div;
      general_data->stat_avg[ipt].aivintert        /= inst_div;
      general_data->stat_avg[ipt].aivintrat        /= inst_div;
      general_data->stat_avg[ipt].aivol            /= inst_div;
      general_data->stat_avg[ipt].aicella          /= inst_div;
      general_data->stat_avg[ipt].aicellb          /= inst_div;
      general_data->stat_avg[ipt].aicellc          /= inst_div;
      general_data->stat_avg[ipt].aicellab         /= inst_div;
      general_data->stat_avg[ipt].aicellbc         /= inst_div;
      general_data->stat_avg[ipt].aicellac         /= inst_div;
      for(i=1;i<=9;i++){general_data->stat_avg[ipt].aipten[i] /= (inst_div*PCONV);}
/*==========================================================================*/
/*   B) Write Averages                                                */
      if(npara_temps>1){
	sprintf(tname,"%s.%d",general_data->filenames.iname,iptoff);
      }else{
	strcpy(tname,general_data->filenames.iname);
      }/*endif*/

      fp_iname = cfopen(tname,"a");
      fprintf(fp_iname,"\n");
      fprintf(fp_iname,"%.9g %.9g %.9g %.9g %.9g %.9g %.9g %.9g %.9g %.9g %.9g\n",
             general_data->stat_avg[ipt].aikinet,general_data->stat_avg[ipt].aipi_ke_prim,
              general_data->stat_avg[ipt].aipi_ke_vir,general_data->stat_avg[ipt].aikin_harm,
              general_data->stat_avg[ipt].aikinet_v,general_data->stat_avg[ipt].aikinet_nhc,
             general_data->stat_avg[ipt].aikinet_nhc_bead,general_data->stat_avg[ipt].aivintert,
             general_data->stat_avg[ipt].aivintrat,general_data->stat_avg[ipt].aivol,etot);
      fprintf(fp_iname,"%.9g %.9g %.9g %.9g %.9g %.9g\n",
             general_data->stat_avg[ipt].aicella,general_data->stat_avg[ipt].aicellb,
             general_data->stat_avg[ipt].aicellc,general_data->stat_avg[ipt].aicellac,
             general_data->stat_avg[ipt].aicellab,general_data->stat_avg[ipt].aicellbc);
      for(i=1;i<=9;i+=3){
       fprintf(fp_iname,"%.9g %.9g %.9g\n",general_data->stat_avg[ipt].aipten[i],
              general_data->stat_avg[ipt].aipten[(i+1)],
              general_data->stat_avg[ipt].aipten[(i+2)]);}
      fprintf(fp_iname,"%.9g %.9g %.9g %.9g %.9g %.9g %.9g %.9g %.9g %.9g\n",
             general_data->stat_avg[ipt].kinet,general_data->stat_avg[ipt].pi_ke_prim,
              general_data->stat_avg[ipt].pi_ke_vir,general_data->stat_avg[ipt].kin_harm,
              general_data->stat_avg[ipt].kinet_v, general_data->stat_avg[ipt].kinet_nhc,
             general_data->stat_avg[ipt].kinet_nhc_bead,general_data->stat_avg[ipt].vintert,
             general_data->stat_avg[ipt].vintrat,general_data->stat_avg[ipt].vol);
      fprintf(fp_iname,"%.9g %.9g %.9g %.9g %.9g %.9g\n",a,b,c,tac,tab,tbc);
      for(i=1;i<=9;i+=3) {
       fprintf(fp_iname,"%.9g %.9g %.9g\n",general_data->stat_avg[ipt].apten_out[i],
              general_data->stat_avg[ipt].apten_out[(i+1)],
              general_data->stat_avg[ipt].apten_out[(i+2)]);}
      fflush(fp_iname);
      fclose(fp_iname);
/*==========================================================================*/
/*   C) Zero Averages                                               */
      general_data->stat_avg[ipt].aikinet     = 0.0;
      general_data->stat_avg[ipt].aipi_ke_prim = 0.0;
      general_data->stat_avg[ipt].aipi_ke_vir  = 0.0;
      general_data->stat_avg[ipt].aikin_harm    = 0.0;
      general_data->stat_avg[ipt].aikinet_v   = 0.0;
      general_data->stat_avg[ipt].aikinet_nhc = 0.0;
      general_data->stat_avg[ipt].aikinet_nhc_bead = 0.0;
      general_data->stat_avg[ipt].aivintert   = 0.0;
      general_data->stat_avg[ipt].aivintrat   = 0.0;
      general_data->stat_avg[ipt].aivol       = 0.0;
      general_data->stat_avg[ipt].aicella     = 0.0;
      general_data->stat_avg[ipt].aicellb     = 0.0;
      general_data->stat_avg[ipt].aicellc     = 0.0;
      general_data->stat_avg[ipt].aicellab    = 0.0;
      general_data->stat_avg[ipt].aicellbc    = 0.0;
      general_data->stat_avg[ipt].aicellac    = 0.0;
      for(i=1;i<=9;i++){general_data->stat_avg[ipt].aipten[i]  = 0.0;}
/*==========================================================================*/
}/* end routine */
/*==========================================================================*/














