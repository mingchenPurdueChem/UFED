void bias_init(CLASS *,GENERAL_DATA *);
void bias_update(CLASS *,GENERAL_DATA *,int,int);
double L_int(double,double,double,double,int);
int find(int,int*,int);
double fact(int);
double power(double,int);
void calc_bias_pot(BIAS_PACK *,double *,double *,double **,int,int);
void L_fun_up(double *,int,double,double,double);
void T_fun_up(double *,int,double);
