void get_kt(DAFED *, double *);
void get_ke(DAFED *, double *);
void zero(double *, int);
void zero_forces(DAFED *, int);
void zero_stats(DAFED_STAT *);
void zero_stats_avg(DAFED_STAT *);
void zero_allstats(DAFED_STAT *);
void total_dafed_energy(DAFED_STAT *, double *);
void get_dafed_therm_energy(GGMT *, double *,double *);
