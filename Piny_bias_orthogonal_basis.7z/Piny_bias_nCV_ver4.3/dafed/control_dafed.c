#include "standard_include.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_cp.h"
#include "../typ_defs/typedefs_par.h"
#include "../typ_defs/typedefs_stat.h"
#include "../proto_defs/proto_friend_lib_entry.h"
#include "../proto_defs/proto_math.h"
#include "../proto_defs/proto_dafed_entry.h"
#include "../proto_defs/proto_dafed_helper.h"
#include "../proto_defs/proto_dafed_bias.h"

void scale_params(DAFED *daf) {
  printf("Scaling to Atomic Units (d-AFED)\n");
  printf(" - Tau -> (tau*dt)**2 \n");
  
  daf->therm.tau *= daf->dt;
  daf->therm.tau  = pow(daf->therm.tau,2);
  daf->therm.dT   = daf->dt;  
  printf(" - ms  -> amu to a.u.\n");
 
  daf->ms *= PROT_MASS;
  
  printf(" - kTs ->\n");
  
  daf->kTs /= BOLTZ;
  daf->therm.kTs = daf->kTs; 
  printf(" - ks ->\n");
  
  daf->ks *=(BOHR*BOHR)/BOLTZ; 

  daf->vs = -sqrt(daf->kTs/daf->ms);
  if (daf->on != 3)
     daf->s  = -4.0;
  daf->Fs = 0;
}

void initialize_therm(GGMT *th) {
  th->ny = 3;
  th->Q[1]  = th->kTs*th->tau;
  th->Q[2]  = 8.0*th->tau*pow(th->kTs,3)/3.0;
  th->w[1]  = (1.0/(2.0-pow(2.0,(1.0/3.0))))/((double)th->nr);
  th->w[2]  = (1.0-(2.0*th->w[1]))/((double)th->nr);
  th->w[3]  = th->w[1];
  th->w[1]  *= th->dT;
  th->w[2]  *= th->dT;
  th->w[3]  *= th->dT;
  th->qt[1] = 1.0;   th->qt[2] = 1.0;
  th->vt[1] = -sqrt(th->kTs/th->Q[1]);
  th->vt[2] = -sqrt(th->kTs/th->Q[2]);
}

void get_Ree_params(DAFED *d, CLATOMS_INFO *cla_i) {
  
   if (cla_i->num_Ree != 2) {
     printf("num_Ree:%i\n",cla_i->num_Ree);
     printf("Error: Molecule must have 2 and only 2 ends!!\n");
     fflush(stdout);
     exit(0);
   }
   d->i1_num = 1;
   d->i1 = (int *)cmalloc(d->i1_num*sizeof(int))-1;
   d->i1[1] = cla_i->Ree_map[1];
   d->i2_num = 1;
   d->i2 = (int *)cmalloc(d->i2_num*sizeof(int))-1;
   d->i2[1] = cla_i->Ree_map[2];
   d->n_atm_f = 2;
   d->atm_fl = (int*)cmalloc(d->n_atm_f*sizeof(int))-1;
   d->atm_fl[1] = d->i1[1];
   d->atm_fl[2] = d->i2[1];

   printf("==================================\n");
   printf("d-AFED End-to-End\n");
   printf("-----------------\n");
   printf(" End 1: %d \n",d->i1[1]);
   printf(" End 2: %d \n",d->i2[1]);
   printf("==================================\n");
   fflush(stdout); 

}

void get_Rgyr_params(DAFED *d, CLATOMS_INFO *cla_i) {
  int iii;

  d->i1_num = cla_i->num_Rgyr;
  d->i2_num = cla_i->num_Rgyr;
  d->n_atm_f = cla_i->num_Rgyr;

  d->i1 = (int *)cmalloc(d->i1_num*sizeof(int))-1;
  d->i2 = (int *)cmalloc(d->i2_num*sizeof(int))-1;
  d->atm_fl  = (int*)cmalloc(d->n_atm_f*sizeof(int))-1;

   printf("==================================\n");
   printf("d-AFED Radius of Gyration\n");
   printf("-----------------\n");
  for (iii = 1; iii<=cla_i->num_Rgyr;iii++) {
    d->i1[iii] = cla_i->Rgyr_map[iii];
    d->i2[iii] = cla_i->Rgyr_map[iii];
    d->atm_fl[iii] = cla_i->Rgyr_map[iii];
   printf(" Backbone Atom: %d\n",d->i1[iii]);
  }
   printf("i2_7 %d\n",d->i2[7]);
   printf("==================================\n");
   fflush(stdout); 
   
}

void get_NH_params(DAFED *d, CLATOMS_INFO *cla_i, ATOMMAPS *am, int min_s){

   int iii,jjj;
   int ind_i, ind_j;
   int nhbonds = 0;
   int res_i, res_j;
   int max;
   d->i1_num = 0;
   d->i2_num = 0;
   if (min_s != -1) 
     max = cla_i->num_H*cla_i->num_O;
   else max = 50000;
   d->i1 = (int *)cmalloc(max*sizeof(int))-1;
   d->i2 = (int *)cmalloc(max*sizeof(int))-1;
  
   if (min_s >= 0) { 

     printf("==================================\n");
     printf("d-AFED Number of H-Bonds \n");
     printf("-----------------\n");

     for (iii=1; iii<=cla_i->num_O;iii++) {
        ind_i = cla_i->O_map[iii];
        res_i = am->iatm_res_num[ind_i];
 
        for (jjj=1; jjj<=cla_i->num_H; jjj++) {
           ind_j = cla_i->H_map[jjj];
           res_j = am->iatm_res_num[ind_j];
           if (fabs(res_j-res_i) > min_s) {
             printf("O #%d is %d residues from H #%d --> ADDING H-BOND!\n",
                     iii, (int)fabs(res_j-res_i), jjj);
             d->i1_num += 1; 
             d->i2_num += 1; 
             d->i1[d->i1_num] = ind_i; 
             d->i2[d->i2_num] = ind_j;
           }
           else {
             printf("O #%d is %d residues from H #%d --> TOO CLOSE!\n",
                     iii, (int)fabs(res_j-res_i), jjj);
 
           }
        }
      }
  /*
    d->i1a_num = 3;
    d->i2_num = 3;
    d->i1[1] = cla_i->O_map[1];
    d->ia2[1] = cla_i->H_map[7];
    printf("Hbond btw O (atm #%d) and H (atm#%d)\n",d->i1[1],d->i2[1]);
    d->i1[2] = cla_i->O_map[6];
    d->i2[2] = cla_i->H_map[2];
    printf("Hbond btw O (atm #%d) and H (atm#%d)\n",d->i1[2],d->i2[2]);
    d->i1[3] = cla_i->O_map[3];
   aaaaa d->i2[3] = cla_i->H_map[5];
    printf("Hbond btw O (atm #%d) and H (atm#%d)\n",d->i1[3],d->i2[3]);
 */

   }
   if (min_s == -1) {
      for (iii = 1; iii <= cla_i->num_O;iii++) {
         ind_i = cla_i->O_map[iii];
         for (jjj = 1; jjj<= cla_i->natm_tot; jjj++) {
              if (strcasecmp(am->atm_typ[am->iatm_atm_typ[jjj]],"HT") == 0) {
                  printf("Adding Intra-Molec H-Bond bw O #%d and TIP H #%d\n",
                          iii,jjj);
                  d->i1_num += 1;  d->i2_num +=1;
                  d->i1[d->i1_num] = ind_i;
                  d->i2[d->i2_num] = jjj;            
              }
         }
      }
      for (iii = 1; iii <= cla_i->num_H;iii++) {
         ind_i = cla_i->H_map[iii];
         for (jjj = 1; jjj<= cla_i->natm_tot; jjj++) {
              if (strcasecmp(am->atm_typ[am->iatm_atm_typ[jjj]],"OT") == 0) {
                  printf("Adding Intra-Molec H-Bond bw H #%d and TIP O #%d\n",
                          iii,jjj);
                  d->i1_num += 1;  d->i2_num +=1;
                  d->i1[d->i1_num] = ind_i;
                  d->i2[d->i2_num] = jjj;            
              }
         }
      }

   }
   d->n_atm_f = 2*d->i1_num;
   d->atm_fl  = (int*)cmalloc(d->n_atm_f*sizeof(int))-1;
   for(iii=1;iii<=d->i1_num;iii++){
      d->atm_fl[iii] = d->i1[iii];
      d->atm_fl[iii+d->i1_num] = d->i2[iii];
   }
   
   printf("TOTAL H-BONDS: %d \n", d->i1_num);
   if (d->i1_num < 1) {
     printf(" ** FOUND NO VALID H-BONDS!! **\n");
     printf(" ** SHUTTING OFF NH!!!       **\n");
     d->on = 0;
   }
   printf("==================================\n");
   fflush(stdout); 
}

void get_Phi_params(DAFED *d, CLATOMS_INFO *clatoms_info, int i)
{
  int iii;
  DIH_MAP *Phi_map = clatoms_info->Phi_map;
  d->i1_num = 4;
  d->n_atm_f = 4;
  d->i1 = (int *)cmalloc(d->i1_num*sizeof(int))-1;
  d->atm_fl  = (int*)cmalloc(d->n_atm_f*sizeof(int))-1;

  printf("==================================\n");
  printf("d-AFED Radius of Gyration\n");
  printf("-----------------\n");  
  for(iii=1;iii<=4;iii++){
     d->i1[iii] = Phi_map[i].atm_i[iii-1];
     d->atm_fl[iii] = Phi_map[i].atm_i[iii-1];
     printf("Phi:%i,Atm:%i\n",i,d->i1[iii]);  
  }
  printf("==================================\n");
  fflush(stdout);
}

void get_Dih_params(DAFED *d, CLATOMS_INFO *clatoms_info,int iflag){//used for dih_cor,Nalpha,Nbeta
  int i;
  int *Ca_map = clatoms_info->Ca_map;

  d->i1_num = clatoms_info->num_ca;
  d->n_atm_f = clatoms_info->num_ca;
  d->i1 = (int *)cmalloc(d->i1_num*sizeof(int))-1;
  d->atm_fl  = (int*)cmalloc(d->n_atm_f*sizeof(int))-1;
  
  printf("==================================\n");
  switch(iflag){
   case 1:printf("d-AFED Dihedral angle correlation\n");break;
   case 2:printf("d-AFED Number of alpha residues\n");break;
   case 3:printf("d-AFED Number of beta residues\n");break;
  }
  printf("-----------------\n");
  if(d->i1_num<4){
    printf("@@@@@@@@@@@@@@@@@@@@@error@@@@@@@@@@@@@@@@@@@@@@\n");
    printf("You can't have # of backbone Ca less then 4!\n");
    printf("This CV is not suitable on small system!\n");
    printf("@@@@@@@@@@@@@@@@@@@@@error@@@@@@@@@@@@@@@@@@@@@@\n");
    fflush(stdout);
    exit(1);
  }
  if(d->i1_num<5&&iflag==1){
    printf("@@@@@@@@@@@@@@@@@@@@@error@@@@@@@@@@@@@@@@@@@@@@\n");
    printf("You turn on Dihedral angle correlation,\n");
    printf("so you can't have # of backbone Ca less then 5!\n");
    printf("This CV is not suitable on small system!\n");
    printf("@@@@@@@@@@@@@@@@@@@@@error@@@@@@@@@@@@@@@@@@@@@@\n");
    fflush(stdout);
    exit(1);
  }
  for(i=1;i<=d->i1_num;i++){
    d->i1[i] = Ca_map[i];
    d->atm_fl[i] = Ca_map[i];
    printf("C alpha:%i\n",d->i1[i]);
  }
}

void initialize_dafed(CLASS *class, GENERAL_DATA *general_data) {
#include "../typ_defs/typ_mask.h"
  CLATOMS_INFO *clatoms_info = &(class->clatoms_info);
  TEMPERING_CTRL *tempering_ctrl = &(general_data->tempering_ctrl);
  DAFED *Ree  = clatoms_info->Ree;
  DAFED *Rgyr = clatoms_info->Rgyr;
  DAFED *NH   = clatoms_info->NH;
  DAFED **Phi = clatoms_info->Phi;
  DAFED *Dih_cor = clatoms_info->Dih_cor;
  DAFED *Nalpha  = clatoms_info->Nalpha;
  DAFED *Nbeta   = clatoms_info->Nbeta;
  DAFED_INFO *dinfo; 
  ATOMMAPS *am = &(class->atommaps);
  STAT_AVG *stat_avg ;
  struct DAFED_FREQ *dafed_freq;
  int myid_m = class->communicate_m.myid;
  int myid   = class->communicate.myid;
  int ipt,iptoff,min_s;
  int npara_temps = general_data->simopts.npara_temps;
  int npara_temps_proc = general_data->tempering_ctrl.npara_temps_proc;
  int ree_on   = tempering_ctrl->ree_on;
  int rgyr_on  = tempering_ctrl->rgyr_on;
  int nh_on    = tempering_ctrl->nh_on;
  int dih_cor_on = tempering_ctrl->dih_cor_on;
  int nalpha_on  = tempering_ctrl->nalpha_on;
  int nbeta_on   = tempering_ctrl->nbeta_on;
  int num_phi  = clatoms_info->num_phi;
  int np       = class->communicate.np;
  int i,j,n_cv,n_bin_phi,steps_bias_s;
  int div,res;
  int iflag;
  NAME name_1,name_2;
  FILE *t1, *t2;
  MPI_Comm world     = class->communicate.world;
  MPI_Datatype dinfo_info_comm;
  MPI_Datatype types[1];
  MPI_Aint displs[1];

  int blockcounts[1];
  int ndinfo = 12;


  for(ipt=1;ipt<=npara_temps_proc;ipt++){
     stat_avg = &(general_data->stat_avg[ipt]);
     stat_avg->ds_phi = (DAFED_STAT *)cmalloc(num_phi*sizeof(DAFED_STAT))-1;
  }
  Barrier(world);
  if(general_data->tempering_ctrl.para_type!=2&&myid!=0){
    clatoms_info->daf_info = (DAFED_INFO*)cmalloc(npara_temps_proc*sizeof(DAFED_INFO))-1;
  }
  Barrier(world);
  dinfo = clatoms_info->daf_info;
 if(myid==0){
  for(ipt=1;ipt<=npara_temps_proc;ipt++){
     n_cv = 0;
     stat_avg          = &(general_data->stat_avg[ipt]);
     stat_avg->num_phi = num_phi;
     Ree[ipt].dt       = general_data->timeinfo.dt;
     Rgyr[ipt].dt      = general_data->timeinfo.dt;
     NH[ipt].dt        = general_data->timeinfo.dt;
     Dih_cor[ipt].dt   = general_data->timeinfo.dt;
     Nalpha[ipt].dt    = general_data->timeinfo.dt;
     Nbeta[ipt].dt     = general_data->timeinfo.dt;
     steps_bias_s      = dinfo[ipt].steps_bias/10;
     dinfo[ipt].difftime = 0.0;
     for(i=1;i<=num_phi;i++){
        Phi[ipt][i].dt = general_data->timeinfo.dt;
     }
        
     min_s = dinfo[ipt].min_sep;

     stat_avg->ree_on  = 0;
     stat_avg->rgyr_on = 0;
     stat_avg->nh_on   = 0;
     stat_avg->dih_cor_on = 0;
     stat_avg->nalpha_on  = 0;
     stat_avg->nbeta_on   = 0;
     scale_params(&Ree[ipt]);
     scale_params(&Rgyr[ipt]);
     scale_params(&NH[ipt]);
     scale_params(&Dih_cor[ipt]);
     scale_params(&Nalpha[ipt]);
     scale_params(&Nbeta[ipt]);
     initialize_therm(&(Ree[ipt].therm));
     initialize_therm(&(Rgyr[ipt].therm));
     initialize_therm(&(NH[ipt].therm));
     initialize_therm(&(Dih_cor[ipt].therm));
     initialize_therm(&(Nalpha[ipt].therm));
     initialize_therm(&(Nbeta[ipt].therm));
     for(i=1;i<=num_phi;i++){
        scale_params(&(Phi[ipt][i]));
        initialize_therm(&(Phi[ipt][i].therm));
     }

    if(general_data->tempering_ctrl.para_type==2){//para dafed, in this situation
      switch(general_data->statepoint[ipt].cv_ext){
        case 1: if(Ree[ipt].on_backup!=0){//this means the information in cv input file is superer then that in gen input file
		  Ree[ipt].on = Ree[ipt].on_backup;
                }
		else{
                  Ree[ipt].on = 1;
		}
                Rgyr[ipt].on = 0;
                NH[ipt].on = 0;
                stat_avg->Ree_freq = (struct DAFED_FREQ *)cmalloc(sizeof(struct DAFED_FREQ));
                stat_avg->n_cv = 1;
                stat_avg->n_list = 1;
                break;
        case 2: if(Rgyr[ipt].on_backup!=0){
		  Rgyr[ipt].on = Rgyr[ipt].on_backup;
                }
		else{
		  Rgyr[ipt].on = 1;
		}
		Ree[ipt].on = 0;
		NH[ipt].on = 0;
	        stat_avg->Rgyr_freq = (struct DAFED_FREQ *)cmalloc(sizeof(struct DAFED_FREQ));
                stat_avg->n_cv = 1;
                stat_avg->n_list = 1;
                break;
        case 3: if(NH[ipt].on_backup!=0){
		  NH[ipt].on = NH[ipt].on_backup;
                }
		else{
		  NH[ipt].on = 1;
		}
		Ree[ipt].on = 0;
		Rgyr[ipt].on = 0;
                stat_avg->NH_freq = (struct DAFED_FREQ *)cmalloc(sizeof(struct DAFED_FREQ));
                stat_avg->n_cv = 1;
                stat_avg->n_list = 1;
                break;
        }/*endswitch*/
      }/*endif para_type*/
      if(ree_on==1){
        get_Ree_params(&(Ree[ipt]),clatoms_info);
      }
      if(rgyr_on==1){
        get_Rgyr_params(&(Rgyr[ipt]),clatoms_info);
      }
      if(nh_on==1){
        get_NH_params(&(NH[ipt]),clatoms_info,am,min_s);
      }//this information is needed of calculating CVs' values which are not in my trajectory
      if(dih_cor_on==1){
        get_Dih_params(&(Dih_cor[ipt]),clatoms_info,1);
      }
      if(nalpha_on == 1){
        get_Dih_params(&(Nalpha[ipt]),clatoms_info,2);
      }
      if(nbeta_on==1){
        get_Dih_params(&(Nbeta[ipt]),clatoms_info,3);
      }
      for(i=1;i<=num_phi;i++){
         get_Phi_params(&(Phi[ipt][i]),clatoms_info,i);
      }

    if (Ree[ipt].on >= 1) {
      n_cv += 1;
      stat_avg->ree_on = Ree[ipt].on;
      Ree[ipt].bdy = 1;
      Ree[ipt].Fx = (double *)cmalloc(Ree[ipt].n_atm_f*sizeof(double))-1;
      Ree[ipt].Fy = (double *)cmalloc(Ree[ipt].n_atm_f*sizeof(double))-1;
      Ree[ipt].Fz = (double *)cmalloc(Ree[ipt].n_atm_f*sizeof(double))-1;
      Ree[ipt].data = (double *)cmalloc(dinfo[ipt].to_file_freq*sizeof(double))-1;
      Ree[ipt].data_s = (double *)cmalloc(dinfo[ipt].to_file_freq*sizeof(double))-1;
      zero_forces(&(Ree[ipt]), Ree[ipt].n_atm_f);
      zero(Ree[ipt].data, dinfo[ipt].to_file_freq);
      zero(Ree[ipt].data_s, dinfo[ipt].to_file_freq);
      if (Ree[ipt].on == 3) Ree[ipt].s/=BOHR;
      if (Ree[ipt].on  == 1|| Ree[ipt].on == 3) {
        zero_allstats(&(general_data->stat_avg[ipt].ds_ree));
        // printf("av_dpe %f\n",general_data->stat_avg.ds_ree.av_dpe);
      }
    }
    if (Rgyr[ipt].on >= 1) {
      n_cv += 1;
      stat_avg->rgyr_on = Rgyr[ipt].on;
      Rgyr[ipt].bdy = 1;
      Rgyr[ipt].Fx = (double *)cmalloc(Rgyr[ipt].n_atm_f*sizeof(double))-1;
      Rgyr[ipt].Fy = (double *)cmalloc(Rgyr[ipt].n_atm_f*sizeof(double))-1;
      Rgyr[ipt].Fz = (double *)cmalloc(Rgyr[ipt].n_atm_f*sizeof(double))-1;
      Rgyr[ipt].data = (double *)cmalloc(dinfo[ipt].to_file_freq*sizeof(double))-1;
      Rgyr[ipt].data_s = (double *)cmalloc(dinfo[ipt].to_file_freq*sizeof(double))-1;
      zero_forces(&(Rgyr[ipt]), Rgyr[ipt].n_atm_f);
      zero(Rgyr[ipt].data, dinfo[ipt].to_file_freq);
      zero(Rgyr[ipt].data_s, dinfo[ipt].to_file_freq);
      if (Rgyr[ipt].on == 3) Rgyr[ipt].s/=BOHR;
      if (Rgyr[ipt].on  == 1|| Rgyr[ipt].on == 3) {
       zero_allstats(&(general_data->stat_avg[ipt].ds_rgyr));
      }
    }
    if (NH[ipt].on >= 1) {
      n_cv += 1;
      stat_avg->nh_on = NH[ipt].on;
      NH[ipt].bdy = 1;
      NH[ipt].Fx = (double *)cmalloc(NH[ipt].n_atm_f*sizeof(double))-1;
      NH[ipt].Fy = (double *)cmalloc(NH[ipt].n_atm_f*sizeof(double))-1;
      NH[ipt].Fz = (double *)cmalloc(NH[ipt].n_atm_f*sizeof(double))-1;
      NH[ipt].data = (double *)cmalloc(dinfo[ipt].to_file_freq*sizeof(double))-1;
      NH[ipt].data_s = (double *)cmalloc(dinfo[ipt].to_file_freq*sizeof(double))-1;
      zero_forces(&(NH[ipt]), NH[ipt].n_atm_f);
      zero(NH[ipt].data, dinfo[ipt].to_file_freq);
      zero(NH[ipt].data_s, dinfo[ipt].to_file_freq);
      if (NH[ipt].on  == 1|| NH[ipt].on == 3) {
       zero_allstats(&(general_data->stat_avg[ipt].ds_nh));
      }
    }
    if(num_phi>=1){
      n_cv += num_phi;
      stat_avg->phi_on = Phi[ipt][1].on;
      for(i=1;i<=num_phi;i++){
         Phi[ipt][i].bdy = 2;
         Phi[ipt][i].Fx = (double *)cmalloc(Phi[ipt][i].n_atm_f*sizeof(double))-1;
         Phi[ipt][i].Fy = (double *)cmalloc(Phi[ipt][i].n_atm_f*sizeof(double))-1;
         Phi[ipt][i].Fz = (double *)cmalloc(Phi[ipt][i].n_atm_f*sizeof(double))-1;
         Phi[ipt][i].data = (double *)cmalloc(dinfo[ipt].to_file_freq*sizeof(double))-1;
         Phi[ipt][i].data_s = (double *)cmalloc(dinfo[ipt].to_file_freq*sizeof(double))-1;
         zero_forces(&(Phi[ipt][i]),Phi[ipt][i].n_atm_f);
         zero(Phi[ipt][i].data,dinfo[ipt].to_file_freq);
         zero(Phi[ipt][i].data_s,dinfo[ipt].to_file_freq);
         if(Phi[ipt][1].on==1||Phi[ipt][1].on==3){
	   zero_allstats(&(general_data->stat_avg[ipt].ds_phi[i]));

         }/*endif*/
      }/*endfor i*/
    }/*endif*/
    if(Dih_cor[ipt].on>=1){
      n_cv += 1;
      stat_avg->dih_cor_on = Dih_cor[ipt].on;
      Dih_cor[ipt].bdy = 1;
      Dih_cor[ipt].Fx  = (double*)cmalloc(Dih_cor[ipt].n_atm_f*sizeof(double))-1;
      Dih_cor[ipt].Fy  = (double*)cmalloc(Dih_cor[ipt].n_atm_f*sizeof(double))-1;
      Dih_cor[ipt].Fz  = (double*)cmalloc(Dih_cor[ipt].n_atm_f*sizeof(double))-1;
      Dih_cor[ipt].data = (double*)cmalloc(dinfo[ipt].to_file_freq*sizeof(double))-1;
      Dih_cor[ipt].data_s = (double*)cmalloc(dinfo[ipt].to_file_freq*sizeof(double))-1;
      zero_forces(&Dih_cor[ipt],Dih_cor[ipt].n_atm_f);
      zero(Dih_cor[ipt].data,dinfo[ipt].to_file_freq);
      zero(Dih_cor[ipt].data_s,dinfo[ipt].to_file_freq);
      if(Dih_cor[ipt].on==1||Dih_cor[ipt].on==3){
	zero_allstats(&(general_data->stat_avg[ipt].ds_dih_cor));
      }
    }
    if(Nalpha[ipt].on>=1){
       n_cv += 1;
       stat_avg->nalpha_on = Nalpha[ipt].on;
       Nalpha[ipt].bdy = 1;
       Nalpha[ipt].Fx  = (double*)cmalloc(Nalpha[ipt].n_atm_f*sizeof(double))-1;
       Nalpha[ipt].Fy  = (double*)cmalloc(Nalpha[ipt].n_atm_f*sizeof(double))-1;
       Nalpha[ipt].Fz  = (double*)cmalloc(Nalpha[ipt].n_atm_f*sizeof(double))-1;
       Nalpha[ipt].data = (double*)cmalloc(dinfo[ipt].to_file_freq*sizeof(double))-1;
       Nalpha[ipt].data_s = (double*)cmalloc(dinfo[ipt].to_file_freq*sizeof(double))-1;
       zero_forces(&Nalpha[ipt],Nalpha[ipt].n_atm_f);
       zero(Nalpha[ipt].data,dinfo[ipt].to_file_freq);
       zero(Nalpha[ipt].data_s,dinfo[ipt].to_file_freq);
       if(Nalpha[ipt].on==1||Nalpha[ipt].on==3){
         zero_allstats(&(general_data->stat_avg[ipt].ds_nalpha));
       }
    }
    if(Nbeta[ipt].on>=1){
      n_cv += 1;
      stat_avg->nbeta_on = Nbeta[ipt].on;
      Nbeta[ipt].bdy = 1;
      Nbeta[ipt].Fx  = (double*)cmalloc(Nbeta[ipt].n_atm_f*sizeof(double))-1;
      Nbeta[ipt].Fy  = (double*)cmalloc(Nbeta[ipt].n_atm_f*sizeof(double))-1;
      Nbeta[ipt].Fz  = (double*)cmalloc(Nbeta[ipt].n_atm_f*sizeof(double))-1;
      Nbeta[ipt].data = (double*)cmalloc(dinfo[ipt].to_file_freq*sizeof(double))-1;
      Nbeta[ipt].data_s = (double*)cmalloc(dinfo[ipt].to_file_freq*sizeof(double))-1;
      zero_forces(&Nbeta[ipt],Nbeta[ipt].n_atm_f);
      zero(Nbeta[ipt].data,dinfo[ipt].to_file_freq);
      zero(Nbeta[ipt].data_s,dinfo[ipt].to_file_freq);
      if(Nbeta[ipt].on==1||Nbeta[ipt].on==3){
        zero_allstats(&(general_data->stat_avg[ipt].ds_nbeta));
      }
    }

    if(Dih_cor[ipt].on>=1||Nalpha[ipt].on>=1||Nbeta[ipt].on>=1){
      clatoms_info->dev_bb = (DEV_TRI*)cmalloc((clatoms_info->num_ca-3)*sizeof(DEV_TRI))-1;
      clatoms_info->tri_bb = (double **)cmalloc((clatoms_info->num_ca-3)*sizeof(double *))-1;
      for(i=1;i<=clatoms_info->num_ca-3;i++){
         clatoms_info->tri_bb[i] = (double*)cmalloc(2*sizeof(double))-1;
      }
    }

    if(npara_temps==1&&dinfo[ipt].bias_on==1){
      stat_avg->n_cv = n_cv;
      stat_avg->n_list = n_cv; 
    }/*endif bias*/ 

    if (Ree[ipt].on ==1||Rgyr[ipt].on == 1||NH[ipt].on == 1||num_phi>=1||Dih_cor[ipt].on==1
	||Nalpha[ipt].on==1||Nbeta[ipt].on==1) {
       dinfo[ipt].dafed_on = 1;
       if (general_data->timeinfo.ix_respa > 1) {
         printf("XI_respa for d-AFED must be 1!!\n");
         printf("XI=%d --> %d\n",general_data->timeinfo.ix_respa,1);
         general_data->timeinfo.ix_respa=1;
       } 
    }
    else dinfo[ipt].dafed_on = 0;
    if (Ree[ipt].on ==2||Rgyr[ipt].on ==2||NH[ipt].on ==2||Dih_cor[ipt].on==2
	||Nalpha[ipt].on==2||Nbeta[ipt].on==2) dinfo[ipt].dafed_on = 2;
    if (num_phi>=1){if(Phi[ipt][1].on==2)dinfo[ipt].dafed_on = 2;}
    if (Ree[ipt].on ==3||Rgyr[ipt].on ==3||NH[ipt].on ==3
	||Dih_cor[ipt].on==3||Nalpha[ipt].on==3||Nbeta[ipt].on==3) dinfo[ipt].dafed_on = 3;
    if (num_phi>=1){if(Phi[ipt][1].on==3)dinfo[ipt].dafed_on = 3;}
  
    if (dinfo[ipt].dafed_on > 0) {
      iptoff = ipt + general_data->tempering_ctrl.npara_temps_proc_off;
      sprintf(name_1,"%s.%d",dinfo[ipt].traj_fn,iptoff);
      sprintf(name_2,"%s.%d",dinfo[ipt].traj_sr_fn,iptoff);
      t1 = cfopen(name_1,"w");
      t2 = cfopen(name_2,"w");
 
      fprintf(t1,"# kTs   ms   ks      dt  Ree  Rgyr NH Dih_cor Nalpha Nbeta\n"); 
      fprintf(t2,"# kTs   ms   ks      dt  Ree  Rgyr NH Dih_cor Nalpha Nbeta\n"); 
      fprintf(t1,"# %.10g %.10g %.10g %.10g %d %d %d %d %d %d\n",
                Ree[ipt].kTs*BOLTZ, Ree[ipt].ms/PROT_MASS,
                Ree[ipt].ks*BOLTZ/(BOHR*BOHR), Ree[ipt].dt*TIME_CONV,
                Ree[ipt].on, Rgyr[ipt].on, NH[ipt].on, Dih_cor[ipt].on, Nalpha[ipt].on, Nbeta[ipt].on);
      fprintf(t2,"# %.10g %.10g %.10g %.10g %d %d %d %d %d %d\n",
                Ree[ipt].kTs*BOLTZ, Ree[ipt].ms/PROT_MASS,
                Ree[ipt].ks*BOLTZ/(BOHR*BOHR), Ree[ipt].dt*TIME_CONV,
                Ree[ipt].on, Rgyr[ipt].on, NH[ipt].on, Dih_cor[ipt].on, Nalpha[ipt].on, Nbeta[ipt].on);
      fprintf(t1,"# step ");
      fprintf(t2,"# step ");
      if (Ree[ipt].on >= 1) {
        fprintf(t1,"s_Ree ");
        fprintf(t2,"Ree(r) ");
      }
      if (Rgyr[ipt].on >= 1) {
        fprintf(t1,"s_Rgyr ");
        fprintf(t2,"Rgyr(r) ");
      }
      if (NH[ipt].on >= 1) {
        fprintf(t1,"s_NH ");
        fprintf(t2,"NH(r) ");
      }
      if(Dih_cor[ipt].on>=1){
	fprintf(t1,"s_Dih_cor ");
        fprintf(t2,"Dih_cor(r) ");
      }
      if(Nalpha[ipt].on>=1){
	fprintf(t1,"s_Nalpha ");
	fprintf(t2,"Nalpha(r) ");
      }
      if(Nbeta[ipt].on>=1){
	fprintf(t1,"s_Nbeta ");
	fprintf(t2,"Nbeta(r) ");
      }
      for(i=1;i<=num_phi;i++){
        fprintf(t1,"s_phi%i ",i);
        fprintf(t2,"Phi%i(r) ",i);
      }
      fprintf(t1,"\n"); fprintf(t2,"\n");
      fclose(t1);  fclose(t2);
    }
    dinfo[ipt].to_file_curr = 1;
    dinfo[ipt].curr = -1;
    dinfo[ipt].timestep = 0;
    if (dinfo[ipt].n_respa < 1) dinfo[ipt].n_respa = 1;
    else printf("*** Turning on experimental r-RESPA-d-AFED!!!**\n");
    dinfo[ipt].i_respa = dinfo[ipt].n_respa;
    if(general_data->tempering_ctrl.para_type==2){   
      stat_avg->w_bin = (double *)cmalloc(stat_avg->n_list*sizeof(double))-1;
      stat_avg->cv_x_min = (double *)cmalloc(stat_avg->n_list*sizeof(double))-1;
      stat_avg->cv_x_max = (double *)cmalloc(stat_avg->n_list*sizeof(double))-1;
      if(Ree[ipt].on>=1){
        stat_avg->w_bin[1] = 0.05;
        dafed_freq = stat_avg->Ree_freq;
        dafed_freq->x = 0.0;
        dafed_freq->freq = 0;
        dafed_freq->right = NULL;
        dafed_freq->left  = NULL;
      }
      if(Rgyr[ipt].on>=1){
        stat_avg->w_bin[1] = 0.05;
        dafed_freq = stat_avg->Rgyr_freq;
        dafed_freq->x = 0.0;
        dafed_freq->freq = 0;
        dafed_freq->right = NULL;
        dafed_freq->left  = NULL;
      }
      if(NH[ipt].on>=1){
        stat_avg->w_bin[1] = 0.05;
        dafed_freq = stat_avg->NH_freq;
        dafed_freq->x = 0.0;
        dafed_freq->freq = 0;
        dafed_freq->right = NULL;
        dafed_freq->left  = NULL;
      }
      stat_avg->n_freq = 1;
    }/*endif para_type*/
    stat_avg->bias_on = dinfo[ipt].bias_on;
    stat_avg->steps_bias = dinfo[ipt].steps_bias;
    stat_avg->num_bias = dinfo[ipt].num_bias;
    //printf("bias_on %i,steps_bias %i,num_bias %i\n",dinfo[ipt].bias_on,dinfo[ipt].steps_bias,dinfo[ipt].num_bias);
    if(npara_temps==1&&dinfo[ipt].bias_on==1){
      stat_avg->data = (DATA_BIAS*)cmalloc(steps_bias_s*sizeof(DATA_BIAS))-1;
      for(i=1;i<=steps_bias_s;i++){
         stat_avg->data[i].x = (double *)cmalloc(n_cv*sizeof(double))-1;
      }
      stat_avg->Ree_bin     = 2.0;
      stat_avg->Rgyr_bin    = 0.2;
      stat_avg->NH_bin      = 0.1;
      stat_avg->Phi_bin     = M_PI/20.0;
      stat_avg->Dih_cor_bin = 0.05;
      stat_avg->Nalpha_bin  = 0.2;
      stat_avg->Nbeta_bin   = 0.05;
    }/*endif bias_on*/
   }/*endfor ipt*/
   if(dinfo[1].bias_on==1){bias_init(class,general_data);}
 }/*endif myid*/
 Barrier(class->communicate.world);

  
 /*        Broadcast DAFED_INFO to all nodes                   */
 printf("start boadcast\n");
   
 if(class->communicate.np > 1){
   for(ipt=1;ipt<=npara_temps_proc;ipt++){
    Barrier(class->communicate.world);
    Address(&(dinfo[ipt].dafed_on),&displs[0]);
    types[0] = MPI_INT;
    blockcounts[0] = ndinfo;
    Barrier(class->communicate.world);
    Type_struct(1,blockcounts,displs,types,&dinfo_info_comm);
    Barrier(class->communicate.world);
    printf("ipt %i\n",ipt);
    Type_commit(&dinfo_info_comm);
    Barrier(class->communicate.world);
    Bcast(MPI_BOTTOM,1,dinfo_info_comm,0,class->communicate.world);
    Barrier(class->communicate.world);
    Type_free(&dinfo_info_comm);
    Barrier(class->communicate.world);
  }
 }
 //exit(0);
 printf("finish bdcast\n");
 //printf("i2_7 %d\n",Rgyr[1].i2[7]);
}
