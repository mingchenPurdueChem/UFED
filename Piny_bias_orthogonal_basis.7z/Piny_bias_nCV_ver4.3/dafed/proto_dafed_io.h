void dafed_trajectory_io(CLATOMS_INFO *, TIMEINFO *,int,int);
void dafed_to_file(DAFED *, DAFED_INFO *);
void dafed_from_file(DAFED *, DAFED_INFO *);
void dafed_kt_io_ree(DAFED_STAT *, double, int);
void dafed_kt_io_rgyr(DAFED_STAT *, double, int);
void dafed_kt_io_nh(DAFED_STAT *, double, int);
void dafed_kt_io_phi(DAFED_STAT	*, double, int, int);
void dafed_screen_io(CLASS *, GENERAL_DATA *, int);
