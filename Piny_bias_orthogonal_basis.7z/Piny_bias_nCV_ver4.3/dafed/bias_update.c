#include "standard_include.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_cp.h"
#include "../typ_defs/typedefs_par.h"
#include "../typ_defs/typedefs_stat.h"
#include "../proto_defs/proto_friend_lib_entry.h"
#include "../proto_defs/proto_math.h"
#include "../proto_defs/proto_dafed_helper.h"
#include "../proto_defs/proto_dafed_integrate.h"
#include "../proto_defs/proto_dafed_io.h"
#include "../proto_defs/proto_dafed_energy.h"
#include "../proto_defs/proto_dafed_bias.h"


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void bias_init(CLASS *class,GENERAL_DATA *general_data)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */
  STAT_AVG *stat_avg          = general_data->stat_avg;
  CLATOMS_INFO *clatoms_info  = &(class->clatoms_info);
  DAFED_INFO *dinfo           = clatoms_info->daf_info;
  DAFED *Ree                  = clatoms_info->Ree;
  DAFED *Rgyr                 = clatoms_info->Rgyr;
  DAFED *NH                   = clatoms_info->NH;
  DAFED *Dih_cor              = clatoms_info->Dih_cor;
  DAFED *Nalpha               = clatoms_info->Nalpha;
  DAFED *Nbeta                = clatoms_info->Nbeta;
  DAFED **Phi                 = clatoms_info->Phi;
  BIAS_PACK *bias;        
  int npara_temps_proc        = general_data->tempering_ctrl.npara_temps_proc;
  int ipt,i,j,k,ind,test,n_cv,i_bias,fun_prod;
  int num_phi                 = clatoms_info->num_phi;
  int num_bias;
  int num_co;
  int nfun_cv;

  double kTs_ini;
  double temp_diff;
  FILE *readin;

  /*-------------------------malloc------------------------------*/
  clatoms_info->bias = (BIAS_PACK*)cmalloc(npara_temps_proc*sizeof(BIAS_PACK))-1;
  for(ipt=1;ipt<=npara_temps_proc;ipt++){
    bias = &(clatoms_info->bias[ipt]);
    n_cv = stat_avg[ipt].n_cv;
    nfun_cv = dinfo[ipt].nfun_cv;
    num_co    = dinfo[ipt].nfun_tot;
    stat_avg[ipt].i_bias = 0;
    stat_avg[ipt].bias_pot = 0.0;
    /*if(n_cv>=3){
      printf("-----------Bias potential only support one or two dimmensional FES----------\n");
      fflush(stdout);
      exit(0);
    }*/
    /* Identify CVs  */
    bias->cv_type = (int *)cmalloc(n_cv*sizeof(int))-1;
    ind = 0;
    if(Ree[ipt].on>=1){
      ind += 1;
      bias->cv_type[ind] = 1;
    }
    if(Rgyr[ipt].on>=1){
      ind += 1;
      bias->cv_type[ind] = 2;
    }
    if(NH[ipt].on>=1){
      ind += 1;
      bias->cv_type[ind] = 3;
    }
    for(i=1;i<=num_phi;i++){
       ind += 1;
       bias->cv_type[ind] = 4;
    }
    if(Dih_cor[ipt].on>=1){
      ind += 1;
      bias->cv_type[ind] = 5;
    }
    if(Nalpha[ipt].on>=1){
      ind += 1;
      bias->cv_type[ind] = 6;
    }
    if(Nbeta[ipt].on>=1){
      ind += 1;
      bias->cv_type[ind] = 7;
    }
    test = 0;
    for(i=1;i<=n_cv;i++){
       if(bias->cv_type[i]==4){test += 1;}
    }/*endfor n_cv*/
    bias->test_type = test;
    if(test!=0&&test!=n_cv){
      printf("-----------Mixed type is not ready yet----------------------------\n");
      fflush(stdout);
      exit(0);
    }
    /* Initialize coefficient stuff  */ 
      
    bias->min = (double *)cmalloc(n_cv*sizeof(double))-1;
    bias->max = (double *)cmalloc(n_cv*sizeof(double))-1;
    for(i=1;i<=n_cv;i++){
       bias->min[i] = 10000000.0;
       bias->max[i] = -1000000.0;
    }
    bias->n_fun = (int *)cmalloc(n_cv*sizeof(int))-1;
    fun_prod = 1;
    for(i=1;i<=n_cv;i++){
       bias->n_fun[i] = nfun_cv;
       fun_prod *= nfun_cv;
    }
    /*temp use for ree na*/
    /*bias->n_fun[1] = 16;
    bias->n_fun[2] = 40;
    fun_prod = 640;*/
    /*-------------------*/
    if(fun_prod>=num_co){bias->n_coeff = num_co;}
    else{bias->n_coeff = fun_prod;}
    bias->coeff_list = (CO*)cmalloc(bias->n_coeff*sizeof(CO))-1;
    for(i=1;i<=bias->n_coeff;i++){
       bias->coeff_list[i].order = (ORD*)cmalloc(n_cv*sizeof(ORD))-1;
    }

   if(dinfo[ipt].bias_readin==1){
     dinfo[ipt].calc_flag = 1;//calc bias PE for prelim
     if(dinfo[ipt].num_fun_readin!=bias->n_coeff){
        printf("@@@@@@@@@@@@@@@@@@error@@@@@@@@@@@@@@@@@@\n");
        printf("Inconsistant number of funcion.\n");
        printf("You require bases function for bias is %i\n",bias[1].n_coeff);
        printf("But you have %i bases in readin file\n",dinfo[ipt].num_fun_readin);
        printf("@@@@@@@@@@@@@@@@@@error@@@@@@@@@@@@@@@@@@\n");
        fflush(stdout);
        exit(1);
      }
      readin = fopen("bias_readin","r");
      for(j=1;j<=n_cv;j++){
        fscanf(readin,"%lg",&(bias->min[j]));
      }
      for(j=1;j<=n_cv;j++){
        fscanf(readin,"%lg",&(bias->max[j]));
      }
      for(j=1;j<=dinfo[ipt].num_fun_readin;j++){
        fscanf(readin,"%lg",&(bias->coeff_list[j].c));
        for(k=1;k<=n_cv;k++){
           fscanf(readin,"%i",&(bias->coeff_list[j].order[k].n));
           fscanf(readin,"%i",&(bias->coeff_list[j].order[k].type));
        }/*endfor k*/
      }/*endfor j*/
      fclose(readin);
      for(j=1;j<=n_cv;j++){
        printf("%lg        ",bias->min[j]);
      }
      printf("\n");
      for(j=1;j<=n_cv;j++){
         printf("%lg        ",bias->max[j]);
      }
      printf("\n");
      for(j=1;j<=dinfo[ipt].num_fun_readin;j++){
         printf("%lg ",bias->coeff_list[j].c);
         for(k=1;k<=n_cv;k++){
            printf("%i %i ",bias->coeff_list[j].order[k].n,bias->coeff_list[j].order[k].type);
         }
         printf("\n");
      }
      printf("=============================\n");
   }/*endif*/
   if(dinfo[ipt].grad_temp_on==1){
     num_bias = dinfo[ipt].num_bias;
     temp_diff = dinfo[ipt].grad_temp_diff;
     if(Ree[ipt].on>=1){
       Ree[ipt].ms *= (Ree[ipt].kTs+num_bias*temp_diff)/(Ree[ipt].kTs);
       Ree[ipt].kTs += num_bias*temp_diff;
     }
     if(Rgyr[ipt].on>=1){
       Rgyr[ipt].ms *= (Rgyr[ipt].kTs+num_bias*temp_diff)/(Rgyr[ipt].kTs);
       Rgyr[ipt].kTs += num_bias*temp_diff;
     }
     if(NH[ipt].on>=1){
       NH[ipt].ms *= (NH[ipt].kTs+num_bias*temp_diff)/(NH[ipt].kTs);
       NH[ipt].kTs += num_bias*temp_diff;
     }
     if(Dih_cor[ipt].on>=1){
       Dih_cor[ipt].ms *= (Dih_cor[ipt].kTs+num_bias*temp_diff)/(Dih_cor[ipt].kTs);
       Dih_cor[ipt].kTs += num_bias*temp_diff;
     }
     if(Nalpha[ipt].on>=1){
       Nalpha[ipt].ms *= (Nalpha[ipt].kTs+num_bias*temp_diff)/(Nalpha[ipt].kTs);
       Nalpha[ipt].kTs += num_bias*temp_diff;
     }
     if(Nbeta[ipt].on>=1){
       Nbeta[ipt].ms *= (Nbeta[ipt].kTs+num_bias*temp_diff)/(Nbeta[ipt].kTs);
       Nbeta[ipt].kTs += num_bias*temp_diff;
     }
     for(i=1;i<=num_phi;i++){
	Phi[ipt][i].ms *= (Phi[ipt][i].kTs+num_bias*temp_diff)/(Phi[ipt][i].kTs);
        Phi[ipt][i].kTs += num_bias*temp_diff;
     }
   }//endif grad_temp_on
 }/*endfor ipt*/

/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void bias_update(CLASS *class,GENERAL_DATA *general_data,int ipt, int i_bias)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */

  CLATOMS_INFO *clatoms_info     = &(class->clatoms_info);
  STAT_AVG *stat_avg             = &(general_data->stat_avg[ipt]);
  DATA_BIAS *data_b              = stat_avg->data;
  BIAS_PACK *bias                = &(clatoms_info->bias[ipt]);
  DAFED_INFO *dinfo              = &(clatoms_info->daf_info[ipt]);
  DAFED *Ree                  = clatoms_info->Ree;
  DAFED *Rgyr                 = clatoms_info->Rgyr;
  DAFED *NH                   = clatoms_info->NH;
  DAFED *Dih_cor              = clatoms_info->Dih_cor;
  DAFED *Nalpha               = clatoms_info->Nalpha;
  DAFED *Nbeta                = clatoms_info->Nbeta;
  DAFED **Phi                 = clatoms_info->Phi;
  CO *coeff;
  int num_bias                   = dinfo->num_bias;
  int n_cv                       = stat_avg->n_cv;
  int steps_bias                 = dinfo->steps_bias/10;
  int test                       = bias->test_type;
  int num_phi                    = clatoms_info->num_phi;
  int *n_fun                     = bias->n_fun;
  int n_coeff                    = bias->n_coeff;
  int bias_readin                = dinfo->bias_readin;
  int i,j,k,l,n_bin,ind_freq,count,n_total,n_fun_total,iflag,ind,order,peak;
  int *ind_pick;
  int div,res;
  double Ree_bin                 = stat_avg->Ree_bin;
  double Rgyr_bin                = stat_avg->Rgyr_bin;
  double NH_bin                  = stat_avg->NH_bin;
  double Phi_bin                 = stat_avg->Phi_bin; 
  double Dih_bin                 = stat_avg->Dih_cor_bin;
  double Na_bin                  = stat_avg->Nalpha_bin;
  double Nb_bin                  = stat_avg->Nbeta_bin;
  double kT                      = clatoms_info->Rgyr[ipt].kTs; 
  double num_ca                  = (double)(clatoms_info->num_ca);

  double fac_bias                = dinfo->fac_bias;
  double a,b,w_bin,prob,w_bin_prod,x,prod,sum,prefac,coeff_modu,coeff_max;
  double *min_old,*max_old;
  double **bias_pot_value,**bias_pot_dev;
  double temp_diff;
  double ***integ;
  double pi = 3.14159265358979323846;
  double sqrt_2 = 0.707106781;
  double test_sum; //using for debug
  int *freq,*n_bin_cv,*n_fun_cu;
  FILE *file;
  //for debug
  FILE *file_fes;

  dinfo->i_bias = i_bias;
  printf("start fes\n");
/*-------------------------------------------------------------------------*/
/* Setup FES bins from data if necessary  */
  n_bin_cv = (int*)cmalloc((1+n_cv)*sizeof(int))-1;
  min_old  = (double *)cmalloc(n_cv*sizeof(double))-1;
  max_old  = (double *)cmalloc(n_cv*sizeof(double))-1;
  
  for(i=1;i<=n_cv;i++){
    min_old[i] = bias->min[i];
    max_old[i] = bias->max[i];
    if(bias->cv_type[i]!=4){
      switch(bias->cv_type[i]){
	case 1:w_bin = Ree_bin;break;
	case 2:w_bin = Rgyr_bin;break;
	case 3:w_bin = NH_bin;break;
        case 5:w_bin = Dih_bin;break;
        case 6:w_bin = Na_bin;break;
        case 7:w_bin = Nb_bin;break;
      }
      for(j=1;j<=steps_bias;j++){
         if(j==1){
            bias->min[i] = data_b[j].x[i];
            bias->max[i] = data_b[j].x[i];
         }
         else{
            if(bias->min[i]>data_b[j].x[i]){
              bias->min[i] = data_b[j].x[i];
            }
            if(bias->max[i]<data_b[j].x[i]){
              bias->max[i] = data_b[j].x[i];
            }
         }/*endif*/
      }/*endfor j*/ 
      bias->min[i] = (double)((int)(bias->min[i]/w_bin))*w_bin;
      bias->max[i] = (double)((int)(bias->max[i]/w_bin)+1)*w_bin;
      if(bias->cv_type[i]==5){bias->max[i] = num_ca-4.0;}
      if(bias->cv_type[i]==6||bias->cv_type[i]==7){bias->max[i] = num_ca-3.0;}
      if(bias->min[i]>min_old[i]){bias->min[i] = min_old[i];}
      if(bias->max[i]<max_old[i]){bias->max[i] = max_old[i];}
    }/*endif cv_type*/
    if(bias->cv_type[i]==4){
      bias->min[i] = -M_PI;
      bias->max[i] = M_PI;
    }
  }/*endfor i*/
  /*--------------- For debug ------------------*/
  /*bias->min[1] = 5.56;
  bias->max[1] = 51.45;
  bias->min[2] = 0.9;
  bias->max[2] = 6.1;*/

  /*--------------------------------------------*/
  n_bin_cv[1+n_cv] = 1;
  i = 1;
  for(i=n_cv;i>=1;i--){
    switch(bias->cv_type[i]){
     case 1:w_bin = Ree_bin;break;
     case 2:w_bin = Rgyr_bin;break;
     case 3:w_bin = NH_bin;break;
     case 4:w_bin = Phi_bin;break;
     case 5:w_bin = Dih_bin;break;
     case 6:w_bin = Na_bin;break;
     case 7:w_bin = Nb_bin;break;
    }
    a = bias->min[i];
    b = bias->max[i];
    n_bin_cv[i] = n_bin_cv[i+1]*(int)((b-a+0.0001*w_bin)/w_bin);
  }/*endfor n_cv*/
  n_total = n_bin_cv[1];
  bias->bias_pot_or = (BIAS_POT*)cmalloc(n_total*sizeof(BIAS_POT))-1;
  freq = (int*)cmalloc(n_total*sizeof(int))-1;
  for(i=1;i<=n_total;i++){
     bias->bias_pot_or[i].x = (double *)cmalloc(n_cv*sizeof(double))-1;
     freq[i] = 0;
     res = i-1;
     for(j=1;j<=n_cv;j++){
       switch(bias->cv_type[j]){
        case 1:w_bin = Ree_bin;break;
        case 2:w_bin = Rgyr_bin;break;
        case 3:w_bin = NH_bin;break;
        case 4:w_bin = Phi_bin;break;
        case 5:w_bin = Dih_bin;break;
        case 6:w_bin = Na_bin;break;
        case 7:w_bin = Nb_bin;break;
       }
       a = bias->min[j];
       div = (int)(res/n_bin_cv[j+1]);
       res = res%n_bin_cv[j+1];
       bias->bias_pot_or[i].x[j] = a+(div+0.5)*w_bin;
     }
  }/*endfor n_bin_cv*/
  //exit(0);
  /*for(i=1;i<=n_total;i++){
     for(j=1;j<=n_cv;j++){
        printf("%lg ",bias->bias_pot_or[i].x[j]);
     }
     printf("\n");
  }*/
  printf("finish setup bins\n");

/*-------------------------------------------------------------------------*/
/* Setup frequency */
  count = 0;
  for(i=1;i<=steps_bias;i++){
    ind_freq = 1;
    for(j=1;j<=n_cv;j++){
      a = bias->min[j];
      switch(bias->cv_type[j]){
       case 1:w_bin = Ree_bin;break;
       case 2:w_bin = Rgyr_bin;break;
       case 3:w_bin = NH_bin;break;
       case 4:w_bin = Phi_bin;break;
       case 5:w_bin = Dih_bin;break;
       case 6:w_bin = Na_bin;break;
       case 7:w_bin = Nb_bin;break;
      }
      ind_freq += (int)((data_b[i].x[j]-a)/w_bin)*n_bin_cv[j+1];
    }
    freq[ind_freq] += 1;
    count += 1;
  }/*endfor steps_bias*/
  //exit(0);
  printf("finish setup frequence\n");
/*-------------------------------------------------------------------------*/
/* Check zero */
  peak = 0;
  for(i=1;i<=n_total;i++){
     if(freq[i]>peak){peak = freq[i];}
  }
  for(i=1;i<=n_total;i++){
     if((double)(freq[i])<peak*fac_bias){freq[i] = (int)(peak*fac_bias);}
     //printf("ind %i, freq %i\n",i,freq[i]);
  }
  
  printf("finish checking zero");
/*-------------------------------------------------------------------------*/
/* Construct Numerical FES */
  w_bin_prod = 1.0;
  for(i=1;i<=n_cv;i++){
    switch(bias->cv_type[1]){
     case 1:w_bin_prod *= Ree_bin;break;
     case 2:w_bin_prod *= Rgyr_bin;break;
     case 3:w_bin_prod *= NH_bin;break;
     case 4:w_bin_prod *= Phi_bin;break;
     case 5:w_bin = Dih_bin;break;
     case 6:w_bin = Na_bin;break;
     case 7:w_bin = Nb_bin;break;

    }
  }
  for(i=1;i<=n_total;i++){
     prob = (double)(freq[i])/*/(double)(count)/w_bin_prod*/;
     bias->bias_pot_or[i].V_x = kT*log(prob);  
  }
  /*-----------add past bias---------*/
  bias_pot_value = (double **)cmalloc(n_coeff*sizeof(double*))-1;
  for(i=1;i<=n_coeff;i++){
     bias_pot_value[i] = (double *)cmalloc(n_cv*sizeof(double))-1;
  }

  if(i_bias>=1||bias_readin==1){
    calc_bias_pot(bias,min_old,max_old,bias_pot_value,n_cv,n_total);
  }
     
  /*-----------debug-----------------*/
  /*file_fes = fopen("fes","r");
  for(i=1;i<=n_total;i++){
    for(j=1;j<=n_cv;j++){
       fscanf(file_fes,"%lg",&(bias->bias_pot_or[i].x[j]));
    }
    fscanf(file_fes,"%lg",&(bias->bias_pot_or[i].V_x));
  }
  printf("n_total %i\n",n_total);*/
  /*for(i=1;i<=n_total;i++){
    printf("%lg %lg %lg\n",bias->bias_pot_or[i].x[1],bias->bias_pot_or[i].x[2],bias->bias_pot_or[i].V_x);
  }*/
  /*---------------------------------*/

  /*test_sum = 0.0;*/
  /*for(i=1;i<=n_total;i++){
     printf("ind %i, pot %lg\n",i,bias->bias_pot_or[i].V_x);
  }*/
  //exit(0);
  
  printf("finish numerical fes\n");
/*-------------------------------------------------------------------------*/
/* Fit FES: 1.Molloc coefficient list*/

  n_fun_cu = (int*)cmalloc((n_cv+1)*sizeof(int))-1;
  n_fun_cu[n_cv+1] = 1;
  for(i=n_cv;i>=1;i--){
     n_fun_cu[i] = n_fun_cu[i+1]*n_fun[i];
  }
  n_fun_total = n_fun_cu[1];
  coeff = (CO*)cmalloc(n_fun_total*sizeof(CO))-1;
  for(i=1;i<=n_fun_total;i++){
     //coeff[i].type = (int*)cmalloc(n_cv*sizeof(int))-1;
     coeff[i].order = (ORD*)cmalloc(n_cv*sizeof(ORD))-1;
     res = i-1;
     for(j=1;j<=n_cv;j++){
        div = (int)(res/n_fun_cu[j+1]);
        res = res%n_fun_cu[j+1];
        if(bias->cv_type[j]!=4){
          coeff[i].order[j].type = 0;
        }
        if(bias->cv_type[j]==4){
          if(div%2==0){
            coeff[i].order[j].type = 1;
          }
          else{
            coeff[i].order[j].type = 2;
          }
        }/**/
        coeff[i].order[j].n = div;
     }/*endfor n_cv*/
  }/*endfor n_fun_total*/
  //printf("finish step 1\n");
  //exit(0);
  printf("finish molloc coefficient\n");
/*-------------------------------------------------------------------------*/
/* Fit FES: 2.Get all integrated values for each bins */
   
  integ = (double ***)cmalloc(n_cv*sizeof(double **))-1;
  for(i=1;i<=n_cv;i++){
     integ[i] = (double **)cmalloc(n_fun[i]*sizeof(double*))-1;
     n_bin = (int)(n_bin_cv[i]/n_bin_cv[i+1]);
     for(j=1;j<=n_fun[i];j++){
        integ[i][j] = (double*)cmalloc(n_bin*sizeof(double))-1; 
     }/*endfor n_fun*/
  }/*n_cv*/
  for(i=1;i<=n_cv;i++){
     a = bias->min[i];
     b = bias->max[i];
     n_bin = (int)(n_bin_cv[i]/n_bin_cv[i+1]);
     switch(bias->cv_type[i]){
      case 1:w_bin = Ree_bin;break;
      case 2:w_bin = Rgyr_bin;break;
      case 3:w_bin = NH_bin;break;
      case 4:w_bin = Phi_bin;break;
      case 5:w_bin = Dih_bin;break;
      case 6:w_bin = Na_bin;break;
      case 7:w_bin = Nb_bin;break;
     }
   //  printf("i %i,n_bin %i\n",i,n_bin);
     for(k=1;k<=n_bin;k++){
	//printf("bin ind %i\n",k);
        x = a+(k-0.5)*w_bin;
        for(j=1;j<=n_fun[i];j++){
          if(bias->cv_type[i]!=4){
            integ[i][j][k] = L_int(a,b,x,w_bin,j-1)*(2.0*(j-1)+1.0)*0.5;
	    //printf("i %i,j %i,k %i,integ %lg\n",i,j,k,integ[i][j][k]);
          }
          if(bias->cv_type[i]==4&&j%2==1){
            order = (int)((j-1)/2);
            if(order==0){integ[i][j][k] = w_bin*0.5/M_PI;}
            else{
              integ[i][j][k] = (sin(order*(x+w_bin*0.5))-sin(order*(x-w_bin*0.5)))/(double)(order)/M_PI;
            }
          }
          if(bias->cv_type[i]==4&&j%2==0){
            order = (int)(j/2);
            integ[i][j][k] = (cos(order*(x-w_bin*0.5))-cos(order*(x+w_bin*0.5)))/(double)(order)/M_PI;
          }
        }/*endfor n_fun*/
     }/*endfor n_bin*/
  }/*endfor n_cv*/

 /* for(i=1;i<=n_cv;i++){
     for(j=1;j<=n_fun[i];j++){
        test_sum = 0.0;
	n_bin = (int)(n_bin_cv[i]/n_bin_cv[i+1]);
        for(k=1;k<=n_bin;k++){
           test_sum += integ[i][j][k];
           //printf("%lg ",integ[i][j][k]);
        }
        printf("cv %i,fun %i,test sum %lg\n",i,j,test_sum);
     }
     printf("-------------------------------\n");
  }*/
  printf("finish integration\n");  

/*-------------------------------------------------------------------------*/
/* Fit FES: 3.Calculate coefficient */

  for(i=1;i<=n_fun_total;i++){
     sum = 0.0;
     for(j=1;j<=n_total;j++){
       prod = 1.0;
       for(k=1;k<=n_cv;k++){
          switch(bias->cv_type[k]){
           case 1:w_bin = Ree_bin;break;
           case 2:w_bin = Rgyr_bin;break;
           case 3:w_bin = NH_bin;break;
           case 4:w_bin = Phi_bin;break;
           case 5:w_bin = Dih_bin;break;
           case 6:w_bin = Na_bin;break;
           case 7:w_bin = Nb_bin;break;
          }
          x = bias->bias_pot_or[j].x[k];
          a = bias->min[k];
          ind = (int)((x-a)/w_bin)+1;
	  //printf("ind %i\n",ind);
          prod *= integ[k][coeff[i].order[k].n+1][ind];
       }/*endfor n_cv*/
       sum += prod*bias->bias_pot_or[j].V_x;
     }/*endfor n_total*/
     coeff[i].c = sum;
  }/*endfor n_fun_total*/

  printf("finish calculating coefficient\n");
 
/*-------------------------------------------------------------------------*/
/* Fit FES: 4.Pick the important coeffcients  */
  
  ind_pick = (int*)cmalloc(n_coeff*sizeof(int))-1;
  for(i=1;i<=n_coeff;i++){
     ind_pick[i] = 0;
  }
  for(i=1;i<=n_coeff;i++){
    coeff_max = 0.0;
    for(j=1;j<=n_fun_total;j++){
       coeff_modu = coeff[j].c*coeff[j].c;
       if(coeff_modu>=coeff_max&&find(j,ind_pick,n_coeff)==0){
         ind = j;
         coeff_max = coeff_modu;
       }
    }
    ind_pick[i] = ind;
  }
  for(i=1;i<=n_coeff;i++){
     for(j=1;j<=n_cv;j++){
        bias->coeff_list[i].order[j].n = coeff[ind_pick[i]].order[j].n;
        bias->coeff_list[i].order[j].type = coeff[ind_pick[i]].order[j].type;
     }
     bias->coeff_list[i].c = coeff[ind_pick[i]].c;
  }
  //printf("finish step 4\n");  

  printf("finish picking important coeffcients\n");
  //exit(0);

/*-------------------------------------------------------------------------*/
/* IO:print coeffcient  */
  file = fopen("Bias_coeff","a");
  
  fprintf(file,"#                ");
  iflag = 0;
  for(i=1;i<=n_cv;i++){
    printf("index i %i\n",i);
    switch(bias->cv_type[i]){
     case 1:fprintf(file,"Ree ");
            break;
     case 2:fprintf(file,"Rgyr ");
            break;
     case 3:fprintf(file,"NH ");
            break;
     case 5:fprintf(file,"Dih ");
            break;
     case 6:fprintf(file,"Na ");
            break;
     case 7:fprintf(file,"Nb ");
            break;
     case 4:iflag += 1;
            fprintf(file,"Phi%i ",iflag);
            break;
    }
  }/*endfor*/
  fprintf(file,"\n");

  fprintf(file,"                ");
  for(i=1;i<=n_cv;i++){
     fprintf(file,"%lg ",bias->min[i]);
  }
  fprintf(file,"\n");
  fprintf(file,"                ");
  for(i=1;i<=n_cv;i++){
     fprintf(file,"%lg ",bias->max[i]);
  }
  fprintf(file,"\n");
  for(i=1;i<=n_coeff;i++){
     fprintf(file,"%16.10lg ",bias->coeff_list[i].c);
     for(j=1;j<=n_cv;j++){
        fprintf(file,"%i %i ",bias->coeff_list[i].order[j].n,bias->coeff_list[i].order[j].type);
     }
     fprintf(file,"\n");
  }
  fprintf(file,"================================================\n");
  fclose(file);

  printf("finish printing\n");

/*-------------------------------------------------------------------------*/
/* Free all local variables  */
  for(i=1;i<=n_total;i++){
    free(&(bias->bias_pot_or[i].x[1]));
  }
  free(&(bias->bias_pot_or[1]));

  for(i=1;i<=n_fun_total;i++){
     free(&(coeff[i].order[1]));
  }
  free(&(coeff[1]));
  free(&(ind_pick[1]));

  for(i=1;i<=n_coeff;i++){
     free(&(bias_pot_value[i][1]));
  }
  free(&(bias_pot_value[1]));

  for(i=1;i<=n_cv;i++){
     for(j=1;j<=n_fun[i];j++){
        free(&(integ[i][j][1]));
     }
     free(&(integ[i][1]));
  }

  free(&(integ[1]));
  free(&(freq[1]));
  free(&(n_fun_cu[1]));
  free(&(n_bin_cv[1]));

   printf("finish freeing local varialbes\n");

  /* For debug input known coeff*/

   /*bias->min[1] = 5.56;
   bias->max[1] = 51.45;

   file_fes = fopen("coeff_debug","r");
   n_coeff = 10;
   bias->n_coeff = 10;
   bias->coeff_list = (CO *)cmalloc(n_coeff*sizeof(CO))-1;
  for(i=1;i<=n_coeff;i++){
    bias->coeff_list[i].order = (ORD*)cmalloc(n_cv*sizeof(ORD))-1;
  }
  for(i=1;i<=n_coeff;i++){
    fscanf(file_fes,"%lg",&(bias->coeff_list[i].c));
    for(j=1;j<=n_cv;j++){
      fscanf(file_fes,"%i",&(bias->coeff_list[i].order[j].n));
      fscanf(file_fes,"%i",&(bias->coeff_list[i].order[j].type));
    }
  }
  fclose(file_fes); */

  //exit(0);
/*-------------------------------------------------------------------------*/
/* Rescale parameters if necessary  */

   if(dinfo[ipt].grad_temp_on==1){
     num_bias = dinfo[ipt].num_bias-i_bias;
     temp_diff = dinfo[ipt].grad_temp_diff;
     if(Ree[ipt].on>=1){
       Ree[ipt].ms *= (Ree[ipt].kTs+num_bias*temp_diff)/(Ree[ipt].kTs);
       Ree[ipt].kTs += num_bias*temp_diff;
     }
     if(Rgyr[ipt].on>=1){
       Rgyr[ipt].ms *= (Rgyr[ipt].kTs+num_bias*temp_diff)/(Rgyr[ipt].kTs);
       Rgyr[ipt].kTs += num_bias*temp_diff;
     }
     if(NH[ipt].on>=1){
       NH[ipt].ms *= (NH[ipt].kTs+num_bias*temp_diff)/(NH[ipt].kTs);
       NH[ipt].kTs += num_bias*temp_diff;
     }
     if(Dih_cor[ipt].on>=1){
       Dih_cor[ipt].ms *= (Dih_cor[ipt].kTs+num_bias*temp_diff)/(Dih_cor[ipt].kTs);
       Dih_cor[ipt].kTs += num_bias*temp_diff;
     }
     if(Nalpha[ipt].on>=1){
       Nalpha[ipt].ms *= (Nalpha[ipt].kTs+num_bias*temp_diff)/(Nalpha[ipt].kTs);
       Nalpha[ipt].kTs += num_bias*temp_diff;
     }
     if(Nbeta[ipt].on>=1){
       Nbeta[ipt].ms *= (Nbeta[ipt].kTs+num_bias*temp_diff)/(Nbeta[ipt].kTs);
       Nbeta[ipt].kTs += num_bias*temp_diff;
     }
     for(i=1;i<=num_phi;i++){
        Phi[ipt][i].ms *= (Phi[ipt][i].kTs+num_bias*temp_diff)/(Phi[ipt][i].kTs);
        Phi[ipt][i].kTs += num_bias*temp_diff;
     }
  }//endif
/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

double L_int(double a,double b,double x,double w_bin,int l)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */

  double w_bin_n = w_bin*2.0/(b-a);
  double x_n     = (x - (a+b)*0.5)*2.0/(b-a);
  double integ   = 0.0;
  int k;
  //printf("x_n %lg\n",x_n);

  //printf("x %lg,an %lg,bn %lg\n",x,x_n-0.5*w_bin_n,x_n+0.5*w_bin_n);
  for(k=0;k<=(int)(l/2);k++){
     integ += pow(-1,k)*fact(2*l-2*k)/fact(k)/fact(l-k)/fact(l-2*k+1)*(pow(x_n+0.5*w_bin_n,l-2*k+1)-pow(x_n-0.5*w_bin_n,l-2*k+1));
  }
  return integ/pow(2.0,l);

/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

int find(int target,int *source, int len)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */
  int i,flag;
  
  flag = 0;
 
  for(i=1;i<=len;i++){
     if(target==source[i]){flag += 1;}
  }
  return flag;
/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

double fact(int n)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */
 
  int i;
  double prod = 1.0;

  for(i=1;i<=n;i++){
     prod *= (double)(i);
  }
  return prod;
/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/

/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

double power(double x,int n)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */

  int i;
  double prod = 1.0;

  for(i=1;i<=n;i++){
     prod *= x;
  }
  return prod;

/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void calc_bias_pot(BIAS_PACK *bias,double *min_old,double *max_old,
                     double **bias_pot_value,int n_cv,int n_total)
/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */
  int i,j,k;
  double *L_value,*T_value;
  double *x;
  CO  *coeff                 = bias->coeff_list;
  BIAS_POT *bias_pot_or      = bias->bias_pot_or;
  int *cv_type               = bias->cv_type;
  int *n_fun                 = bias->n_fun;
  int n_coeff                = bias->n_coeff;
  
  double prod,a,b;
  int order;  

/*---------------------------malloc------------------------------------- */

   

/*-----------------------calc bias potential---------------------------- */
   for(i=1;i<=n_total;i++){
     x = bias_pot_or[i].x;
     for(j=1;j<=n_cv;j++){
        if(cv_type[j]!=4){
          a = min_old[j];
          b = max_old[j];
          //s = 0.5*(b+a);
          //printf("cv %i,s %lg\n",j,s);
          L_value = (double *)cmalloc(n_fun[j]*sizeof(double))-1;
          L_fun_up(L_value,n_fun[j],a,b,x[j]);
          for(k=1;k<=n_coeff;k++){
            order = coeff[k].order[j].n;
            //bias_pot_value[k][j] = L_value[order+1]*sw_fun(s,a,b);//pay attention to a<=s<=b
            //bias_pot_dev[k][j]   = L_dev[order+1]*sw_fun(s,a,b)+L_value[order+1]*sw_fun_dev(s,a,b);
            //printf("order %i, i_cv %i, value %lg, dev %lg\n",order,j,bias_pot_value[k][j],bias_pot_dev[k][j]);
            bias_pot_value[k][j] = L_value[order+1];
          }
          free(&(L_value[1]));
        }/*endif cv_type[i]!=4*/
        else{
          T_value = (double *)cmalloc(bias->n_fun[j]*sizeof(double))-1;
          T_fun_up(T_value,n_fun[j],x[j]);
          for(k=1;k<=n_coeff;k++){
             order = coeff[k].order[j].n;
             bias_pot_value[k][j] = T_value[order+1];
          }
          free(&(T_value[1]));
        }/*end else*/
     }/*endfor n_cv*/
     for(j=1;j<=n_coeff;j++){
        prod = 1.0;
        for(k=1;k<=n_cv;k++){
           prod *= bias_pot_value[j][k];
        }
        bias_pot_or[i].V_x += coeff[j].c*prod;
    }

  }//endfor n_total

/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/



/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/

void L_fun_up(double *L_value,int len,double a,double b,double s)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */

  double x,order;
  int i;
  double b_a_1 = 1.0/(b-a);

  /*-----------------------------------------------------------------------*/
  /* Rescale s */

  if(s>=a&&s<=b){x = 2.0*s*b_a_1-(b+a)*b_a_1;}
  if(s<a){x = -1.0;}
  if(s>b){x = 1.0;}

  /*-----------------------------------------------------------------------*/
  /* Calculate Legendre polynomial */

  if(len==1){
    L_value[1] = 1.0;
  }
  else{
    L_value[1] = 1.0;
    L_value[2] = x;
  }
  for(i=3;i<=len;i++){
    order = (double)(i-2);
    L_value[i] = ((2.0*order+1.0)*x*L_value[i-1]-order*L_value[i-2])/(order+1.0);
  }


/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/

/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/

void T_fun_up(double *T_value,int len,double s)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */

  int i,order;

  for(i=1;i<=len;i++){
     if(i%2==1){
       order = (int)((i-1)/2);
       if(i==1){
         T_value[i] = 1.0;
       }
       else{
         T_value[i] = cos(order*s);
       }
     }
     else{
       order = (int)(i/2);
       T_value[i] = sin(order*s);
     }
  }

/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/





