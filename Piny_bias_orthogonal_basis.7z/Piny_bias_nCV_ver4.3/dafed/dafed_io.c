#include "standard_include.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_cp.h"
#include "../typ_defs/typedefs_par.h"
#include "../typ_defs/typedefs_stat.h"
#include "../proto_defs/proto_friend_lib_entry.h"
#include "../proto_defs/proto_math.h"
#include "../proto_defs/proto_dafed_helper.h"
#include "../proto_defs/proto_dafed_io.h"

void dafed_kt_io_ree (DAFED_STAT *ds, double atime, int iptoff) {
   double fac = 1.0*BOLTZ;
   printf("index: %d s(Ree)  Temp.     = %.10g %.10g\n",iptoff,fac*ds->dkt,fac*ds->av_dkt/atime);
}
void dafed_kt_io_rgyr (DAFED_STAT *ds, double atime, int iptoff) {
   double fac = 1.0*BOLTZ;
   printf("index: %d s(Rgyr) Temp.     = %.10g %.10g\n",iptoff,fac*ds->dkt,fac*ds->av_dkt/atime);
}
void dafed_kt_io_nh (DAFED_STAT *ds, double atime, int iptoff) {
   double fac = 1.0*BOLTZ;
   printf("index: %d s(NH)   Temp.     = %.10g %.10g\n",iptoff,fac*ds->dkt,fac*ds->av_dkt/atime);
}
void dafed_kt_io_phi(DAFED_STAT *ds, double atime, int iptoff, int i) {
   double fac = 1.0*BOLTZ;
   printf("index: %d s(Phi%d)   Temp.     = %.10g %.10g\n",iptoff,i,fac*ds->dkt,fac*ds->av_dkt/atime);
}
void dafed_kt_io_dih_cor (DAFED_STAT *ds, double atime, int iptoff) {
   double fac = 1.0*BOLTZ;
   printf("index: %d s(Dih_cor)   Temp.     = %.10g %.10g\n",iptoff,fac*ds->dkt,fac*ds->av_dkt/atime);
}
void dafed_kt_io_nalpha (DAFED_STAT *ds, double atime, int iptoff) {
   double fac = 1.0*BOLTZ;
   printf("index: %d s(Nalpha)   Temp.     = %.10g %.10g\n",iptoff,fac*ds->dkt,fac*ds->av_dkt/atime);
}
void dafed_kt_io_nbeta (DAFED_STAT *ds, double atime, int iptoff) {
   double fac = 1.0*BOLTZ;
   printf("index: %d s(Nbeta)   Temp.     = %.10g %.10g\n",iptoff,fac*ds->dkt,fac*ds->av_dkt/atime);
}

void dafed_screen_io (CLASS *class, GENERAL_DATA *general_data, int ipt) {

   CLATOMS_INFO *clatoms_info = &(class->clatoms_info);
   DAFED *Ree                 = clatoms_info->Ree;
   DAFED *Rgyr                = clatoms_info->Rgyr;
   DAFED *NH                  = clatoms_info->NH;
   DAFED *Dih_cor             = clatoms_info->Dih_cor;
   DAFED *Nalpha              = clatoms_info->Nalpha;
   DAFED *Nbeta               = clatoms_info->Nbeta;
   DAFED **Phi                = clatoms_info->Phi;
   DAFED_INFO *dinfo          = clatoms_info->daf_info;
   STAT_AVG *stat_avg         = general_data->stat_avg;
 
   double atime               = (double) general_data->timeinfo.itime;
   double te                  = 0.0; 
   double ke                  = 0.0; 
   double pe                  = 0.0;
   double avte                = 0.0; 
   double avke                = 0.0; 
   double avpe                = 0.0; 
   double s                   = 0.0;
   double NHCpe               = 0.0;
   double avNHCpe             = 0.0;
   double mass;
   int npara_temps_proc_off   = general_data->tempering_ctrl.npara_temps_proc_off;
   int iptoff                 = ipt + npara_temps_proc_off;
   int num_phi                = clatoms_info->num_phi;
   int bias_on                = clatoms_info->daf_info[ipt].bias_on;
   int steps_bias             = clatoms_info->daf_info[ipt].steps_bias;
   int num_bias               = clatoms_info->daf_info[ipt].num_bias;
   int i;
   int itime                  = general_data->timeinfo.itime;

   //printf("ree avpe avke %f %f\n",stat_avg->ds_ree.av_dpe,stat_avg->ds_ree.av_dke); 
   //printf("rgyr avpe avke %f %f\n",stat_avg->ds_rgyr.av_dpe,stat_avg->ds_rgyr.av_dke); 
   //printf("nh avpe avke %f %f\n",stat_avg->ds_nh.av_dpe,stat_avg->ds_nh.av_dke); 
   if (Ree[ipt].on == 1) {
      te   += stat_avg[ipt].ds_ree.dte; 
      avte += stat_avg[ipt].ds_ree.av_dte; 

      ke   += stat_avg[ipt].ds_ree.dke; 
      avke += stat_avg[ipt].ds_ree.av_dke; 
      pe   += stat_avg[ipt].ds_ree.dpe; 
      avpe += stat_avg[ipt].ds_ree.av_dpe;
      NHCpe += stat_avg[ipt].ds_ree.dNHCpe;
      avNHCpe += stat_avg[ipt].ds_ree.av_dNHCpe; 
   }
   if (Rgyr[ipt].on == 1) {
      te   += stat_avg[ipt].ds_rgyr.dte; 
      avte += stat_avg[ipt].ds_rgyr.av_dte; 
      ke   += stat_avg[ipt].ds_rgyr.dke; 
      avke += stat_avg[ipt].ds_rgyr.av_dke; 
      pe   += stat_avg[ipt].ds_rgyr.dpe; 
      avpe += stat_avg[ipt].ds_rgyr.av_dpe;
      NHCpe += stat_avg[ipt].ds_rgyr.dNHCpe;
      avNHCpe += stat_avg[ipt].ds_rgyr.av_dNHCpe;

   }
   if (NH[ipt].on == 1) {
      te   += stat_avg[ipt].ds_nh.dte; 
      avte += stat_avg[ipt].ds_nh.av_dte; 
      ke   += stat_avg[ipt].ds_nh.dke; 
      avke += stat_avg[ipt].ds_nh.av_dke; 
      pe   += stat_avg[ipt].ds_nh.dpe; 
      avpe += stat_avg[ipt].ds_nh.av_dpe;
      NHCpe += stat_avg[ipt].ds_nh.dNHCpe;
      avNHCpe += stat_avg[ipt].ds_nh.av_dNHCpe;

   }
   if (Dih_cor[ipt].on == 1) {
      te   += stat_avg[ipt].ds_dih_cor.dte;
      avte += stat_avg[ipt].ds_dih_cor.av_dte;
      ke   += stat_avg[ipt].ds_dih_cor.dke;
      avke += stat_avg[ipt].ds_dih_cor.av_dke;
      pe   += stat_avg[ipt].ds_dih_cor.dpe;
      avpe += stat_avg[ipt].ds_dih_cor.av_dpe;
      NHCpe += stat_avg[ipt].ds_dih_cor.dNHCpe;
      avNHCpe += stat_avg[ipt].ds_dih_cor.av_dNHCpe;

   }
   if (Nalpha[ipt].on == 1) {
      te   += stat_avg[ipt].ds_nalpha.dte;
      avte += stat_avg[ipt].ds_nalpha.av_dte;
      ke   += stat_avg[ipt].ds_nalpha.dke;
      avke += stat_avg[ipt].ds_nalpha.av_dke;
      pe   += stat_avg[ipt].ds_nalpha.dpe;
      avpe += stat_avg[ipt].ds_nalpha.av_dpe;
      NHCpe += stat_avg[ipt].ds_nalpha.dNHCpe;
      avNHCpe += stat_avg[ipt].ds_nalpha.av_dNHCpe;

   }
   if (Nbeta[ipt].on == 1) {
      te   += stat_avg[ipt].ds_nbeta.dte;
      avte += stat_avg[ipt].ds_nbeta.av_dte;
      ke   += stat_avg[ipt].ds_nbeta.dke;
      avke += stat_avg[ipt].ds_nbeta.av_dke;
      pe   += stat_avg[ipt].ds_nbeta.dpe;
      avpe += stat_avg[ipt].ds_nbeta.av_dpe;
      NHCpe += stat_avg[ipt].ds_nbeta.dNHCpe;
      avNHCpe += stat_avg[ipt].ds_nbeta.av_dNHCpe;

   }
   for(i=1;i<=num_phi;i++){
      te   += stat_avg[ipt].ds_phi[i].dte;
      avte += stat_avg[ipt].ds_phi[i].av_dte;
      ke   += stat_avg[ipt].ds_phi[i].dke;
      avke += stat_avg[ipt].ds_phi[i].av_dke;
      pe   += stat_avg[ipt].ds_phi[i].dpe;
      avpe += stat_avg[ipt].ds_phi[i].av_dpe;
      NHCpe += stat_avg[ipt].ds_phi[i].dNHCpe;
      avNHCpe += stat_avg[ipt].ds_phi[i].av_dNHCpe;

   }
   printf("************************\n");
   printf("d-AFED %i ke         = %.7g %.7g\n",iptoff,ke,avke/atime);
   printf("d-AFED %i pe         = %.7g %.7g\n",iptoff,pe,avpe/atime);
   printf("d-AFED %i te         = %.7g %.7g\n",iptoff,te,avte/atime);
   printf("d-AFED %i GGMT pe    = %.7g %.7g\n",iptoff,NHCpe,avNHCpe/atime);
   printf("d-AFED time          = %.7g\n",dinfo[ipt].difftime);
//   printf("d-AFED %i s          = %.7g     \n",iptoff,s);
   if(bias_on==1){
     printf("d-AFED %i bias pe     = %.7g\n",iptoff,stat_avg[ipt].bias_pot);
   }
   printf("************************\n");
   if (Ree[ipt].on  == 1) dafed_kt_io_ree(&(stat_avg[ipt].ds_ree),atime,iptoff);
   if (Rgyr[ipt].on == 1) dafed_kt_io_rgyr(&(stat_avg[ipt].ds_rgyr),atime,iptoff);
   if (NH[ipt].on   == 1) dafed_kt_io_nh(&(stat_avg[ipt].ds_nh),atime,iptoff);
   if (Dih_cor[ipt].on   == 1) dafed_kt_io_dih_cor(&(stat_avg[ipt].ds_dih_cor),atime,iptoff);
   if (Nalpha[ipt].on   == 1) dafed_kt_io_nalpha(&(stat_avg[ipt].ds_nalpha),atime,iptoff);
   if (Nbeta[ipt].on   == 1) dafed_kt_io_nbeta(&(stat_avg[ipt].ds_nbeta),atime,iptoff);
   for(i=1;i<=num_phi;i++){
      dafed_kt_io_phi(&(stat_avg[ipt].ds_phi[i]),atime,iptoff,i);
   }
   printf("************************\n");

}
void dafed_trajectory_io(CLATOMS_INFO *clatoms_info, TIMEINFO *ti, int ipt,
                         int npara_temps_proc_off)
 {

   DAFED *Ree		= clatoms_info->Ree;
   DAFED *Rgyr		= clatoms_info->Rgyr;
   DAFED *NH 		= clatoms_info->NH;
   DAFED **Phi          = clatoms_info->Phi;
   DAFED *Dih_cor       = clatoms_info->Dih_cor;
   DAFED *Nalpha        = clatoms_info->Nalpha;
   DAFED *Nbeta         = clatoms_info->Nbeta;
   DAFED_INFO *dinfo    = clatoms_info->daf_info;
   int num_phi          = clatoms_info->num_phi;
   int bias_on          = dinfo[ipt].bias_on;
   int steps_bias       = dinfo[ipt].steps_bias;
   int num_bias         = dinfo[ipt].num_bias;
   int itime            = ti->itime;
   FILE  *t1, *t2;
   NAME name_1,name_2;

   int tot = dinfo[ipt].to_file_freq*dinfo[ipt].freq;
   int iii, i;
   int iflag;
   int iptoff = ipt + npara_temps_proc_off;
   double time;
 
   iflag = 1;
   if(dinfo[ipt].bias_on==0){
     iflag = 0;
   }
   if(dinfo[ipt].bias_on==1&&itime>steps_bias*num_bias){
     iflag = 0;
   }
   if(dinfo[ipt].to_file_curr == dinfo[ipt].to_file_freq) { 
     dinfo[ipt].to_file_curr = 1;
     if(iflag==0){
       sprintf(name_1,"%s.%d",dinfo[ipt].traj_fn,iptoff);
       sprintf(name_2,"%s.%d",dinfo[ipt].traj_sr_fn,iptoff);
       t1 = cfopen(name_1,"a");
       t2 = cfopen(name_2,"a");
     
       for (iii = 1; iii <= dinfo[ipt].to_file_freq; iii++) {
         time = ti->itime-tot+iii*dinfo[ipt].freq; 
         fprintf(t1, "%lf ",time); 
         fprintf(t2, "%lf ",time); 
         if (Ree[ipt].on == 1) {
           fprintf(t1, "%.10g ",Ree[ipt].data_s[iii]*BOHR); 
           fprintf(t2, "%.10g ",Ree[ipt].data[iii]*BOHR); 
         }
         if (Rgyr[ipt].on == 1) {
           fprintf(t1, "%.10g ",Rgyr[ipt].data_s[iii]*BOHR); 
           fprintf(t2, "%.10g ",Rgyr[ipt].data[iii]*BOHR); 
         }
         if (NH[ipt].on == 1) {
           fprintf(t1, "%.10g ",NH[ipt].data_s[iii]); 
           fprintf(t2, "%.10g ",NH[ipt].data[iii]); 
         }
	 if (Dih_cor[ipt].on == 1) {
            fprintf(t1, "%.10g ",Dih_cor[ipt].data_s[iii]);
            fprintf(t2, "%.10g ",Dih_cor[ipt].data[iii]);
         }
	 if (Nalpha[ipt].on == 1) {
            fprintf(t1, "%.10g ",Nalpha[ipt].data_s[iii]);
            fprintf(t2, "%.10g ",Nalpha[ipt].data[iii]);
         }
	 if (Nbeta[ipt].on == 1) {
            fprintf(t1, "%.10g ",Nbeta[ipt].data_s[iii]);
            fprintf(t2, "%.10g ",Nbeta[ipt].data[iii]);
         }
         if (Ree[ipt].on >= 2) {
           fprintf(t2, "%.10g ",Ree[ipt].data[iii]*BOHR); 
         }
         if (Rgyr[ipt].on >= 2) {
           fprintf(t2, "%.10g ",Rgyr[ipt].data[iii]*BOHR); 
         }
         if (NH[ipt].on >= 2) {
           fprintf(t2, "%.10g ",NH[ipt].data[iii]); 
         }
	 if (Dih_cor[ipt].on >= 2) {
            fprintf(t2, "%.10g ",Dih_cor[ipt].data[iii]);
         }
	 if (Nalpha[ipt].on>=2){
	    fprintf(t2, "%.10g ",Nalpha[ipt].data[iii]);
	 }
	 if (Nbeta[ipt].on>=2){
            fprintf(t2, "%.10g ",Nbeta[ipt].data[iii]);
         }
         for(i=1;i<=num_phi;i++){
           if(Phi[ipt][1].on == 1){
             fprintf(t1, "%.10g ",Phi[ipt][i].data_s[iii]*57.295779513);
             fprintf(t2, "%.10g ",Phi[ipt][i].data[iii]*57.295779513);
           }
           if(Phi[ipt][1].on == 2){
             fprintf(t2, "%.10g ",Phi[ipt][i].data[iii]*57.295779513);
           }
         }/*endfor*/

         fprintf(t1,"\n"); fprintf(t2,"\n");
       }/*endfor iii*/
     fclose(t1);  
     fclose(t2);
     }/*endif iflag*/
   }
} 
