#include "standard_include.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_cp.h"
#include "../typ_defs/typedefs_par.h"
#include "../typ_defs/typedefs_stat.h"
#include "../proto_defs/proto_friend_lib_entry.h"
#include "../proto_defs/proto_math.h"
#include "../proto_defs/proto_dafed_helper.h"
#include "../proto_defs/proto_dafed_integrate.h"
#include "../proto_defs/proto_dafed_io.h"
#include "../proto_defs/proto_dafed_energy.h"

void check_boundaries(DAFED *daf) {

   if(daf->bdy==1){
     if (daf->s < 0) {
         daf->s *= -1.0; 
         daf->vs *= -1.0;
     }
   }
   if(daf->bdy==2){
     if(daf->s<=-3.141592653589793){
       daf->s += 6.283185307;
     }
     if(daf->s>3.141592653589793){
       daf->s -= 6.283185307;
     }
   }
}
     


void int_dafed_ggmt(DAFED *daf) {
   GGMT *th = &(daf->therm);

   // printf("DAFED GGMT NOW!\n");

   int iii, jjj;
   double aa, bb;
   double kt;  get_kt(daf, &kt);
   
   for (iii = 1; iii <= th->nr; iii++) {
     for (jjj = 1; jjj <= th->ny; jjj++) {
       th->G[1]   = (kt - daf->kTs)/(th->Q[1]);
       th->G[2]   = (pow(kt,2)/(3.0) - pow(daf->kTs,2))/(th->Q[2]);       
       th->vt[1] += 0.25*th->w[jjj]*th->G[1];  
       th->vt[2] += 0.25*th->w[jjj]*th->G[2];  

       aa         = exp(-0.125*th->w[jjj]* (th->vt[1] + daf->kTs*th->vt[2])); 
       daf->vs   *= aa;
       get_kt(daf, &kt);

       bb         = kt*th->vt[2]/(3.0);
       daf->vs   *= sqrt(1.0/(1.0 + 0.5*th->w[jjj]*bb));

       aa         = exp(-0.125*th->w[jjj]* (th->vt[1] + daf->kTs*th->vt[2])); 
       daf->vs   *= aa;
       get_kt(daf, &kt);

       th->qt[1] += 0.5*th->w[jjj]*th->vt[1];
       th->qt[2] += 0.5*th->w[jjj]*th->vt[2]*(daf->kTs + kt);

       aa         = exp(-0.125*th->w[jjj]* (th->vt[1] + daf->kTs*th->vt[2])); 
       daf->vs   *= aa;
       get_kt(daf, &kt);
 
       bb         = kt*th->vt[2]/(3.0);
       daf->vs   *= sqrt(1.0/(1.0 + 0.5*th->w[jjj]*bb));

       aa         = exp(-0.125*th->w[jjj]* (th->vt[1] + daf->kTs*th->vt[2])); 
       daf->vs   *= aa;
       get_kt(daf, &kt);

       th->G[1]   = (kt - daf->kTs)/(th->Q[1]);
       th->G[2]   = (pow(kt,2)/(3.0) - pow(daf->kTs,2))/(th->Q[2]);       
       th->vt[1] += 0.25*th->w[jjj]*th->G[1];  
       th->vt[2] += 0.25*th->w[jjj]*th->G[2]; 
     }
   } 
}

void evolve_position(DAFED *daf) {
   daf->s += daf->dt*daf->vs;  
   check_boundaries(daf);
}
void evolve_velocity(DAFED *daf) {
 //  printf(" d-AFED vel update\n");
  daf->vs += 0.5*daf->dt*daf->Fs/(daf->ms);  
}

void int_dafed_0_to_dt2 (CLASS *class, GENERAL_DATA *general_data,int ipt) {

   CLATOMS_INFO *clatoms_info = &(class->clatoms_info);
   DAFED *Ree  = clatoms_info->Ree;
   DAFED *Rgyr = clatoms_info->Rgyr;
   DAFED *NH   = clatoms_info->NH;
   DAFED **Phi = clatoms_info->Phi;
   DAFED *Dih_cor = clatoms_info->Dih_cor;
   DAFED *Nalpha  = clatoms_info->Nalpha;
   DAFED *Nbeta   = clatoms_info->Nbeta;
 
   DAFED_INFO *dinfo = class->clatoms_info.daf_info;
   int num_phi = clatoms_info->num_phi;
   int i,iflag;

   if (Ree[ipt].on == 1) {
      int_dafed_ggmt(&(Ree[ipt])); 
      evolve_velocity(&(Ree[ipt]));
      evolve_position(&(Ree[ipt]));
   }
   if (Rgyr[ipt].on == 1) {
      int_dafed_ggmt(&(Rgyr[ipt])); 
      evolve_velocity(&(Rgyr[ipt]));
      evolve_position(&(Rgyr[ipt]));
   }
   if (NH[ipt].on == 1) {
      int_dafed_ggmt(&(NH[ipt])); 
      evolve_velocity(&(NH[ipt]));
      evolve_position(&(NH[ipt]));
   }
   if(Dih_cor[ipt].on==1){
     int_dafed_ggmt(&(Dih_cor[ipt]));
     evolve_velocity(&(Dih_cor[ipt]));
     evolve_position(&(Dih_cor[ipt]));
   }
   if(Nalpha[ipt].on==1){
     int_dafed_ggmt(&(Nalpha[ipt]));
     evolve_velocity(&(Nalpha[ipt]));
     evolve_position(&(Nalpha[ipt]));
   }
   if(Nbeta[ipt].on==1){
     int_dafed_ggmt(&(Nbeta[ipt]));
     evolve_velocity(&(Nbeta[ipt]));
     evolve_position(&(Nbeta[ipt]));
   }
   for(i=1;i<=num_phi;i++){
      int_dafed_ggmt(&(Phi[ipt][i]));
      evolve_velocity(&(Phi[ipt][i]));
      evolve_position(&(Phi[ipt][i]));
   }

}
void int_dafed_dt2_to_dt (CLASS *class, GENERAL_DATA *general_data,int ipt) {

   CLATOMS_INFO *clatoms_info = &(class->clatoms_info);
   DAFED *Ree  = class->clatoms_info.Ree;
   DAFED *Rgyr = class->clatoms_info.Rgyr;
   DAFED *NH   = class->clatoms_info.NH;
   DAFED *Dih_cor = clatoms_info->Dih_cor;
   DAFED *Nalpha  = clatoms_info->Nalpha;
   DAFED *Nbeta   = clatoms_info->Nbeta;

   DAFED **Phi = clatoms_info->Phi;
   DAFED_INFO *dinfo = class->clatoms_info.daf_info;
   int num_phi = clatoms_info->num_phi;
   int i;

   if (Ree[ipt].on == 1) {
      evolve_velocity(&(Ree[ipt]));
      int_dafed_ggmt(&(Ree[ipt])); 
   }
   if (Rgyr[ipt].on == 1) {
      evolve_velocity(&(Rgyr[ipt]));
      int_dafed_ggmt(&(Rgyr[ipt])); 
   }
   if (NH[ipt].on == 1) {
      evolve_velocity(&(NH[ipt]));
      int_dafed_ggmt(&(NH[ipt])); 
   }
   if(Dih_cor[ipt].on==1){
     evolve_velocity(&(Dih_cor[ipt]));
     int_dafed_ggmt(&(Dih_cor[ipt]));
   }
   if(Nalpha[ipt].on==1){
     evolve_velocity(&(Nalpha[ipt]));
     int_dafed_ggmt(&(Nalpha[ipt]));
   }
   if(Nbeta[ipt].on==1){
     evolve_velocity(&(Nbeta[ipt]));
     int_dafed_ggmt(&(Nbeta[ipt]));
   }
   for(i=1;i<=num_phi;i++){
      evolve_velocity(&(Phi[ipt][i]));
      int_dafed_ggmt(&(Phi[ipt][i]));
   }

}
void int_dafed_0_to_dt2_res (CLASS *class, GENERAL_DATA *general_data,
                         double dti, int on, int ipt) {
   
   CLATOMS_INFO *clatoms_info = &(class->clatoms_info);
   STAT_AVG *stat_avg = &(general_data->stat_avg[ipt]);
   DAFED *Ree  = clatoms_info->Ree;
   DAFED *Rgyr = clatoms_info->Rgyr;
   DAFED *NH   = clatoms_info->NH;
   DAFED *Dih_cor = clatoms_info->Dih_cor;
   DAFED *Nalpha  = clatoms_info->Nalpha;
   DAFED *Nbeta   = clatoms_info->Nbeta;
   DAFED **Phi = clatoms_info->Phi;
   DAFED_INFO *dinfo = class->clatoms_info.daf_info;
   BIAS_PACK *bias  = clatoms_info->bias;
   DATA_BIAS *data   = stat_avg->data;

   int num_phi = clatoms_info->num_phi;
   int bias_on = dinfo[ipt].bias_on;
   int num_bias = dinfo[ipt].num_bias;
   int steps_bias   = dinfo[ipt].steps_bias;
   int i;

   Ree[ipt].dt = dti;
   Rgyr[ipt].dt = dti;
   NH[ipt].dt = dti;
   Dih_cor[ipt].dt = dti;
   Nalpha[ipt].dt  = dti;
   Nbeta[ipt].dt   = dti;

   if (Ree[ipt].on == 1) {
      if(on == 1) int_dafed_ggmt(&(Ree[ipt]));
      evolve_velocity(&(Ree[ipt]));
      evolve_position(&(Ree[ipt]));
   }
   if (Rgyr[ipt].on == 1) {
      if(on == 1) {int_dafed_ggmt(&(Rgyr[ipt])); }
      evolve_velocity(&(Rgyr[ipt]));
      evolve_position(&(Rgyr[ipt]));
   }
   if (NH[ipt].on == 1) {
      if(on == 1) int_dafed_ggmt(&(NH[ipt])); 
      evolve_velocity(&(NH[ipt]));
      evolve_position(&(NH[ipt]));
   }
   if (Dih_cor[ipt].on == 1) {
      if(on == 1) int_dafed_ggmt(&(Dih_cor[ipt]));
      evolve_velocity(&(Dih_cor[ipt]));
      evolve_position(&(Dih_cor[ipt]));
   }
   if (Nalpha[ipt].on == 1) {
      if(on == 1) int_dafed_ggmt(&(Nalpha[ipt]));
      evolve_velocity(&(Nalpha[ipt]));
      evolve_position(&(Nalpha[ipt]));
   }
   if (Nbeta[ipt].on == 1) {
      if(on == 1) int_dafed_ggmt(&(Nbeta[ipt]));
      evolve_velocity(&(Nbeta[ipt]));
      evolve_position(&(Nbeta[ipt]));
   }
   for(i=1;i<=num_phi;i++){
      Phi[ipt][i].dt = dti;
      if(on == 1) int_dafed_ggmt(&(Phi[ipt][i]));
      evolve_velocity(&(Phi[ipt][i]));
      evolve_position(&(Phi[ipt][i]));
   }

}
void int_dafed_dt2_to_dt_res (CLASS *class, GENERAL_DATA *general_data,
                          double dti, int on, int ipt) {

   CLATOMS_INFO *clatoms_info = &(class->clatoms_info);
   DAFED *Ree  = clatoms_info->Ree;
   DAFED *Rgyr = clatoms_info->Rgyr;
   DAFED *NH   = clatoms_info->NH;
   DAFED *Dih_cor = clatoms_info->Dih_cor;
   DAFED *Nalpha  = clatoms_info->Nalpha;
   DAFED *Nbeta   = clatoms_info->Nbeta;
   DAFED **Phi = clatoms_info->Phi;
   DAFED_INFO *dinfo = class->clatoms_info.daf_info;
   int num_phi = clatoms_info->num_phi;
   int i;

   Ree[ipt].dt = dti;
   Rgyr[ipt].dt = dti;
    NH[ipt].dt = dti;
    Dih_cor[ipt].dt = dti;
    Nalpha[ipt].dt  = dti;
    Nbeta[ipt].dt   = dti;
   if (Ree[ipt].on == 1) {
      evolve_velocity(&(Ree[ipt]));
      if(on == 1) int_dafed_ggmt(&(Ree[ipt])); 
   }
   if (Rgyr[ipt].on == 1) {
      evolve_velocity(&(Rgyr[ipt]));
      if(on == 1) {int_dafed_ggmt(&(Rgyr[ipt]));} 
   }
   if (NH[ipt].on == 1) {
      evolve_velocity(&(NH[ipt]));
      if(on == 1) int_dafed_ggmt(&(NH[ipt])); 
   }
   if (Dih_cor[ipt].on == 1) {
      evolve_velocity(&(Dih_cor[ipt]));
      if(on == 1) int_dafed_ggmt(&(Dih_cor[ipt]));
   }
   if (Nalpha[ipt].on == 1) {
      evolve_velocity(&(Nalpha[ipt]));
      if(on == 1) int_dafed_ggmt(&(Nalpha[ipt]));
   }
   if (Nbeta[ipt].on == 1) {
      evolve_velocity(&(Nbeta[ipt]));
      if(on == 1) int_dafed_ggmt(&(Nbeta[ipt]));
   }
   for(i=1;i<=num_phi;i++){
      Phi[ipt][i].dt = dti;
      evolve_velocity(&(Phi[ipt][i]));
      if(on == 1) int_dafed_ggmt(&(Phi[ipt][i]));
   }

}
void int_dafed_final (CLASS *class, GENERAL_DATA *general_data, int ipt) {

   CLATOMS_INFO *clatoms_info = &(class->clatoms_info);
   STAT_AVG *stat_avg = &(general_data->stat_avg[ipt]);
   DAFED *Ree                 = clatoms_info->Ree;
   DAFED *Rgyr                = clatoms_info->Rgyr;
   DAFED *NH                  = clatoms_info->NH;
   DAFED *Dih_cor             = clatoms_info->Dih_cor;
   DAFED *Nalpha              = clatoms_info->Nalpha;
   DAFED *Nbeta               = clatoms_info->Nbeta;
   DAFED **Phi                = clatoms_info->Phi;

   DAFED_STAT *ds_Ree         = &(general_data->stat_avg[ipt].ds_ree);
   DAFED_STAT *ds_Rgyr        = &(general_data->stat_avg[ipt].ds_rgyr);
   DAFED_STAT *ds_NH          = &(general_data->stat_avg[ipt].ds_nh);
   DAFED_STAT *ds_phi         = general_data->stat_avg[ipt].ds_phi;
   DAFED_STAT *ds_dih_cor     = &(general_data->stat_avg[ipt].ds_dih_cor);
   DAFED_STAT *ds_nalpha      = &(general_data->stat_avg[ipt].ds_nalpha);
   DAFED_STAT *ds_nbeta       = &(general_data->stat_avg[ipt].ds_nbeta);
   DAFED_INFO *dinfo          = clatoms_info->daf_info;
   BIAS_PACK *bias  = clatoms_info->bias;
   DATA_BIAS *data   = stat_avg->data;

   int bias_on = dinfo[ipt].bias_on;
   int num_bias = dinfo[ipt].num_bias;
   int steps_bias   = dinfo[ipt].steps_bias/10;
   int npara_temps_proc_off   = general_data->tempering_ctrl.npara_temps_proc_off;
   int num_phi                = clatoms_info->num_phi;
   int i,iflag,ind;   
   int itime   = general_data->timeinfo.itime;
   int n_cv    = stat_avg->n_cv;
   int i_bias  = stat_avg->i_bias+1;
   int myid    = class->communicate.myid;

   // printf("int_dafed_final myid %d\n", class->communicate.myid);
   
   if (Ree[ipt].on == 1) {
     get_dafed_therm_energy(&(Ree[ipt].therm),&(ds_Ree->dte),&(ds_Ree->dNHCpe));
     get_kt(&(Ree[ipt]), &(ds_Ree->dkt));
     get_ke(&(Ree[ipt]), &(ds_Ree->dke));
     ds_Ree->av_dpe += ds_Ree->dpe;
     ds_Ree->av_dte += ds_Ree->dte; 
     ds_Ree->av_dkt += ds_Ree->dkt; 
     ds_Ree->av_dke += ds_Ree->dke;
     ds_Ree->av_dNHCpe += ds_Ree->dNHCpe; 
     ds_Ree->tot     = ds_Ree->dte + ds_Ree->dke + ds_Ree->dpe;
     if (dinfo[ipt].curr == 0)  Ree[ipt].data_s[dinfo[ipt].to_file_curr] = Ree[ipt].s;
   }
   if (Rgyr[ipt].on == 1) {
     get_dafed_therm_energy(&(Rgyr[ipt].therm),&(ds_Rgyr->dte),&(ds_Rgyr->dNHCpe));
     get_kt(&(Rgyr[ipt]), &(ds_Rgyr->dkt));
     get_ke(&(Rgyr[ipt]), &(ds_Rgyr->dke));
     ds_Rgyr->av_dpe += ds_Rgyr->dpe;
     ds_Rgyr->av_dte += ds_Rgyr->dte; 
     ds_Rgyr->av_dkt += ds_Rgyr->dkt; 
     ds_Rgyr->av_dke += ds_Rgyr->dke;
     ds_Rgyr->av_dNHCpe += ds_Rgyr->dNHCpe; 
     ds_Rgyr->tot     = ds_Rgyr->dte + ds_Rgyr->dke + ds_Rgyr->dpe;
     if (dinfo[ipt].curr == 0) Rgyr[ipt].data_s[dinfo[ipt].to_file_curr] = Rgyr[ipt].s;
   }
   if (NH[ipt].on == 1) {
     get_dafed_therm_energy(&(NH[ipt].therm),&(ds_NH->dte),&(ds_NH->dNHCpe));
     get_kt(&(NH[ipt]), &(ds_NH->dkt));
     get_ke(&(NH[ipt]), &(ds_NH->dke));
     ds_NH->av_dpe += ds_NH->dpe;
     ds_NH->av_dte += ds_NH->dte; 
     ds_NH->av_dkt += ds_NH->dkt; 
     ds_NH->av_dke += ds_NH->dke; 
     ds_NH->av_dNHCpe += ds_NH->dNHCpe;
     ds_NH->tot     = ds_NH->dte + ds_NH->dke + ds_NH->dpe;
     if (dinfo[ipt].curr == 0) NH[ipt].data_s[dinfo[ipt].to_file_curr] = NH[ipt].s;
   }
   if (Dih_cor[ipt].on == 1) {
      get_dafed_therm_energy(&(Dih_cor[ipt].therm),&(ds_dih_cor->dte),&(ds_dih_cor->dNHCpe));
      get_kt(&(Dih_cor[ipt]), &(ds_dih_cor->dkt));
      get_ke(&(Dih_cor[ipt]), &(ds_dih_cor->dke));
      ds_dih_cor->av_dpe += ds_dih_cor->dpe;
      ds_dih_cor->av_dte += ds_dih_cor->dte;
      ds_dih_cor->av_dkt += ds_dih_cor->dkt;
      ds_dih_cor->av_dke += ds_dih_cor->dke;
      ds_dih_cor->av_dNHCpe += ds_dih_cor->dNHCpe;
      ds_dih_cor->tot     = ds_dih_cor->dte + ds_dih_cor->dke + ds_dih_cor->dpe;
     if (dinfo[ipt].curr == 0) Dih_cor[ipt].data_s[dinfo[ipt].to_file_curr] = Dih_cor[ipt].s;
   }
   if (Nalpha[ipt].on == 1) {
      get_dafed_therm_energy(&(Nalpha[ipt].therm),&(ds_nalpha->dte),&(ds_nalpha->dNHCpe));
      get_kt(&(Nalpha[ipt]), &(ds_nalpha->dkt));
      get_ke(&(Nalpha[ipt]), &(ds_nalpha->dke));
      ds_nalpha->av_dpe += ds_nalpha->dpe;
      ds_nalpha->av_dte += ds_nalpha->dte;
      ds_nalpha->av_dkt += ds_nalpha->dkt;
      ds_nalpha->av_dke += ds_nalpha->dke;
      ds_nalpha->av_dNHCpe += ds_nalpha->dNHCpe;
      ds_nalpha->tot     = ds_nalpha->dte + ds_nalpha->dke + ds_nalpha->dpe;
      if (dinfo[ipt].curr == 0) Nalpha[ipt].data_s[dinfo[ipt].to_file_curr] = Nalpha[ipt].s;
   }
   if (Nbeta[ipt].on == 1) {
      get_dafed_therm_energy(&(Nbeta[ipt].therm),&(ds_nbeta->dte),&(ds_nbeta->dNHCpe));
      get_kt(&(Nbeta[ipt]), &(ds_nbeta->dkt));
      get_ke(&(Nbeta[ipt]), &(ds_nbeta->dke));
      ds_nbeta->av_dpe += ds_nbeta->dpe;
      ds_nbeta->av_dte += ds_nbeta->dte;
      ds_nbeta->av_dkt += ds_nbeta->dkt;
      ds_nbeta->av_dke += ds_nbeta->dke;
      ds_nbeta->av_dNHCpe += ds_nbeta->dNHCpe;
      ds_nbeta->tot     = ds_nbeta->dte + ds_nbeta->dke + ds_nbeta->dpe;
      if (dinfo[ipt].curr == 0) Nbeta[ipt].data_s[dinfo[ipt].to_file_curr] = Nbeta[ipt].s;
   }
   for(i=1;i<=num_phi;i++){
      get_dafed_therm_energy(&(Phi[ipt][i].therm),&(ds_phi[i].dte),&(ds_phi[i].dNHCpe));
      get_kt(&(Phi[ipt][i]),&(ds_phi[i].dkt));
      get_ke(&(Phi[ipt][i]),&(ds_phi[i].dke));
      ds_phi[i].av_dpe += ds_phi[i].dpe;
      ds_phi[i].av_dte += ds_phi[i].dte;
      ds_phi[i].av_dkt += ds_phi[i].dkt;    
      ds_phi[i].av_dke += ds_phi[i].dke;
      ds_phi[i].av_dNHCpe += ds_phi[i].dNHCpe;
      ds_phi[i].tot     = ds_phi[i].dte + ds_phi[i].dke + ds_phi[i].dpe;
      if(dinfo[ipt].curr == 0) Phi[ipt][i].data_s[dinfo[ipt].to_file_curr] = Phi[ipt][i].s;
   }/*endfor*/

   if(bias_on==1&&i_bias<=num_bias&&myid==0&&itime%10==0){
     iflag = 0;
     ind = (int)(itime/10)%steps_bias;
     if(ind==0){ind = steps_bias;}
     for(i=1;i<=n_cv;i++){
        switch(bias[ipt].cv_type[i]){
         case 1:data[ind].x[i] = Ree[ipt].s;
                break;
         case 2:data[ind].x[i] = Rgyr[ipt].s;
                break;
         case 3:data[ind].x[i] = NH[ipt].s;
                break;
         case 5:data[ind].x[i] = Dih_cor[ipt].s;
                break;
         case 6:data[ind].x[i] = Nalpha[ipt].s;
                break;
         case 7:data[ind].x[i] = Nbeta[ipt].s;
                break;
         case 4:iflag += 1;
                data[ind].x[i] = Phi[ipt][iflag].s;
                break;
        }/*endswitch*/
     }/*endfor*/
   }/*endif*/

   dafed_trajectory_io(clatoms_info,&(general_data->timeinfo), ipt, npara_temps_proc_off);
}

/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void calc_dafed_freq(CLASS *class, GENERAL_DATA *general_data, int ipt)
/*========================================================================*/
{/*begin routine*/
/*========================================================================*/

  STAT_AVG *stat_avg         = &(general_data->stat_avg[ipt]);
  CLATOMS_INFO *clatoms_info = &(class->clatoms_info);  
  struct DAFED_FREQ *dafed_freq, *dafed_freq_root, *dafed_freq_last;

  double Ree_x               = clatoms_info->Ree[ipt].s;
  double Rgyr_x              = clatoms_info->Rgyr[ipt].s;
  double NH_x                = clatoms_info->NH[ipt].s;
  double *cv_x_min           = stat_avg->cv_x_min;
  double *cv_x_max           = stat_avg->cv_x_max;
  double *w_bin              = stat_avg->w_bin;
  double cv_x_value;

/*==========================================================================*/

  if(stat_avg->ree_on>=1){
    dafed_freq = stat_avg->Ree_freq;
    dafed_freq_root = stat_avg->Ree_freq;
    cv_x_value = Ree_x;
  }
  if(stat_avg->rgyr_on>=1){
    dafed_freq = stat_avg->Rgyr_freq;
    dafed_freq_root = stat_avg->Rgyr_freq;
    cv_x_value = Rgyr_x;
  }
  if(stat_avg->nh_on>=1){
    dafed_freq = stat_avg->NH_freq;
    dafed_freq_root = stat_avg->NH_freq;
    cv_x_value = NH_x;
  }
  if(stat_avg->n_cv==1){          //this means one varialbe in cv
   if(cv_x_value>=dafed_freq_root->x-0.5*w_bin[1]){ //left or right expand
    while(dafed_freq->right!=NULL&&cv_x_value>=dafed_freq->x+0.5*w_bin[1]){
	dafed_freq = dafed_freq->right;
    }
    if(cv_x_value<dafed_freq->x+0.5*w_bin[1]){
	dafed_freq->freq += 1;
    }
    else{
	while(cv_x_value>=dafed_freq->x+0.5*w_bin[1]){

	    dafed_freq->right = (struct DAFED_FREQ *)cmalloc(sizeof(struct DAFED_FREQ));
	    dafed_freq_last = dafed_freq;
	    dafed_freq = dafed_freq->right;
	    dafed_freq->left = dafed_freq_last;
	    dafed_freq->x = dafed_freq_last->x+w_bin[1];
	    dafed_freq->freq = 0;
            stat_avg->n_freq += 1;\
	}/*endwhile*/
	dafed_freq->freq += 1;
	cv_x_max[1] = dafed_freq->x;
    }/*endif cv_x_value<dafed_freq.x+0.5*w_bin[1]*/
   }/*endif right expand*/
   else{ //root pointer point to the node with smallest x.
       while(cv_x_value<dafed_freq->x-0.5*w_bin[1]){
           dafed_freq->left = (struct DAFED_FREQ *)cmalloc(sizeof(struct DAFED_FREQ));
	   dafed_freq_last = dafed_freq;
	   dafed_freq = dafed_freq->left;
	   dafed_freq->right = dafed_freq_last;
	   dafed_freq->x = dafed_freq_last->x-w_bin[1];
	   dafed_freq->freq = 0;
           stat_avg->n_freq += 1;
       }/*endwhile*/
       dafed_freq->freq += 1;
       cv_x_min[1] = dafed_freq->x;
       dafed_freq_root = dafed_freq;
   }/*endif left expand*/
  }/*endif n_cv==1*/
  stat_avg->n_sample += 1;
  if(stat_avg->Ree_freq!=NULL){stat_avg->Ree_freq = dafed_freq_root;}
  if(stat_avg->Rgyr_freq!=NULL){stat_avg->Rgyr_freq = dafed_freq_root;}
  if(stat_avg->NH_freq!=NULL){stat_avg->NH_freq = dafed_freq_root;}
  
/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void calc_dafed_value(CLASS *class, GENERAL_DATA *general_data, int ipt)
/*========================================================================*/
{/*begin routine*/
/*========================================================================*/

  STAT_AVG *stat_avg          = &(general_data->stat_avg[ipt]);
  CLATOMS_INFO *clatoms_info  = &(class->clatoms_info);
  DAFED_STAT *ds_ree          = &(stat_avg->ds_ree);
  DAFED_STAT *ds_rgyr         = &(stat_avg->ds_rgyr);
  DAFED_STAT *ds_nh           = &(stat_avg->ds_nh);
  CLATOMS_POS *clatoms_pos    = class->clatoms_pos;
  DAFED *Ree                  = class->clatoms_info.Ree;
  DAFED *Rgyr                 = class->clatoms_info.Rgyr;
  DAFED *NH                   = class->clatoms_info.NH;

/*==========================================================================*/
  ds_ree->x = 0.0;
  ds_rgyr->x = 0.0;
  ds_nh->x = 0.0;
  if(general_data->tempering_ctrl.ree_on==1){
    ds_ree->x = get_Ree_value(clatoms_info, clatoms_pos, ipt);
  }
  if(general_data->tempering_ctrl.rgyr_on==1){
    ds_rgyr->x = get_Rgyr_value(clatoms_info, clatoms_pos, ipt);
  }
  if(general_data->tempering_ctrl.nh_on==1){
    ds_nh->x = get_NH_value(clatoms_info,clatoms_pos, ipt);
  }
  if(Ree[ipt].on>0) ds_ree->x   = Ree[ipt].s;
  if(Rgyr[ipt].on>0) ds_rgyr->x = Rgyr[ipt].s;
  if(NH[ipt].on>0) ds_nh->x     = NH[ipt].s;
 


/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/






