void analysis_md(  CLASS *,GENERAL_DATA *, BONDED *, ANALYSIS *);
void analysis_pimd(CLASS *,GENERAL_DATA *, BONDED *, ANALYSIS *);

void prelim_analysis(CLASS *, GENERAL_DATA *, ANALYSIS *);
void calcul_vovt_atm(CLASS *, GENERAL_DATA *, ANALYSIS *);
void calcul_msqd_atm(CLASS *, GENERAL_DATA *, ANALYSIS *);
void calcul_iikt_iso_cmd(CLASS *, GENERAL_DATA *, ANALYSIS *);
void calcul_ickt_iso_md(CLASS *, GENERAL_DATA *, ANALYSIS *);
void calcul_simp_sc_op(CLASS *, GENERAL_DATA *, ANALYSIS *);
void calcul_gr(CLASS *,GENERAL_DATA *,ANALYSIS *);

