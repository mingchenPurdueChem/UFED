/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
/*                                                                          */
/*                         PI_MD:                                           */
/*             The future of simulation technology                          */
/*             ------------------------------------                         */
/*                     Module: parse                                        */
/*                                                                          */
/* This subprogram reads in all user inputs                                 */
/*                                                                          */
/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

#include "standard_include.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_cp.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../typ_defs/typedefs_par.h"
#include "../typ_defs/typedefs_stat.h"
#include "../proto_defs/proto_parse_entry.h"


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void mall_para_temp(CLASS *class,BONDED *bonded,GENERAL_DATA *general_data,
                    CP *cp)

/*==========================================================================*/
  {/* begin routine */
/*==========================================================================*/
/* Over Malloc size. The empty structures are not large.                    */
/* When this routine is called, the parallelization has not yet been set up */

         /* over malloc : DO NOT PANIC*/
    int nmall,nmall_dafed;
    int np          = class->communicate_m.np ;
    int npara_temps = general_data->simopts.npara_temps; 
    int ioff        = 1;
    CLATOMS_INFO *clatoms_info = &(class->clatoms_info);    
 
    if(np>1){
      ioff          = 0;
      npara_temps++;
    }/*endif*/

/*===========================================================================*/

  general_data->statepoint     = 
       (STATEPOINT *)     cmalloc(npara_temps*sizeof(STATEPOINT))-ioff;
  general_data->stat_avg       = 
       (STAT_AVG *)       cmalloc(npara_temps*sizeof(STAT_AVG))-ioff;
  general_data->stat_avg_tmp   = 
       (STAT_AVG *)       cmalloc(npara_temps*sizeof(STAT_AVG))-ioff;
  general_data->ptens       = 
       (PTENS *)          cmalloc(npara_temps*sizeof(PTENS))-ioff;
  general_data->tempering_screen_out = (TEMPERING_SCREEN_OUT *)
                cmalloc(npara_temps*sizeof(TEMPERING_SCREEN_OUT))-ioff;

  general_data->stat_avg[1].nsend_dbl = 24;

  nmall = (npara_temps*(general_data->stat_avg[1].nsend_dbl+1));
  general_data->stat_avg[1].data_us = (double *)cmalloc(nmall*sizeof(double))-1;
  general_data->stat_avg[1].data_ds = (double *)cmalloc(nmall*sizeof(double))-1;
  general_data->stat_avg[1].data_ur = (double *)cmalloc(nmall*sizeof(double))-1;
  general_data->stat_avg[1].data_dr = (double *)cmalloc(nmall*sizeof(double))-1;
  
/*  if(general_data->tempering_ctrl.para_type==2){
    clatoms_info.nsend_dafed_dbl = 6;
    nmall_dafed = (npara_temps*(clatoms_info.nsend_dafed_dbl+1));
    clatoms_info.send_dafed = (double *)cmalloc(nmall_dafed*sizeof(double))-1;
    clatoms_info.recv_dafed = (double *)cmalloc(nmall_dafed*sizeof(double))-1;
    clatoms_info.bcast_dafed = (double *)cmalloc(nmall_dafed*sizeof(double))-1;
  }
*/
  general_data->stat_avg[1].rand_vec = (double *)
                          cmalloc((npara_temps+2)*sizeof(double));

  class->clatoms_tran      = 
       (CLATOMS_TRAN *)   cmalloc(npara_temps*sizeof(CLATOMS_TRAN))-ioff;
  class->clatoms_sysinfo      = 
       (CLATOMS_SYSINFO *)cmalloc(npara_temps*sizeof(CLATOMS_SYSINFO))-ioff;
  class->therm_info_class      = 
       (THERM_INFO *)     cmalloc(npara_temps*sizeof(THERM_INFO))-ioff;
  class->therm_info_bead       = 
       (THERM_INFO *)     cmalloc(npara_temps*sizeof(THERM_INFO))-ioff;
  class->therm_class           =
       (THERM_POS *)      cmalloc(npara_temps*sizeof(THERM_POS))-ioff;
printf("MALLOC  para init %d %d\n",npara_temps,ioff);fflush(stdout);
  class->nbr_list.verlist      = 
       (VERLIST *)        cmalloc(npara_temps*sizeof(VERLIST))-ioff;
  class->nbr_list.lnklist      = 
       (LNKLIST *)        cmalloc(npara_temps*sizeof(LNKLIST))-ioff;
  class->interact.list_skin     = 
       (LIST_SKIN *)        cmalloc(npara_temps*sizeof(LIST_SKIN))-ioff;

  bonded->bond_free            =
       (BOND_FREE *)      cmalloc(npara_temps*sizeof(BOND_FREE))-ioff;
  bonded->bend_free            =
       (BEND_FREE *)      cmalloc(npara_temps*sizeof(BEND_FREE))-ioff;
  bonded->tors_free            = 
       (TORS_FREE *)      cmalloc(npara_temps*sizeof(TORS_FREE))-ioff;
  bonded->rbar_sig_free        = 
       (RBAR_SIG_FREE *)  cmalloc(npara_temps*sizeof(RBAR_SIG_FREE))-ioff;

/*==========================================================================*/
  }/* end routine */
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
void init_parallel_tempering(GENERAL_DATA *general_data, CLASS *class, CP *cp)
/*==========================================================================*/
  {/*begin routine*/
/*==========================================================================*/

    int ioff,koff,iii,i,j,ndiv,nrem;

    int npara_temps = general_data->simopts.npara_temps;
    int natm_tot    = class->clatoms_info.natm_tot;
    int nmol_typ    = class->atommaps.nmol_typ;
    int np          = class->communicate_m.np;
    int np_temper   = class->communicate_m.np_temper;
    int myid        = class->communicate_m.myid;
    int myid_temper;
    int npara_temps_proc;
    int npara_temps_proc_off;
    int npara_temps_proc_st;
    int npara_temps_proc_end;

    CPOPTS  *cpopts                  = &(cp->cpopts);
    SIMOPTS *simopts                 = &(general_data->simopts);
    TEMPERING_CTRL *tempering_ctrl   = &(general_data->tempering_ctrl);
    TEMPERING_SCREEN_OUT *tempering_screen_out = 
                                         general_data->tempering_screen_out;

    int *cv_ext_m                    = tempering_ctrl->cv_ext_m;
    double *t_ext_m                  = tempering_ctrl->t_ext_m;
    double *p_ext_m                  = tempering_ctrl->p_ext_m;
    double *s_ext_m                  = tempering_ctrl->s_ext_m;
    double *text_mol;
    double *text_atm;
    int myid_use;

   cp->communicate_m.np = np;

/*==========================================================================*/
/* Parallelization : Just create indices : make the communicator later      */

    myid_use    = (myid*np_temper)/np;
    myid_temper = (myid_use % np_temper);
    ndiv        = (npara_temps/np_temper);
    nrem        = (npara_temps % np_temper);
    if(myid_temper<nrem){
      npara_temps_proc     = ndiv+1;
      npara_temps_proc_st  = (ndiv+1)*myid_temper + 1;
      npara_temps_proc_end = (ndiv+1)*(myid_temper+1);
    }else{
      npara_temps_proc     = ndiv;
      npara_temps_proc_st  = (myid_temper)*ndiv   + nrem + 1;
      npara_temps_proc_end = (myid_temper+1)*ndiv + nrem;
    }/*endif*/
    npara_temps_proc_off = npara_temps_proc_st-1;

    tempering_ctrl->npara_temps_proc     = npara_temps_proc;
    tempering_ctrl->npara_temps_proc_off = npara_temps_proc_off;
    tempering_ctrl->npara_temps_proc_st  = npara_temps_proc_st;
    tempering_ctrl->npara_temps_proc_end = npara_temps_proc_end;

    simopts->npara_temps_proc            = npara_temps_proc;
    simopts->npara_temps_proc_off        = npara_temps_proc_off;
    simopts->npara_temps_proc_st         = npara_temps_proc_st;
    simopts->npara_temps_proc_end        = npara_temps_proc_end;

    cpopts->npara_temps_proc             = npara_temps_proc;
    cpopts->npara_temps_proc_off         = npara_temps_proc_off;
    cpopts->npara_temps_proc_st          = npara_temps_proc_st;
    cpopts->npara_temps_proc_end         = npara_temps_proc_end;

/*==========================================================================*/
/* set up the screen */

    ioff = npara_temps_proc_off;
    for(i=1;i<=npara_temps_proc;i++){
      tempering_screen_out[i].fname = (char *)cmalloc(MAXWORD*sizeof(char));
      sprintf(tempering_screen_out[i].fname,"%s-%d.o",
	      tempering_ctrl->screen_name,i+ioff );
    }/*end for*/

/*==========================================================================*/
/* set statepoint */

    koff=0; if(npara_temps != npara_temps_proc){koff=1;}
    for(i=1-koff;i<=npara_temps_proc+koff;i++){
      iii = i+ioff;
      if(iii==0){iii=npara_temps;}  
      if(iii==npara_temps+1){iii=1;}//thest two conditions have no means but just to avoid segmentation fault
      if( tempering_ctrl->para_type==1){//this for para temp
        class->clatoms_sysinfo[i].pi_temperature = t_ext_m[(iii)];
        general_data->statepoint[i].t_ext        = t_ext_m[(iii)];
        general_data->statepoint[i].pext         = p_ext_m[(iii)];
        general_data->statepoint[i].stens_ext    = s_ext_m[(iii)];
      }/*endif*/
      else if( tempering_ctrl->para_type==2){//this for para dafed
        general_data->statepoint[i].cv_ext       = cv_ext_m[(iii)];
      }/*endif*/
    }/*endfor*/

/*==========================================================================*/
/* set atom and molecule temperatures */

  if(tempering_ctrl->para_type==1){
   for(i=1;i<=npara_temps_proc;i++){
    class->clatoms_sysinfo[i].text_atm = 
                        (double *)cmalloc(natm_tot*sizeof(double))-1;
    text_atm = class->clatoms_sysinfo[i].text_atm;
    for(j=1;j<=class->clatoms_info.natm_tot;j++){
      text_atm[j] = general_data->statepoint[i].t_ext;
    }/*endfor*/ 
   }/*endfor*/
  }/*endif para_type*/
  
  if(tempering_ctrl->para_type==2){
   for(i=1;i<=npara_temps_proc;i++){
    class->clatoms_sysinfo[i].text_atm =
                        (double *)cmalloc(natm_tot*sizeof(double))-1;
    text_atm = class->clatoms_sysinfo[i].text_atm;
    for(j=1;j<=class->clatoms_info.natm_tot;j++){
      text_atm[j] = general_data->statepoint[1].t_ext;
    }/*endfor*/
   }/*endfor*/

   for(i=1;i<=npara_temps_proc;i++){
    class->clatoms_sysinfo[i].text_mol = 
                 (double*)cmalloc(nmol_typ*sizeof(double))-1;
    text_mol = class->clatoms_sysinfo[i].text_mol;
    for(j=1;j<=class->atommaps.nmol_typ;j++){
      text_mol[j] = general_data->statepoint[i].t_ext;
    }/*endfor*/
   }/*endfor*/
  }/*endif para_type*/
/*==========================================================================*/
  }/*end routine */
/*==========================================================================*/



/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
void prelim_paratemp(STAT_AVG *stat_avg, CLATOMS_POS *clatoms_pos, 
		     int iptoff,int npara_temps,int istart, int ipt_restart)
/*========================================================================*/
   { /*begin Routine */
/*-----------------------------------------------------------------------*/

     stat_avg->nacc       = 0.0;
     stat_avg->ntest      = 0.0;
     stat_avg->coastal    = 0.0;

     if(istart<2 || ipt_restart==0){
       stat_avg->ndirect[1] = 0;
       stat_avg->ndirect[2] = 0;
       stat_avg->ndirect[3] = 0;
       clatoms_pos->origin  = iptoff; /* sent with offset in parallel */
       clatoms_pos->idirect = 3;
       if(iptoff==1)          {clatoms_pos->idirect = 1;}
       if(iptoff==npara_temps){clatoms_pos->idirect = 2;}
     }/*endif*/

/*-----------------------------------------------------------------------*/
  }/*end routine*/
/*========================================================================*/
















