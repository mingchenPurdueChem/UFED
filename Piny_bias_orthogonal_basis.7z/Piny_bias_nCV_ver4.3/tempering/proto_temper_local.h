/*---------------------------------------------------------------------*/

void travel_histo(CLATOMS_POS *,STAT_AVG *,TEMPERING_CTRL *, 
                  int ,int , int ,int , MPI_Comm );

double get_switch_energy(STAT_AVG *,char *,int);

double get_adiab_prob(STAT_AVG *,STAT_AVG *);

double read_dafed_prob(STAT_AVG *, STAT_AVG *, int);

void accept_switch_atoms(CLATOMS_POS *, THERM_POS *, THERM_POS *,
			 THERM_INFO *, THERM_INFO *,
			 int ,int ,char *,int ,int,int,int);

void get_new_cv(CLATOMS_INFO *, STAT_AVG *, int, int );

void accept_switch_wave(CPCOEFFS_POS *,CPTHERM_POS *,
			int ,int ,char *,int ,int );

void switch_point_dble(double **,double **);

void switch_point_dbledble(double ***,double ***);

void switch_val_dble(double *,double *);

void switch_val_dbledble_scale(double **, double **, 
                               int, int , int ,int , double **, double **);
void switch_point_int(int **,int **);

void switch_point_intint(int ***,int ***);

void switch_val_int(int *,int *);

void get_pimd_harm_energy(STAT_AVG *stat_avg,double ,double ,
                          double *,double *);

double get_adiab_prob(STAT_AVG *, STAT_AVG *);

double read_dafed_prob(STAT_AVG *,STAT_AVG *, int);

/*---------------------------------------------------------------------*/
/* comm_switch.c                                                       */
void switch_communicate_stat_avg(COMMUNICATE *, COMMUNICATE *, STAT_AVG *,
				 CLATOMS_INFO *,int , int,int , int,int);

void Bcast_stat_avg_grp(STAT_AVG *,CLATOMS_INFO *,int, int,MPI_Comm ,int ,int);

void Send_stat_avg_updn(STAT_AVG *,CLATOMS_INFO *,int ,int,
                        MPI_Comm ,int ,int ,int,int,int);

void stat_avg_pack(double *, STAT_AVG *,int ,int );

void stat_avg_unpack(double *, STAT_AVG *,int ,int );
 
void cv_freq_pack(STAT_AVG *, int, int );

void cv_freq_unpack(STAT_AVG *, int, int );

void fetch_updn_id(int ,int ,int *,int *,
                   int *,int *,int *,int *);

void switch_communicate_atoms(int ,int , int ,int ,CLATOMS_POS *, 
                              MPI_Comm ,int ,int ,int,int,int);

/*---------------------------------------------------------------------*/
