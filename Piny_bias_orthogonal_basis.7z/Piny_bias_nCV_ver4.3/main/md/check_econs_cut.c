/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
/*                                                                          */
/*                         PI_MD:                                           */
/*             The future of simulation technology                          */
/*             ------------------------------------                         */
/*                     Module: auto_exit                                    */
/*                                                                          */
/* Allows user to stop a run before number of steps has been reached        */
/*                                                                          */
/*                                                                          */
/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/


#include "standard_include.h"

/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void check_econs_cut(double CUT, double E, int *flag)

/*=======================================================================*/
{ /*begin function */
/*=======================================================================*/
/*            Local variable declarations                                */

   if (E > CUT) {
     printf("what a large E %lg, cut %lg\n",E,CUT);
     *flag = 1;
  printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("You have issued the automatic EXIT command.\n");
  printf("I will now perform one last step and\n");
  printf("then exit.  Thanks for using PINY_MD!\n");
  printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
 } else {*flag = 0;}


/*-----------------------------------------------------------------------*/
  }/*end function */
/*========================================================================*/



