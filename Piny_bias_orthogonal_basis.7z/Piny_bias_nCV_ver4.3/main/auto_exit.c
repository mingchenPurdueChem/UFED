/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
/*                                                                          */
/*                         PI_MD:                                           */
/*             The future of simulation technology                          */
/*             ------------------------------------                         */
/*                     Module: auto_exit                                    */
/*                                                                          */
/* Allows user to stop a run before number of steps has been reached        */
/*                                                                          */
/*                                                                          */
/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/


#include "standard_include.h"
void check_auto_exit(int *);

/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void check_auto_exit(int *exit_flag)

/*=======================================================================*/
{ /*begin function */
/*=======================================================================*/
/*            Local variable declarations                                */

   FILE *wfp;   
   char name[MAXWORD];
   int exit_found=0;

/*=======================================================================*/
/* Check to see if EXIT file exists.  If so, set exit_flag to 1          */

    system("ls -1 > xxx888");
    wfp = fopen("xxx888","r");
    while(1) {
      fscanf(wfp,"%s",name);
      if((strcasecmp(name,"EXIT")==0)) {*exit_flag = 1; exit_found = 1;}
      if((strcasecmp(name,"xxx888")==0)) break;
    }/* endwhile */
    fclose(wfp);
    system("/bin/rm xxx888"); 
    if(exit_found == 1) {
      printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
      printf("You have issued the automatic EXIT command.\n");
      printf("I will now perform one last step and\n");
      printf("then exit.  Thanks for using PINY_MD!\n");
      printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
      system("/bin/rm EXIT");
    }/* endif */


/*-----------------------------------------------------------------------*/
  }/*end function */
/*========================================================================*/



