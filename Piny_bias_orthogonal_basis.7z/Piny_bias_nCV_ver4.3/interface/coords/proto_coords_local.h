void comm_coord_class_state(CLASS *, GENERAL_DATA *,int, int, int,int , int );


void molecule_decomp_err(int,char *,int);

void assign_coord_forc(CLASS *);

void assign_bonded_forc(BONDED *,CLASS *,int );

void assign_thermo_forc(CLASS *,int );

void assign_bead_thermo_forc(CLASS *,int );


