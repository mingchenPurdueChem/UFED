/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
/*                                                                          */
/*                         PI_MD:                                           */
/*             The future of simulation technology                          */
/*             ------------------------------------                         */
/*                     Module: mall_coef                                    */
/*                                                                          */
/* This subprogram reads atm-atm_NHC vol-vol_NHC input for a MD on a        */ 
/* LD-classical potential energy surface (LD-PES)                           */
/*                                                                          */
/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/


#include "standard_include.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_par.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_cp.h"
/*still broken: */

#include "../proto_defs/proto_coords_cp_entry.h"
#include "../proto_defs/proto_coords_cp_local.h"
#include "../proto_defs/proto_friend_lib_entry.h"

/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void mall_coef(CP *cp,SIMOPTS *simopts,int pi_beads_proc,int npara_temps_proc)

/*======================================================================*/
/*                Begin Routine */
{   /*begin routine */
/*======================================================================*/
/*               Local variable declarations                            */

  int np                = cp->communicate_m.np;
  int pi_beads          = cp->cpcoeffs_info.pi_beads;
  int npara_temps_proc2 = npara_temps_proc;
  int ioff     = 1;

  /* parallel malloc sizes : just a tad more */
  if(np>1){
    npara_temps_proc2 += 2; 
    ioff               = pi_beads_proc-1;
  }/*endif*/

/*========================================================================*/
/* I) Malloc the vector structures                                        */

  /* Extra space */
   cp->cpcoeffs_pos = (CPCOEFFS_POS *)cmalloc(pi_beads_proc*
					      npara_temps_proc2*
					      sizeof(CPCOEFFS_POS))-ioff;
   cp->cptherm_pos = (CPTHERM_POS *)cmalloc(pi_beads_proc*
					    npara_temps_proc2*
					    sizeof(CPTHERM_POS))-ioff;
   /* no extra space */
   cp->electronic_properties    = 
                     (ELECTRONIC_PROPERTIES *) cmalloc(pi_beads_proc*
		      npara_temps_proc*sizeof(ELECTRONIC_PROPERTIES))-1;

/*========================================================================*/
  } /* end routine */
/*==========================================================================*/




