/*----------------------------------------------------------------------*/
/* control_sim_params.c */

void control_sim_params(CLASS *,GENERAL_DATA *,BONDED *,CP *,ANALYSIS *,
                        CLASS_PARSE *,CP_PARSE *,FILENAME_PARSE *);

/*----------------------------------------------------------------------*/
