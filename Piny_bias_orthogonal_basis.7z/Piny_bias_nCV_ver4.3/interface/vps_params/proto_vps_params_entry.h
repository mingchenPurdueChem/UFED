/*---------------------------------------------------------------*/
/* Control_vps_params.c */

void control_vps_params(PSEUDO *,CELL *,FILENAME_PARSE *,
   		        SPLINE_PARSE *,int ,NAME [],
			double *,int, int,int ,int , 
                        COMMUNICATE *, double);
















