/*-------------------------------------------------------------------------*/
/*       Controls                                                          */

void control_vc_smpl(GENERAL_DATA *,CP *,int );

void control_vcnhc_smpl(CP *,int);

void control_vc_scale(CP *,int);

void control_vcnhc_scale(CP *,int );

/*-------------------------------------------------------------------------*/
/*       Proj_vels                                                        */

void proj_velc(CP *,int);







