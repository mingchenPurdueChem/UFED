/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
/*                                                                          */
/*                         PI_MD:                                           */
/*             The future of simulation technology                          */
/*             ------------------------------------                         */
/*                     Module: parse                                        */
/*                                                                          */
/* This subprogram reads in all user inputs                                 */
/*                                                                          */
/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

#include "standard_include.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_cp.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../typ_defs/typedefs_par.h"
#include "../typ_defs/typedefs_stat.h"
#include "../proto_defs/proto_parse_entry.h"


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void mall_para_temp(CLASS *class,BONDED *bonded,GENERAL_DATA *general_data,
                    CP *cp)

/*==========================================================================*/
  {/* begin routine */
/*==========================================================================*/
 
 /* Over malloc the structures in parallel to make life easy. */
 /* As long as we don't malloc the BIG stuff insides them     */
 /* this is not much memory. Change this at your peril as     */
 /* many places in the interfaces, the structures are assumed */
 /* to be big.*/

  int npara_temps    = general_data->simopts.npara_temps;
  int npara_temps2   = npara_temps;
  int np             = class->communicate_m.np;
  int pi_beads_proc  = class->clatoms_info.pi_beads_proc;
  int pi_beads       = class->clatoms_info.pi_beads;
  int ioff           = 1;

  /* parallel malloc : add one extra memory location */
  if(np>1){
    npara_temps2   += 1;  /* we are already over dimensioned in parallel */
    ioff            = 0;  /* but we would like to start at zero          */
  }/*endif*/

/*==========================================================================*/
/* Information structure malloc */

  /* Leave extra space at the back*/
  general_data->statepoint     = 
       (STATEPOINT *)     cmalloc(npara_temps2*sizeof(STATEPOINT))-ioff;
  general_data->stat_avg       = 
       (STAT_AVG *)       cmalloc(npara_temps2*sizeof(STAT_AVG))-ioff;

  /* No extra space    */
  general_data->ptens       = 
       (PTENS *)          cmalloc(npara_temps*sizeof(PTENS))-1;
  general_data->tempering_screen_out = 
   (TEMPERING_SCREEN_OUT *)cmalloc(npara_temps*sizeof(TEMPERING_SCREEN_OUT))-1;

/*==========================================================================*/
/* Atom malloc */

  /* Extra space at the back */
  class->therm_info_class      = 
       (THERM_INFO *)     cmalloc(npara_temps2*sizeof(THERM_INFO))-ioff;
  class->therm_info_bead       = 
       (THERM_INFO *)     cmalloc(npara_temps2*sizeof(THERM_INFO))-ioff;
  class->therm_class           =
       (THERM_POS *)      cmalloc(npara_temps2*sizeof(THERM_POS))-ioff;

  bonded->bond_free            =
       (BOND_FREE *)      cmalloc(npara_temps2*sizeof(BOND_FREE))-ioff;
  bonded->bend_free            =
       (BEND_FREE *)      cmalloc(npara_temps2*sizeof(BEND_FREE))-ioff;
  bonded->tors_free            = 
       (TORS_FREE *)      cmalloc(npara_temps2*sizeof(TORS_FREE))-ioff;
  bonded->rbar_sig_free        = 
       (RBAR_SIG_FREE *)  cmalloc(npara_temps2*sizeof(RBAR_SIG_FREE))-ioff;
printf("MALLOC mall para\n");fflush(stdout);
  /* No extra space at the back */
  class->clatoms_tran      = 
       (CLATOMS_TRAN *)   cmalloc(npara_temps*sizeof(CLATOMS_TRAN))-1;
  class->clatoms_sysinfo      = 
       (CLATOMS_SYSINFO *)cmalloc(npara_temps*sizeof(CLATOMS_SYSINFO))-1;
  class->nbr_list.verlist      = 
       (VERLIST *)        cmalloc(npara_temps*sizeof(VERLIST))-1;
  class->nbr_list.lnklist      = 
       (LNKLIST *)        cmalloc(npara_temps*sizeof(LNKLIST))-1;
  class->interact.list_skin     = 
       (LIST_SKIN *)      cmalloc(npara_temps*sizeof(LIST_SKIN))-1;

/*==========================================================================*/
  }/* end routine */
/*==========================================================================*/
