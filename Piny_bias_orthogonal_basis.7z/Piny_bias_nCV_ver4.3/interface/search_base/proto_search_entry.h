/*---------------------------------------------------------------------*/
/*     Search_base_class.c                                             */


void search_base(int ,int ,CATM_LAB *,int , CATM_LAB *,int *,int *,int *, int ,
                       int ,char *);

void atmlst_not_found(int ,CATM_LAB *,int *,int ,char *);

/*---------------------------------------------------------------------*/
/*     Search_base_cp.c                                                */

void search_base_vps(char [],CVPS *,DICT_WORD [],int ,
                     DICT_WORD *[],DICT_WORD [],int ,int *);


/*---------------------------------------------------------------------*/
/* data_base_handle.c                                                  */

void read_data_base(char [],DICT_WORD [], int ,DATA_BASE_ENTRIES *,
                    CATM_LAB *,int , int );

void count_data_base(char [],DICT_WORD [], int , int *, int );




