/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
/*                                                                          */
/*                         PI_MD:                                           */
/*             The future of simulation technology                          */
/*             ------------------------------------                         */
/*                   Module: force_control.c                                */
/*                                                                          */
/* These routine bundle the interactions and send them to force nopol       */
/*                                                                          */
/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

#include "standard_include.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../proto_defs/proto_real_space_entry.h"
#include "../proto_defs/proto_real_space_local.h"

/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
 
void force_control(CLATOMS_INFO *clatoms_info,
                   CLATOMS_POS *clatoms_pos,
                   FOR_SCR *for_scr,ATOMMAPS *atommaps,
                   CELL *cell,PTENS *ptens,INTERACT *interact,
                   ENERGY_CTRL *energy_ctrl, NBR_LIST *nbr_list,EXCL *excl,
                   INTRA_SCR *intra_scr,double *vreal,double *vvdw,
                   double *vcoul,int error_check_on,
                   CLASS_COMM_FORC_PKG *class_comm_forc_pkg,int ipt)

/*==========================================================================*/
{/*Begin Routine*/
/*=======================================================================*/
/* X) local variable: */


/*=======================================================================*/
/* I) Nolist option */

    
  if((nbr_list->nolst)==1) {
    force_nolst(clatoms_info,clatoms_pos,
                for_scr,atommaps,cell,
 		ptens,interact,energy_ctrl,excl,
                intra_scr,vreal,
		vvdw,vcoul,class_comm_forc_pkg);
  }/*endif*/

/*======================================================================*/
/* II) Verlist option */

  if(((nbr_list->iver)==1)&&((energy_ctrl->iget_full_inter)==1)){
    force_verlst(clatoms_info,clatoms_pos,
                 for_scr,atommaps,cell,
		 ptens,interact,energy_ctrl,
		 nbr_list->verlist[ipt].nter,nbr_list->verlist[ipt].jter,
		 nbr_list->verlist[ipt].jver_off,intra_scr,vreal,vvdw,vcoul,class_comm_forc_pkg); 
  }/*endif*/
  if(((nbr_list->iver)==1)&&((energy_ctrl->iget_full_inter)==0)
     &&((energy_ctrl->iget_res_inter)==1)){
    force_verlst(clatoms_info,clatoms_pos,
                 for_scr,atommaps,cell,
		 ptens,interact,energy_ctrl,
		 nbr_list->verlist[ipt].nter_res,nbr_list->verlist[ipt].jter_res,
		 nbr_list->verlist[ipt].jver_off_res,intra_scr,vreal,vvdw,vcoul,class_comm_forc_pkg);
  }/*endif*/


/*=====================================================================*/
/* III) Link list option */

  if((nbr_list->ilnk==1)&&(energy_ctrl->iget_full_inter==1)){
    force_lnklst(clatoms_info,clatoms_pos,
		 for_scr,atommaps,cell,ptens,interact,
                 energy_ctrl,
		 (nbr_list->lnklist[ipt].ncell_a),(nbr_list->lnklist[ipt].ncell_b), 
		 (nbr_list->lnklist[ipt].ncell_c),
		 (nbr_list->lnklist->natm_cell_max),
		 (nbr_list->lnklist[ipt].lnk_list),
		 (nbr_list->lnklist[ipt].nshft_lnk),(nbr_list->lnklist[ipt].shft_wght),
		 (nbr_list->lnklist[ipt].ishft_a),(nbr_list->lnklist[ipt].ishft_b),
		 (nbr_list->lnklist[ipt].ishft_c),
		 (nbr_list->lnklist[ipt].iexl_chk),excl,intra_scr,vreal,vvdw,vcoul,
		 class_comm_forc_pkg);
  }/*endif*/
  if( ((nbr_list->ilnk)==1)&&((energy_ctrl->iget_full_inter)==0)
     &&((energy_ctrl->iget_res_inter)==1)){
     force_lnklst(clatoms_info,clatoms_pos,
       for_scr,atommaps,cell,ptens,interact,energy_ctrl,
       (nbr_list->lnklist[ipt].ncell_a),(nbr_list->lnklist[ipt].ncell_b),
       (nbr_list->lnklist[ipt].ncell_c),
       (nbr_list->lnklist[ipt].natm_cell_max),(nbr_list->lnklist[ipt].lnk_list),
       (nbr_list->lnklist[ipt].nshft_lnk_res),(nbr_list->lnklist[ipt].shft_wght_res),
       (nbr_list->lnklist[ipt].ishft_a_res),(nbr_list->lnklist[ipt].ishft_b_res),
       (nbr_list->lnklist[ipt].ishft_c_res),(nbr_list->lnklist[ipt].iexl_chk_res),
       excl,intra_scr,vreal,vvdw,vcoul,class_comm_forc_pkg);
  }/*endif*/

/*---------------------------------------------------------------------*/
  }/*end routine */
/*==========================================================================*/






