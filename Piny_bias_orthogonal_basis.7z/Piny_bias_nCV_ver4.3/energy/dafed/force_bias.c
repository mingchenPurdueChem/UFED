#include "standard_include.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../proto_defs/proto_dafed_energy.h"
#include "../proto_defs/proto_dafed_helper.h"
#include "../proto_defs/proto_math.h"

/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/

void force_bias(CLATOMS_INFO *clatoms_info, STAT_AVG *stat_avg, int ipt)
 
/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */

  DAFED_INFO *dinfo             = &(clatoms_info->daf_info[ipt]);
  BIAS_PACK *bias;
  CO *coeff;
  DAFED *Ree                    = &(clatoms_info->Ree[ipt]);
  DAFED *Rgyr                   = &(clatoms_info->Rgyr[ipt]);
  DAFED *NH                     = &(clatoms_info->NH[ipt]);
  DAFED *Phi                    = clatoms_info->Phi[ipt];
  DAFED *Dih                    = &(clatoms_info->Dih_cor[ipt]);
  DAFED *Na                     = &(clatoms_info->Nalpha[ipt]);
  DAFED *Nb                     = &(clatoms_info->Nbeta[ipt]);

  double **bias_pot_value,**bias_pot_dev,*L_value,*L_dev,*T_value,*T_dev;
  double s,a,b,pot,force,prod;
  int i_bias                    = stat_avg->i_bias;
  int n_cv                      = stat_avg->n_cv;
  int num_phi                   = clatoms_info->num_phi;
  int i,j,k,l,n_coeff,order,iflag;
  int *cv_type;  
  double delta = 0.001;//using for debug
  double s_p,s_m;//using for debug
  double scale = 3.14159265358979323846/180.0;
  double time = (double)(dinfo->time);

     stat_avg->bias_pot = 0.0;
     //printf("bias_pot %lg\n",stat_avg->bias_pot);
     bias = &(clatoms_info->bias[ipt]);
     n_coeff = bias->n_coeff;
     cv_type = bias->cv_type;
     iflag = 0;
     coeff = bias->coeff_list;
     bias_pot_value = (double **)cmalloc(n_coeff*sizeof(double*))-1;
     bias_pot_dev   = (double **)cmalloc(n_coeff*sizeof(double*))-1;
     for(j=1;j<=n_coeff;j++){
        bias_pot_value[j] = (double *)cmalloc(n_cv*sizeof(double))-1;
        bias_pot_dev[j]   = (double *)cmalloc(n_cv*sizeof(double))-1;
     }
  /*-----------------------------------------------------------------------*/
  /* Calculate function value and derivative */
     for(j=1;j<=n_cv;j++){
        if(cv_type[j]!=4){
          switch(cv_type[j]){
           case 1:s = Ree->s;break;
           case 2:s = Rgyr->s;break;
           case 3:s = NH->s;break;
           case 5:s = Dih->s;break;
           case 6:s = Na->s;break;
           case 7:s = Nb->s;break;
          }
          a = bias->min[j];
          b = bias->max[j];
	  //s = 0.5*(b+a);
	  //printf("cv %i,s %lg\n",j,s);
          L_value = (double *)cmalloc(bias->n_fun[j]*sizeof(double))-1;
          L_dev   = (double *)cmalloc(bias->n_fun[j]*sizeof(double))-1;
          L_fun(L_value,L_dev,bias->n_fun[j],a,b,s);
          for(k=1;k<=n_coeff;k++){
            order = coeff[k].order[j].n;                   
            //bias_pot_value[k][j] = L_value[order+1]*sw_fun(s,a,b);//pay attention to a<=s<=b
            //bias_pot_dev[k][j]   = L_dev[order+1]*sw_fun(s,a,b)+L_value[order+1]*sw_fun_dev(s,a,b);
	    //printf("order %i, i_cv %i, value %lg, dev %lg\n",order,j,bias_pot_value[k][j],bias_pot_dev[k][j]);
            bias_pot_value[k][j] = L_value[order+1];
	    bias_pot_dev[k][j]   = L_dev[order+1];
          }
          free(&(L_value[1]));
          free(&(L_dev[1]));
        }/*endif cv_type[i]!=4*/
        else{
          iflag += 1;
          s = Phi[iflag].s;
          T_value = (double *)cmalloc(bias->n_fun[j]*sizeof(double))-1;
          T_dev   = (double *)cmalloc(bias->n_fun[j]*sizeof(double))-1;
          T_fun(T_value,T_dev,bias->n_fun[j],s);
          for(k=1;k<=n_coeff;k++){
             order = coeff[k].order[j].n;
             bias_pot_value[k][j] = T_value[order+1];
             bias_pot_dev[k][j]   = T_dev[order+1];
          }
          free(&(T_value[1]));
          free(&(T_dev[1]));
        }/*end else*/
     }/*endfor n_cv*/ 

  /*-----------------------------------------------------------------------*/
  /* Calculate bias potential */
  
     for(j=1;j<=n_coeff;j++){
        prod = 1.0;
        for(k=1;k<=n_cv;k++){
           prod *= bias_pot_value[j][k];
        }
        stat_avg->bias_pot += coeff[j].c*prod;
    }
    //printf("i %i,i_bias %i\n",i,i_bias);
    //printf("potential %lg\n",stat_avg->bias_pot);
  /*-----------------------------------------------------------------------*/
  /* Calculate bias force */

     iflag = 0;
     for(j=1;j<=n_cv;j++){
        force = 0.0;
        for(k=1;k<=n_coeff;k++){
           prod = 1.0;
           for(l=1;l<=n_cv;l++){
              if(l!=j){prod *= bias_pot_value[k][l];}
              else{prod *= bias_pot_dev[k][l];}
           }/*endfor n_cv*/
           force += coeff[k].c*prod;
        }/*endfor n_coeff*/
        //printf("s %lg,pot %lg,force %lg\n",s,stat_avg->bias_pot,force);
        if(cv_type[j]==1){Ree->Fs -= force*time;}
        if(cv_type[j]==2){Rgyr->Fs -= force*time;}
        if(cv_type[j]==3){NH->Fs -= force*time;}
	if(cv_type[j]==5){Dih->Fs -= force*time;}
	if(cv_type[j]==6){Na->Fs -= force*time;}
        if(cv_type[j]==7){Nb->Fs -= force*time;}
        if(cv_type[j]==4){
          iflag += 1;
	  //printf("ind %i, Fs %lg, bias %lg, ",iflag,Phi[iflag].Fs,force);
          Phi[iflag].Fs -= force*time;
          //printf("Fs_after %lg\n",Phi[iflag].Fs);
        }
	//printf("ind %i,force %lg\n",j,force);
     }/*endfor n_cv*/

  /*-----------------------------------------------------------------------*/
  /* Test bias force Numerically*/

  /*-----------------------------------------------------------------------*/
  /* Free local variables */
    for(j=1;j<=n_coeff;j++){
       free(&(bias_pot_value[j][1]));
       free(&(bias_pot_dev[j][1]));
    }
    free(&(bias_pot_value[1]));
    free(&(bias_pot_dev[1]));
    //exit(0);
/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/

void L_fun(double *L_value, double *L_dev, int len,double a,double b,double s)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */

  double x,order;
  int i;
  double b_a_1 = 1.0/(b-a);

  /*-----------------------------------------------------------------------*/
  /* Rescale s */
  
  if(s>=a&&s<=b){x = 2.0*s*b_a_1-(b+a)*b_a_1;}
  if(s<a){x = -1.0;}
  if(s>b){x = 1.0;}
  
  /*-----------------------------------------------------------------------*/
  /* Calculate Legendre polynomial */
  
  if(len==1){
    L_value[1] = 1.0;
    L_dev[1] = 0.0;
  }
  else{
    L_value[1] = 1.0;
    L_value[2] = x;
    L_dev[1] = 0.0;
    L_dev[2] = 1.0;
  }
  for(i=3;i<=len;i++){
    order = (double)(i-2);
    L_value[i] = ((2.0*order+1.0)*x*L_value[i-1]-order*L_value[i-2])/(order+1.0);
    if(a<=s&&s<=b){
      L_dev[i] = ((2.0*order+1.0)*(L_value[i-1]+x*L_dev[i-1])-order*L_dev[i-2])/(order+1.0);
    }
    else{
      L_dev[i] = 0.0;
    }
  }
  for(i=1;i<=len;i++){
    L_dev[i] *= 2.0*b_a_1;
  }
    

/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/

void T_fun(double *T_value, double *T_dev, int len,double s)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */

  int i,order;
 
  for(i=1;i<=len;i++){
     if(i%2==1){
       order = (int)((i-1)/2);
       if(i==1){
         T_value[i] = 1.0;
         T_dev[i] = 0.0;
       }
       else{
         T_value[i] = cos(order*s);
         T_dev[i] = -order*sin(order*s);
       }
     }
     else{
       order = (int)(i/2);
       T_value[i] = sin(order*s);
       T_dev[i] = order*cos(order*s);
     }
  }  

/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/

double sw_fun(double a,double b,double s)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */

  double delta = 0.01*(b-a);
  double d_0   = 0.1;
  double x,doub,result;


  if(s<=a-delta){result = 1.0;}
  if(s>=a+delta&&s<=b-delta){result = 1.0;}
  if(s>=b+delta){result = 1.0;}
  if(s>a-delta&&s<a+delta){
    doub = ((s-a)*(s-a)-delta*delta);
    result = -d_0*doub*doub+1.0;
  }
  if(s>b-delta&&s<b+delta){
    doub = ((s-b)*(s-b)-delta*delta);
    result = -d_0*doub*doub+1.0;
  }
  return result;
  
/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/

double sw_fun_dev(double a,double b,double s)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */

  double delta = 0.01*(b-a);
  double d_0 = 0.1;
  double x,doub,result;

  if(s<=a-delta){result = 0.0;}
  if(s>=a+delta&&s<=b-delta){result = 0.0;}
  if(s>=b+delta){result = 0.0;}
  if(s>a-delta&&s<a+delta){
    result = -4.0*d_0*((s-a)*(s-a)-delta*delta)*(s-a);
  }
  if(s>b-delta&&s<b+delta){
    result = -4.0*d_0*((s-b)*(s-b)-delta*delta)*(s-b);
  }
  return result;
 
/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/







