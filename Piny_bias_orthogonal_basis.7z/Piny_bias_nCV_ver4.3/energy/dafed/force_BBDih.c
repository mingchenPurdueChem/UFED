#include "standard_include.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../proto_defs/proto_dafed_energy.h"
#include "../proto_defs/proto_dafed_helper.h"
#include "../proto_defs/proto_math.h"

/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
void force_BBDih(CLATOMS_INFO *clatoms_info, CLATOMS_POS *clatoms_pos, int ipt)
/*========================================================================*/
{/*begin routine*/
/*========================================================================*/

  DAFED *Dih_cor = &(clatoms_info->Dih_cor[ipt]);
  DAFED *Nalpha  = &(clatoms_info->Nalpha[ipt]);
  DAFED *Nbeta   = &(clatoms_info->Nbeta[ipt]);
  DAFED_INFO *dinfo   = clatoms_info->daf_info;
  DEV_TRI *dev   = clatoms_info->dev_bb;

  double array_ab[3],array_bc[3],array_cd[3],crs_1[3],crs_2[3],crs_12[3];
  double m_crs_1,m_crs_2,m_v2,phi_cos,phi_sin;
  double cos_a = 0.6432966007;
  double sin_a = 0.7656170606;
  double cos_b = -0.182180563;
  double sin_b = 0.9832650927;
  double *clatoms_x  = clatoms_pos[ipt].x;
  double *clatoms_y  = clatoms_pos[ipt].y;
  double *clatoms_z  = clatoms_pos[ipt].z;
  double *Fx,*Fy,*Fz;
  double **tri_bb    = clatoms_info->tri_bb;
  double dih_cor,nalpha,nbeta,diff,pre;  
  double ks,s;
  double tri11,tri12,tri21,tri22;
  double prod11,prod22,prod33,prod12,prod123;

  int num_ca = clatoms_info->num_ca;
  int n_dih = num_ca-3;
  int index_a,index_b,index_c,index_d,index_e;
  int i,j,k,l;
  int *Ca_map = clatoms_info->Ca_map;
  double (*dev_list1)[3][2],(*dev_list2)[3][2];

  /*-------  this is for numerical test ----------*/
  /*double **coord;
  double f_num,f_ana;


  coord = (double **)cmalloc(num_ca*sizeof(double*))-1;
  for(i=1;i<=num_ca;i++){
    coord[i] = (double*)cmalloc(3*sizeof(double))-1;
  }
  
  for(i=1;i<=num_ca;i++){
    index_a = clatoms_info->Ca_map[i];
    coord[i][1] = clatoms_x[index_a];
    coord[i][2] = clatoms_y[index_a];
    coord[i][3] = clatoms_z[index_a];
  }*/
  /*-----------------------------------------------*/

  for(i=1;i<=n_dih;i++){
     index_a = Ca_map[i];
     index_b = Ca_map[i+1];
     index_c = Ca_map[i+2];
     index_d = Ca_map[i+3];
     array_ab[0] = clatoms_x[index_b] - clatoms_x[index_a];
     array_ab[1] = clatoms_y[index_b] - clatoms_y[index_a];
     array_ab[2] = clatoms_z[index_b] - clatoms_z[index_a];

     array_bc[0] = clatoms_x[index_c] - clatoms_x[index_b];
     array_bc[1] = clatoms_y[index_c] - clatoms_y[index_b];
     array_bc[2] = clatoms_z[index_c] - clatoms_z[index_b];

     array_cd[0] = clatoms_x[index_d] - clatoms_x[index_c];
     array_cd[1] = clatoms_y[index_d] - clatoms_y[index_c];
     array_cd[2] = clatoms_z[index_d] - clatoms_z[index_c];
     cross_product(array_ab,array_bc,crs_1);
     cross_product(array_bc,array_cd,crs_2);

     //m_crs_1 = sqrt(dot(crs_1,crs_1));
     //m_crs_2 = sqrt(dot(crs_2,crs_2));
     //m_v2    = sqrt(dot(array_bc,array_bc));
     prod11  = 1.0/dot(crs_1,crs_1);
     prod22  = 1.0/dot(crs_2,crs_2);
     prod33  = 1.0/dot(array_bc,array_bc);
     prod12  = sqrt(prod11*prod22);
     prod123 = prod12*sqrt(prod33);



     phi_cos = dot(crs_1,crs_2)*prod12;
     cross_product(crs_1,crs_2,crs_12);
     phi_sin = dot(crs_12,array_bc)*prod123;
     tri_bb[i][1] = phi_cos;
     tri_bb[i][2] = phi_sin;     
     force_trifun(dev[i].dev_list,array_ab,array_bc,array_cd,
                  crs_1,crs_2,crs_12,prod11,prod22,prod33,prod123,prod12,
                  phi_cos,phi_sin);
  }
  
  if(Dih_cor->on==1||Dih_cor->on==3){
    dih_cor = 0.0;
    ks = Dih_cor->ks;
    s  = Dih_cor->s;
    Fx = Dih_cor->Fx;
    Fy = Dih_cor->Fy;
    Fz = Dih_cor->Fz;
    for(i=1;i<=n_dih-1;i++){
       dih_cor += 0.5*(1.0+tri_bb[i][1]*tri_bb[i+1][1]+tri_bb[i][2]*tri_bb[i+1][2]);
    }
  
    if(s<-3){Dih_cor->s = dih_cor - 0.001;s = Dih_cor->s;}
    if(dinfo[ipt].curr==0){
      Dih_cor->data[dinfo[ipt].to_file_curr] = dih_cor;
    }
    
    diff = dih_cor - s;
    Dih_cor->pote = 0.5*ks*diff*diff;
    Dih_cor->Fs   = ks*diff;    

    pre = -ks*diff;
    
    for(i=1;i<=n_dih-1;i++){
     dev_list1 = dev[i].dev_list;
     dev_list2 = dev[i+1].dev_list;
     tri11 = tri_bb[i][1];
     tri12 = tri_bb[i][2];
     tri21 = tri_bb[i+1][1];
     tri22 = tri_bb[i+1][2];

     Fx[i]   += 0.5*(dev_list1[0][0][0]*tri21+
                     dev_list1[0][0][1]*tri22);
     Fy[i]   += 0.5*(dev_list1[0][1][0]*tri21+
                     dev_list1[0][1][1]*tri22);
     Fz[i]   += 0.5*(dev_list1[0][2][0]*tri21+
                     dev_list1[0][2][1]*tri22);
     Fx[i+1] += 0.5*(dev_list1[1][0][0]*tri21+
                     dev_list2[0][0][0]*tri11+
                     dev_list1[1][0][1]*tri22+
                     dev_list2[0][0][1]*tri12);
     Fy[i+1] += 0.5*(dev_list1[1][1][0]*tri21+
                     dev_list2[0][1][0]*tri11+
                     dev_list1[1][1][1]*tri22+
                     dev_list2[0][1][1]*tri12);
     Fz[i+1] += 0.5*(dev_list1[1][2][0]*tri21+
                     dev_list2[0][2][0]*tri11+
                     dev_list1[1][2][1]*tri22+
                     dev_list2[0][2][1]*tri12);
     Fx[i+2] += 0.5*(dev_list1[2][0][0]*tri21+
                     dev_list2[1][0][0]*tri11+
                     dev_list1[2][0][1]*tri22+
                     dev_list2[1][0][1]*tri12);
     Fy[i+2] += 0.5*(dev_list1[2][1][0]*tri21+
                     dev_list2[1][1][0]*tri11+
                     dev_list1[2][1][1]*tri22+
                     dev_list2[1][1][1]*tri12);
     Fz[i+2] += 0.5*(dev_list1[2][2][0]*tri21+
                     dev_list2[1][2][0]*tri11+
                     dev_list1[2][2][1]*tri22+
                     dev_list2[1][2][1]*tri12);
     Fx[i+3] += 0.5*(dev_list1[3][0][0]*tri21+
                     dev_list2[2][0][0]*tri11+
                     dev_list1[3][0][1]*tri22+
                     dev_list2[2][0][1]*tri12);
     Fy[i+3] += 0.5*(dev_list1[3][1][0]*tri21+
                     dev_list2[2][1][0]*tri11+
                     dev_list1[3][1][1]*tri22+
                     dev_list2[2][1][1]*tri12);
     Fz[i+3] += 0.5*(dev_list1[3][2][0]*tri21+
                     dev_list2[2][2][0]*tri11+
                     dev_list1[3][2][1]*tri22+
                     dev_list2[2][2][1]*tri12);

     Fx[i+4] += 0.5*(dev_list2[3][0][0]*tri11+
                     dev_list2[3][0][1]*tri12);
     Fy[i+4] += 0.5*(dev_list2[3][1][0]*tri11+
                     dev_list2[3][1][1]*tri12);
     Fz[i+4] += 0.5*(dev_list2[3][2][0]*tri11+
                     dev_list2[3][2][1]*tri12);
    }
    for(i=1;i<=num_ca;i++){
       Fx[i] *= pre;
       Fy[i] *= pre;
       Fz[i] *= pre;
    }
    /*for(i=1;i<=clatoms_info->natm_tot;i++){
      printf("i %i,fx %lg\n",i,Dih_cor[ipt].Fx[i]);
      printf("i %i,fy %lg\n",i,Dih_cor[ipt].Fy[i]); 
      printf("i %i,fz %lg\n",i,Dih_cor[ipt].Fz[i]);
    }*/
    /*--------------  Numerically test force ---------------- */  
    /*for(i=1;i<=num_ca;i++){
      index_a = clatoms_info->Ca_map[i];
      for(j=1;j<=3;j++){
         f_num = get_numf_dcor(&(Dih_cor[ipt]),coord,i,j,num_ca,n_dih);
	 switch(j){
	  case 1:f_ana = Dih_cor[ipt].Fx[index_a];break;
	  case 2:f_ana = Dih_cor[ipt].Fy[index_a];break;
          case 3:f_ana = Dih_cor[ipt].Fz[index_a];break;
         }
         printf("ana %lg,num %lg\n",f_ana,f_num);
      }
    }*/
    /*------------------------------------------------------- */
  }
  
  if(Nalpha->on==1||Nalpha->on==3){
    nalpha = 0.0;
    ks = Nalpha->ks;
    s  = Nalpha->s;
    Fx = Nalpha->Fx;
    Fy = Nalpha->Fy;
    Fz = Nalpha->Fz;
    for(i=1;i<=n_dih;i++){
       nalpha += 0.5*(1.0+tri_bb[i][1]*cos_a+tri_bb[i][2]*sin_a);
    }
 
    if(s<-3){Nalpha->s = nalpha - 0.001;s = Nalpha->s;}
    if(dinfo[ipt].curr==0){
      Nalpha->data[dinfo[ipt].to_file_curr] = nalpha;
    }

    diff = nalpha - s;
    Nalpha->pote = 0.5*ks*diff*diff;
    Nalpha->Fs   = ks*diff;


    pre = -ks*diff;

    for(i=1;i<=n_dih;i++){
       dev_list1 = dev[i].dev_list;

       Fx[i]   += 0.5*(cos_a*dev_list1[0][0][0]+
                       sin_a*dev_list1[0][0][1]);
       Fy[i]   += 0.5*(cos_a*dev_list1[0][1][0]+
                       sin_a*dev_list1[0][1][1]);
       Fz[i]   += 0.5*(cos_a*dev_list1[0][2][0]+
                       sin_a*dev_list1[0][2][1]);
       Fx[i+1] += 0.5*(cos_a*dev_list1[1][0][0]+
                       sin_a*dev_list1[1][0][1]);
       Fy[i+1] += 0.5*(cos_a*dev_list1[1][1][0]+
                       sin_a*dev_list1[1][1][1]);
       Fz[i+1] += 0.5*(cos_a*dev_list1[1][2][0]+
                       sin_a*dev_list1[1][2][1]);
       Fx[i+2] += 0.5*(cos_a*dev_list1[2][0][0]+
                       sin_a*dev_list1[2][0][1]);
       Fy[i+2] += 0.5*(cos_a*dev_list1[2][1][0]+
                       sin_a*dev_list1[2][1][1]);
       Fz[i+2] += 0.5*(cos_a*dev_list1[2][2][0]+
                       sin_a*dev_list1[2][2][1]);
       Fx[i+3] += 0.5*(cos_a*dev_list1[3][0][0]+
                       sin_a*dev_list1[3][0][1]);
       Fy[i+3] += 0.5*(cos_a*dev_list1[3][1][0]+
                       sin_a*dev_list1[3][1][1]);
       Fz[i+3] += 0.5*(cos_a*dev_list1[3][2][0]+
                       sin_a*dev_list1[3][2][1]);

    }
    for(i=1;i<=num_ca;i++){
       Fx[i] *= pre;
       Fy[i] *= pre;
       Fz[i] *= pre;
    }
    /*--------------  Numerically test force ---------------- */
    /*for(i=1;i<=num_ca;i++){
       index_a = clatoms_info->Ca_map[i];
       for(j=1;j<=3;j++){
          f_num = get_numf_nalpha(&(Nalpha[ipt]),coord,i,j,num_ca,n_dih);
          switch(j){
            case 1:f_ana = Nalpha[ipt].Fx[index_a];break;
            case 2:f_ana = Nalpha[ipt].Fy[index_a];break;
            case 3:f_ana = Nalpha[ipt].Fz[index_a];break;
          }
          printf("ana %lg,num %lg\n",f_ana,f_num);
          }
     }*/
     /*------------------------------------------------------- */
  }
  if(Nbeta->on==1||Nbeta->on==3){
    nbeta = 0.0;
    ks = Nbeta->ks;
    s  = Nbeta->s;
    Fx = Nbeta->Fx;
    Fy = Nbeta->Fy;
    Fz = Nbeta->Fz;
    for(i=1;i<=n_dih;i++){
       nbeta += 0.5*(1.0+tri_bb[i][1]*cos_b+tri_bb[i][2]*sin_b);
    }

    if(s<-3){Nbeta->s = nbeta - 0.001;s = Nbeta->s;}
    if(dinfo[ipt].curr==0){
      Nbeta->data[dinfo[ipt].to_file_curr] = nbeta;
    }

    diff = nbeta - s;
    Nbeta->pote = 0.5*ks*diff*diff;
    Nbeta->Fs   = ks*diff;


    pre = -ks*diff;

    for(i=1;i<=n_dih;i++){
       dev_list1 = dev[i].dev_list;

       Fx[i]   += 0.5*(cos_b*dev_list1[0][0][0]+
                       sin_b*dev_list1[0][0][1]);
       Fy[i]   += 0.5*(cos_b*dev_list1[0][1][0]+
                       sin_b*dev_list1[0][1][1]);
       Fz[i]   += 0.5*(cos_b*dev_list1[0][2][0]+
                       sin_b*dev_list1[0][2][1]);
       Fx[i+1] += 0.5*(cos_b*dev_list1[1][0][0]+
                       sin_b*dev_list1[1][0][1]);
       Fy[i+1] += 0.5*(cos_b*dev_list1[1][1][0]+
                       sin_b*dev_list1[1][1][1]);
       Fz[i+1] += 0.5*(cos_b*dev_list1[1][2][0]+
                       sin_b*dev_list1[1][2][1]);
       Fx[i+2] += 0.5*(cos_b*dev_list1[2][0][0]+
                       sin_b*dev_list1[2][0][1]);
       Fy[i+2] += 0.5*(cos_b*dev_list1[2][1][0]+
                       sin_b*dev_list1[2][1][1]);
       Fz[i+2] += 0.5*(cos_b*dev_list1[2][2][0]+
                       sin_b*dev_list1[2][2][1]);
       Fx[i+3] += 0.5*(cos_b*dev_list1[3][0][0]+
                       sin_b*dev_list1[3][0][1]);
       Fy[i+3] += 0.5*(cos_b*dev_list1[3][1][0]+
                       sin_b*dev_list1[3][1][1]);
       Fz[i+3] += 0.5*(cos_b*dev_list1[3][2][0]+
                       sin_b*dev_list1[3][2][1]);

    }
    for(i=1;i<=num_ca;i++){
       Fx[i] *= pre;
       Fy[i] *= pre;
       Fz[i] *= pre;
    }

    /*--------------  Numerically test force ---------------- */
    /*for(i=1;i<=num_ca;i++){
       index_a = clatoms_info->Ca_map[i];
       for(j=1;j<=3;j++){
          f_num = get_numf_nbeta(&(Nbeta[ipt]),coord,i,j,num_ca,n_dih);
          switch(j){
            case 1:f_ana = Nbeta[ipt].Fx[index_a];break;
            case 2:f_ana = Nbeta[ipt].Fy[index_a];break;
            case 3:f_ana = Nbeta[ipt].Fz[index_a];break;
          }
          printf("ana %lg,num %lg\n",f_ana,f_num);
       }
    }*/
    /*------------------------------------------------------- */
  }

/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
double get_numf_dcor(DAFED *Dih_cor,double **coord, int i_atm, int i_cord, 
                     int num_ca, int n_dih)
/*========================================================================*/
{/*begin routine*/
/*========================================================================*/

  int i,j,k,ite;
  double dx = 0.00001;
  double dx_ite;

  double **coord_l;
  double pe[2];  
  double array_ab[3],array_bc[3],array_cd[3],crs_1[3],crs_2[3],crs_12[3];
  double m_crs_1,m_crs_2,m_v2,phi_cos,phi_sin;
  double dih_cor,diff,ks;
  double **tri_bb;

  coord_l = (double**)cmalloc(num_ca*sizeof(double*))-1;
  for(i=1;i<=num_ca;i++){
    coord_l[i] = (double*)cmalloc(3*sizeof(double))-1;
  }
  tri_bb = (double**)cmalloc(n_dih*sizeof(double*))-1;
  for(i=1;i<=n_dih;i++){
    tri_bb[i] = (double*)cmalloc(2*sizeof(double))-1;
  }

  for(ite=0;ite<=1;ite++){
     dx_ite = dx*2.0*(ite-0.5);
     for(i=1;i<=num_ca;i++){
       for(j=1;j<=3;j++){
         coord_l[i][j] = coord[i][j];
       }
     }
     coord_l[i_atm][i_cord] += dx_ite;
     for(i=1;i<=n_dih;i++){
        array_ab[0] = coord_l[i+1][1] - coord_l[i][1];
        array_ab[1] = coord_l[i+1][2] - coord_l[i][2];
        array_ab[2] = coord_l[i+1][3] - coord_l[i][3];

        array_bc[0] = coord_l[i+2][1] - coord_l[i+1][1];
        array_bc[1] = coord_l[i+2][2] - coord_l[i+1][2];
        array_bc[2] = coord_l[i+2][3] - coord_l[i+1][3];

        array_cd[0] = coord_l[i+3][1] - coord_l[i+2][1];
        array_cd[1] = coord_l[i+3][2] - coord_l[i+2][2];
        array_cd[2] = coord_l[i+3][3] - coord_l[i+2][3];
        cross_product(array_ab,array_bc,crs_1);
        cross_product(array_bc,array_cd,crs_2);

        m_crs_1 = sqrt(dot(crs_1,crs_1));
        m_crs_2 = sqrt(dot(crs_2,crs_2));
        m_v2    = sqrt(dot(array_bc,array_bc));


        phi_cos = dot(crs_1,crs_2)/(m_crs_1*m_crs_2);
        cross_product(crs_1,crs_2,crs_12);
        phi_sin = dot(crs_12,array_bc)/(m_crs_1*m_crs_2*m_v2);
        tri_bb[i][1] = phi_cos;
        tri_bb[i][2] = phi_sin;
     }
     dih_cor = 0.0;
     ks = Dih_cor->ks;
     for(i=1;i<=n_dih-1;i++){
        dih_cor += 0.5*(1.0+tri_bb[i][1]*tri_bb[i+1][1]+tri_bb[i][2]*tri_bb[i+1][2]);
     }
     diff = dih_cor - Dih_cor->s;
     pe[ite] = 0.5*ks*diff*diff;

  }

  return (pe[0]-pe[1])*0.5/dx;

/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/

/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
double get_numf_nalpha(DAFED *Nalpha,double **coord, int i_atm, int i_cord, 
                     int num_ca, int n_dih)
/*========================================================================*/
{/*begin routine*/
/*========================================================================*/

  int i,j,k,ite;
  double dx = 0.00001;
  double dx_ite;
  double cos_a = 0.6432966007;
  double sin_a = 0.7656170606;

  double **coord_l;
  double pe[2];  
  double array_ab[3],array_bc[3],array_cd[3],crs_1[3],crs_2[3],crs_12[3];
  double m_crs_1,m_crs_2,m_v2,phi_cos,phi_sin;
  double nalpha,diff,ks;
  double **tri_bb;

  coord_l = (double**)cmalloc(num_ca*sizeof(double*))-1;
  for(i=1;i<=num_ca;i++){
    coord_l[i] = (double*)cmalloc(3*sizeof(double))-1;
  }
  tri_bb = (double**)cmalloc(n_dih*sizeof(double*))-1;
  for(i=1;i<=n_dih;i++){
    tri_bb[i] = (double*)cmalloc(2*sizeof(double))-1;
  }

  for(ite=0;ite<=1;ite++){
     dx_ite = dx*2.0*(ite-0.5);
     for(i=1;i<=num_ca;i++){
       for(j=1;j<=3;j++){
         coord_l[i][j] = coord[i][j];
       }
     }
     coord_l[i_atm][i_cord] += dx_ite;
     for(i=1;i<=n_dih;i++){
        array_ab[0] = coord_l[i+1][1] - coord_l[i][1];
        array_ab[1] = coord_l[i+1][2] - coord_l[i][2];
        array_ab[2] = coord_l[i+1][3] - coord_l[i][3];

        array_bc[0] = coord_l[i+2][1] - coord_l[i+1][1];
        array_bc[1] = coord_l[i+2][2] - coord_l[i+1][2];
        array_bc[2] = coord_l[i+2][3] - coord_l[i+1][3];

        array_cd[0] = coord_l[i+3][1] - coord_l[i+2][1];
        array_cd[1] = coord_l[i+3][2] - coord_l[i+2][2];
        array_cd[2] = coord_l[i+3][3] - coord_l[i+2][3];
        cross_product(array_ab,array_bc,crs_1);
        cross_product(array_bc,array_cd,crs_2);

        m_crs_1 = sqrt(dot(crs_1,crs_1));
        m_crs_2 = sqrt(dot(crs_2,crs_2));
        m_v2    = sqrt(dot(array_bc,array_bc));


        phi_cos = dot(crs_1,crs_2)/(m_crs_1*m_crs_2);
        cross_product(crs_1,crs_2,crs_12);
        phi_sin = dot(crs_12,array_bc)/(m_crs_1*m_crs_2*m_v2);
        tri_bb[i][1] = phi_cos;
        tri_bb[i][2] = phi_sin;
     }
     nalpha = 0.0;
     ks = Nalpha->ks;
     for(i=1;i<=n_dih;i++){
        nalpha += 0.5*(1.0+tri_bb[i][1]*cos_a+tri_bb[i][2]*sin_a);
     }
     diff = nalpha - Nalpha->s;
     pe[ite] = 0.5*ks*diff*diff;

  }

  return (pe[0]-pe[1])*0.5/dx;

/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/

/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
double get_numf_nbeta(DAFED *Nbeta,double **coord, int i_atm, int i_cord, 
                     int num_ca, int n_dih)
/*========================================================================*/
{/*begin routine*/
/*========================================================================*/

  int i,j,k,ite;
  double dx = 0.00001;
  double dx_ite;
  double cos_b = -0.182180563;
  double sin_b = 0.9832650927;

  double **coord_l;
  double pe[2];  
  double array_ab[3],array_bc[3],array_cd[3],crs_1[3],crs_2[3],crs_12[3];
  double m_crs_1,m_crs_2,m_v2,phi_cos,phi_sin;
  double nbeta,diff,ks;
  double **tri_bb;

  coord_l = (double**)cmalloc(num_ca*sizeof(double*))-1;
  for(i=1;i<=num_ca;i++){
    coord_l[i] = (double*)cmalloc(3*sizeof(double))-1;
  }
  tri_bb = (double**)cmalloc(n_dih*sizeof(double*))-1;
  for(i=1;i<=n_dih;i++){
    tri_bb[i] = (double*)cmalloc(2*sizeof(double))-1;
  }

  for(ite=0;ite<=1;ite++){
     dx_ite = dx*2.0*(ite-0.5);
     for(i=1;i<=num_ca;i++){
       for(j=1;j<=3;j++){
         coord_l[i][j] = coord[i][j];
       }
     }
     coord_l[i_atm][i_cord] += dx_ite;
     for(i=1;i<=n_dih;i++){
        array_ab[0] = coord_l[i+1][1] - coord_l[i][1];
        array_ab[1] = coord_l[i+1][2] - coord_l[i][2];
        array_ab[2] = coord_l[i+1][3] - coord_l[i][3];

        array_bc[0] = coord_l[i+2][1] - coord_l[i+1][1];
        array_bc[1] = coord_l[i+2][2] - coord_l[i+1][2];
        array_bc[2] = coord_l[i+2][3] - coord_l[i+1][3];

        array_cd[0] = coord_l[i+3][1] - coord_l[i+2][1];
        array_cd[1] = coord_l[i+3][2] - coord_l[i+2][2];
        array_cd[2] = coord_l[i+3][3] - coord_l[i+2][3];
        cross_product(array_ab,array_bc,crs_1);
        cross_product(array_bc,array_cd,crs_2);

        m_crs_1 = sqrt(dot(crs_1,crs_1));
        m_crs_2 = sqrt(dot(crs_2,crs_2));
        m_v2    = sqrt(dot(array_bc,array_bc));


        phi_cos = dot(crs_1,crs_2)/(m_crs_1*m_crs_2);
        cross_product(crs_1,crs_2,crs_12);
        phi_sin = dot(crs_12,array_bc)/(m_crs_1*m_crs_2*m_v2);
        tri_bb[i][1] = phi_cos;
        tri_bb[i][2] = phi_sin;
     }
     nbeta = 0.0;
     ks = Nbeta->ks;
     for(i=1;i<=n_dih;i++){
        nbeta += 0.5*(1.0+tri_bb[i][1]*cos_b+tri_bb[i][2]*sin_b);
     }
     diff = nbeta - Nbeta->s;
     pe[ite] = 0.5*ks*diff*diff;

  }

  return (pe[0]-pe[1])*0.5/dx;

/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/


