
#include "standard_include.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../proto_defs/proto_dafed_energy.h"
#include "../proto_defs/proto_dafed_helper.h"
#include "../proto_defs/proto_math.h"


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
void force_Ree (CLATOMS_INFO *clatoms_info, CLATOMS_POS *clatoms_pos, int ipt)
/*========================================================================*/
{/*begin routine*/
/*========================================================================*/


  double dx, dy, dz, reesq, ree;
 
  DAFED *Ree = &(clatoms_info->Ree[ipt]);
  DAFED_INFO *dinfo = clatoms_info->daf_info; 
  double *clatoms_x	= clatoms_pos[ipt].x;
  double *clatoms_y	= clatoms_pos[ipt].y;
  double *clatoms_z	= clatoms_pos[ipt].z; 
  double PRE;
  double ks = Ree->ks;
  double s  = Ree->s;
  double diff;
  int n1 = Ree->i1[1];
  int n2 = Ree->i2[1];
  double *Fx = Ree->Fx;
  double *Fy = Ree->Fy;
  double *Fz = Ree->Fz;
  

  int iii; 
  
  /* for numerical force*/ 
  /*double delta = 0.0001;
  double ree_n_sq1,ree_n_sq2,ree_n1,ree_n2,dx1,dx2,dy1,dy2,dz1,dz2;
  double pot1,pot2,force;*/

/*==========================================================================*/

  dx = clatoms_x[n1] - clatoms_x[n2];
  dy = clatoms_y[n1] - clatoms_y[n2];
  dz = clatoms_z[n1] - clatoms_z[n2];

  reesq = dx*dx+dy*dy+dz*dz;
  ree   = sqrt(reesq);

  if (s < 0) {Ree->s = ree - 0.0001;s = Ree->s;}
  if (dinfo[ipt].curr == 0) 
  Ree->data[dinfo[ipt].to_file_curr] = ree;
  
  diff = ree-s;
  Ree->pote = ks*diff*diff*0.5;
  Ree->Fs   = ks*diff;

  PRE = ks*diff/(ree);

  Fx[1] = -PRE*dx;
  Fx[2] = +PRE*dx;
  Fy[1] = -PRE*dy;
  Fy[2] = +PRE*dy;
  Fz[1] = -PRE*dz;
  Fz[2] = +PRE*dz;

  /* Numerical force*/
/*
  dx1 = dx + delta;
  dx2 = dx - delta;

  ree_n_sq1 = dx1*dx1+dy*dy+dz*dz;
  ree_n_sq2 = dx2*dx2+dy*dy+dz*dz;

  ree_n1 = sqrt(ree_n_sq1);
  ree_n2 = sqrt(ree_n_sq2);
  
  pot1 = Ree[ipt].ks*pow(ree_n1 - Ree[ipt].s,2)*0.5;
  pot2 = Ree[ipt].ks*pow(ree_n2 - Ree[ipt].s,2)*0.5;

  force = -(pot1-pot2)/delta*0.5;
  printf("ana force %lg, num force %lg\n",-PRE*dx,force);
*/
/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
double get_Ree_value(CLATOMS_INFO *clatoms_info, CLATOMS_POS *clatoms_pos, int ipt)
/*========================================================================*/
{/*begin routine*/
/*========================================================================*/

  double dx, dy, dz, reesq, ree;

  DAFED *Ree = clatoms_info->Ree;
  DAFED_INFO *dinfo = clatoms_info->daf_info;
  double *clatoms_x     = clatoms_pos[ipt].x;
  double *clatoms_y     = clatoms_pos[ipt].y;
  double *clatoms_z     = clatoms_pos[ipt].z;

/*==========================================================================*/

  dx = clatoms_x[Ree[ipt].i1[1]] - clatoms_x[Ree[ipt].i2[1]];
  dy = clatoms_y[Ree[ipt].i1[1]] - clatoms_y[Ree[ipt].i2[1]];
  dz = clatoms_z[Ree[ipt].i1[1]] - clatoms_z[Ree[ipt].i2[1]];

  reesq = pow(dx,2) + pow(dy,2); + pow(dz,2);
  ree   = sqrt(reesq);

  return(ree - 0.0001);

/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/







