void control_pimd_trans_force(CLASS *,GENERAL_DATA *,int );

void control_pimd_trans_mode(CLASS *,GENERAL_DATA *,int );

void control_pimd_trans_pos(CLASS *,GENERAL_DATA *,int );

void mode_energy_control(CLASS *,GENERAL_DATA *,int );

void pimd_pvten_forc_corr(CLASS *, GENERAL_DATA *,double *,int);

void get_vir_press(CLASS *, GENERAL_DATA *general_data, double *,int);

void spread_coord(CLATOMS_INFO *,CLATOMS_SYSINFO *,
                  CLATOMS_POS *,
                  double *,double *,double *,
                  int *,int *,double *,
                  ATOMMAPS *,int );

void pimd_harm_energy(CLASS *,GENERAL_DATA *,int ,double , double *);




