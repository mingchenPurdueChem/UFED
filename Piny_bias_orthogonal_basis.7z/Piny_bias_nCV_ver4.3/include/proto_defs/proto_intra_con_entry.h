#include "../../energy/intra_con/proto_intra_con_entry.h"
