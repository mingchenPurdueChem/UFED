#include "../../energy/control/proto_energy_ctrl_local.h"
