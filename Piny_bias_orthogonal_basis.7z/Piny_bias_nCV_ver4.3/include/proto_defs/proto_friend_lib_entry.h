#include "../../friend_lib/proto_friend_lib_entry.h"
