#include "../../energy/pimd/proto_pimd_local.h"
