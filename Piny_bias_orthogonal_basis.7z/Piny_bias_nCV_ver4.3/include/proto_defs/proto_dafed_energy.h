#include "../../energy/dafed/proto_dafed_energy.h"

