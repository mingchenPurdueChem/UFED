#include "../../output/proto_output_cp_entry.h"
