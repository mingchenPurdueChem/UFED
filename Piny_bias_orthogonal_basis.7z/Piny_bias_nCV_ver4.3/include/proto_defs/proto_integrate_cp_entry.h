#include "../../integrate/cp/proto_integrate_cp_entry.h"
