#include "../../integrate/cpmin/proto_integrate_cpmin_entry.h"
