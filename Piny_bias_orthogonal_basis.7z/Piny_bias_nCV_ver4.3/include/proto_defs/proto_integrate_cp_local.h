#include "../../integrate/cp/proto_integrate_cp_local.h"
