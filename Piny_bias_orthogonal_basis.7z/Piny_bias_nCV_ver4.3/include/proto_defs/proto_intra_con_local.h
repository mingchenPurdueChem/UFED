#include "../../energy/intra_con/proto_intra_con_local.h"
