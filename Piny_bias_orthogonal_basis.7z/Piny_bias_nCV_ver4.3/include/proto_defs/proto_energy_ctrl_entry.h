#include "../../energy/control/proto_energy_ctrl_entry.h"
